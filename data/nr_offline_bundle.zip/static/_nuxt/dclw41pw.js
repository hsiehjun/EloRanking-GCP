import{d as G,_ as Q,o as i,c as p,f as r,F as C,g as D,b as o,t as m,a as w,I as St,h,e as E,w as k,k as P,R as I,aR as bn,Z as je,a0 as Gt,s as yn,aW as vn,ak as Pe,v as q,m as B,j as N,l as T,r as R,N as K,n as oe,G as Bt,H as We,b8 as wn,bm as Xe,E as Qt,b7 as ze,aU as Cn,aS as En,aT as Fn,u as Ut,y as $t,P as Ze,aJ as kn,$ as Se,a6 as Dn,aj as An,a7 as Rt,aI as Pn,a8 as Sn,aX as Gn,b2 as Bn,aa as Mt,b4 as Qn,O as Un,i as $n,bt as M,bx as Rn,ae as Mn,aK as In,a1 as Hn,b0 as Ln,ba as Tn}from"./D7p1p3T3.js";import{_ as H}from"./DNPng9xq.js";import{aO as Ke,bz as It,_ as Je,f6 as qe,I as On,f7 as Yn,f8 as it,f9 as Nn,ba as Ge,fa as Vn,cr as Ie,k as He,fb as Ht,fc as jn,bv as Lt,fd as Be,fe as Wn,bu as Xn,aK as Qe,aX as _,ff as zn,fg as at,M as Zn,aB as Kn,w as V,fh as Jn,fi as qn,fj as _n,fk as Le,cV as es,fl as ts,au as ns,N as se,p as _e,A as Tt,B as ke,fm as ss,fn as os,fo as rs,fp as is,ck as as,aJ as ls,cf as he,f3 as xe,ca as Ae,a_ as ds,fq as ps,fr as ie,fs as Ot,c7 as lt,ao as us,ab as Ce,q as Yt,ft as et,fu as Nt,c9 as dt,aZ as pt,cl as pe,fv as cs,fw as gs,b0 as fs,E as ms,eV as hs,eW as xs,eX as bs,eY as ys,eZ as vs,e_ as ws,e$ as Cs,f0 as Es,f5 as Fs,bl as ks,cX as Ds,P as ut}from"./aT_s2Hv8.js";import{u as te,_ as As}from"./D7n9-sfm.js";import{_ as be}from"./CEx-G14Y.js";import{E as ye}from"./DUryOkKs.js";import{c as Vt,a as X,_ as Ue,d as Ps,R as Ss,S as Gs,T as ct}from"./DF-PUrh0.js";import{_ as jt}from"./BvTDIbaE.js";import Bs from"./DyYfjHhV.js";import{B as Qs,d as ge}from"./su0bLjbT.js";import{_ as ne}from"./RG-uSisl.js";import{_ as Us}from"./DZWp_Li8.js";import{c as $s,_ as Rs,a as Ms}from"./b-UVIE7U.js";import{_ as gt,u as Is}from"./V_zMSna8.js";import{_ as Hs}from"./tZAMxTaq.js";import{_ as $e}from"./CecovokV.js";import{s as ft,B as tt}from"./B1ChPxjI.js";import{_ as Wt}from"./CUGZkScV.js";import{f as me,w as Ls}from"./BQcJRbkS.js";import{_ as Xt}from"./CXWN7T-H.js";import{b as Ts,A as Os}from"./19TlUyUM.js";import{U as Ys}from"./44pr8VfO.js";(function(){try{var e=typeof window<"u"?window:typeof global<"u"?global:typeof globalThis<"u"?globalThis:typeof self<"u"?self:{};e.SENTRY_RELEASE={id:"nr@36.27"};var t=new e.Error().stack;t&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[t]="d07312be-712f-499c-a206-d05f49f74320",e._sentryDebugIdIdentifier="sentry-dbid-d07312be-712f-499c-a206-d05f49f74320")}catch{}})();const nt=G({setup(){return{store:te()}},props:{list:{type:Object,required:!0},mode:{type:Number,default:0}},computed:{army(){return this.list.army||null},book(){var e;return((e=this.army)==null?void 0:e.getBook())||null},selectedSystem(){var e;return((e=this.book)==null?void 0:e.getSystem())||null},system(){return this.selectedSystem},forces(){return this.army?this.army.getForces():null},editingUnit(){return this.store.editingUnit},bookHasOnlyOneForce(){var e,t;return((t=(e=this.list.army)==null?void 0:e.getBook())==null?void 0:t.hasOnlyOneForce())||!1}},methods:{debug(e){console.log(e.getName(),e),window.$debugOption=e}}}),Ns=G({mixins:[nt],components:{PopupDialog:H},props:{hideButtons:{type:Boolean,default:!1}},setup(){return{figurineStore:It()}},data(){return{showRemaining:!1,showAddDialog:!1,missingWithState:[]}},computed:{totalRequired(){if(!this.matchedFigurines)return 0;let e=0;const t=[...this.matchedFigurines.missing,...this.matchedFigurines.matches.map(n=>n.from)];for(const n of t)e+=n.amount||0;return e},totalOwned(){return this.totalRequired-this.total(this.missing)},totalBuilt(){return this.totalOwned-this.total(this.toBuild)},totalPainted(){return this.totalOwned-this.total(this.toPaint)},allMatched(){return this.$figurineStore.allMatched()},unmatched(){return this.$figurineStore.unmatched()},extra(){return Ke(this.$figurineStore.extra(),e=>{var t,n;return((n=(t=e.matches)==null?void 0:t[0])==null?void 0:n.catalogue)??""})},matchedFigurines(){return this.figurineStore.matchedFigurines},missing(){var e;return((e=this.figurineStore.matchedFigurines)==null?void 0:e.missing)||[]},toPaint(){return this.$figurineStore.toPaint()},toBuild(){return this.$figurineStore.toBuild()},allBuilt(){return this.missingWithState.length>0&&this.missingWithState.every(e=>e.built)},allPainted(){return this.missingWithState.length>0&&this.missingWithState.every(e=>e.painted)},hasAnyMiniatures(){return this.matchedFigurines?this.matchedFigurines.matches.length>0||this.matchedFigurines.extra.length>0:!1}},methods:{getActionText(e){const t=`models_${e}`;return this.$referenceStore.getString(t)},total(e){return e.reduce((t,n)=>t+(n.amount||0),0)},getAddMissingText(){const e=this.total(this.missing);return this.$referenceStore.getString("models_add_missing_models").replace("{count}",String(e)).replace(/\{plural\}/g,e!==1?"s":"")},async addListToMiniatures(){var e;(e=this.list)!=null&&e.army&&this.missing.length>0?(this.missingWithState=this.missing.map(t=>({...t,built:!1,painted:!1})),this.showAddDialog=!0):this.missing.length===0&&await customAlert(this.$referenceStore.getString("models_no_missing_miniatures"))},confirmAddMiniatures(){var e;if((e=this.list)!=null&&e.army){const t=String(this.list.army.getBook().getSystem().id),n=this.total(this.missingWithState);this.figurineStore.addMissingFigurines(this.missingWithState,t),this.figurineStore.updateMatchedFigurines(this.list.army),this.showAddDialog=!1,this.$showMessages([{type:0,msg:this.$referenceStore.getString("models_miniatures_added_success").replace("{count}",String(n))}])}},splitMiniature(e){const t=this.missingWithState[e];if(!t.amount||t.amount<=1)return;const n=Math.floor(t.amount/2),s=t.amount-n;t.amount=n;const a={...t,amount:s,built:!1,painted:!1};this.missingWithState.splice(e+1,0,a)},toggleAllBuilt(){const e=!this.allBuilt;this.missingWithState.forEach(t=>{t.built=e})},toggleAllPainted(){const e=!this.allPainted;this.missingWithState.forEach(t=>{t.painted=e})}}}),Vs={class:"section"},js={class:"blue"},Ws={class:"minisDetails"},Xs={key:0,class:"section"},zs={class:"minis"},Zs={key:1,class:"section"},Ks={key:2,class:"section"},Js={class:"bold",style:{"margin-left":"4px"}},qs={style:{margin:"0"}},_s={key:0},eo={class:"addMiniaturesList"},to={class:"dataTable"},no={style:{width:"80px"}},so=["checked"],oo={style:{width:"80px"}},ro=["checked"],io={key:0,class:"gray"},ao={style:{"text-align":"center"}},lo=["onUpdate:modelValue"],po={style:{"text-align":"center"}},uo=["onUpdate:modelValue"],co={style:{"text-align":"center"}},go=["innerHTML"],fo={key:0,class:"section boutons"},mo=["disabled"];function ho(e,t,n,s,a,d){const l=St,u=H,g=bn,c=je,x=Gt,y=Je;return i(),p("div",null,[r("div",null,[(i(!0),p(C,null,D(e.unmatched,b=>(i(),p("div",Vs,[r("div",null,[o(m(e.$referenceStore.getString("models_miniatures_you_need_to"))+" ",1),r("strong",js,m(e.getActionText(b.name)),1),t[9]||(t[9]=o(`:
        `,-1))]),t[10]||(t[10]=o()),r("div",Ws,[r("ul",null,[(i(!0),p(C,null,D(b.value,f=>(i(),p("li",null,m(f.amount)+"x "+m(f.name),1))),256))])])]))),256)),t[33]||(t[33]=o()),e.allMatched?(i(),p("div",Xs,[r("div",zs,[w(l,{size:16}),t[11]||(t[11]=o()),r("label",null,m(e.$referenceStore.getString("models_all_required_miniatures_owned")),1)])])):h("",!0),t[34]||(t[34]=o()),e.hasAnyMiniatures?(i(),p("div",Zs,[r("strong",null,m(e.$referenceStore.getString("models_totals")),1),t[12]||(t[12]=o()),r("div",null,m(e.$referenceStore.getString("models_required"))+": "+m(e.totalRequired),1),t[13]||(t[13]=o()),r("div",null,m(e.$referenceStore.getString("models_owned"))+": "+m(e.totalOwned),1),t[14]||(t[14]=o()),r("div",null,m(e.$referenceStore.getString("models_built"))+": "+m(e.totalBuilt),1),t[15]||(t[15]=o()),r("div",null,m(e.$referenceStore.getString("models_painted"))+": "+m(e.totalPainted),1)])):h("",!0),t[35]||(t[35]=o()),e.hasAnyMiniatures?(i(),p("div",Ks,[Object.values(e.extra).length?(i(),p("a",{key:0,class:"hover-underline clickable",onClick:t[0]||(t[0]=b=>e.showRemaining=!0)},m(e.$referenceStore.getString("models_view_remaining_miniatures")),1)):h("",!0)])):h("",!0),t[36]||(t[36]=o()),e.showRemaining?(i(),E(u,{key:3,modelValue:e.showRemaining,"onUpdate:modelValue":t[1]||(t[1]=b=>e.showRemaining=b),x:"",noclose:""},{header:k(()=>[o(m(e.$referenceStore.getString("models_remaining_miniatures")),1)]),default:k(()=>[(i(!0),p(C,null,D(Object.entries(e.extra),([b,f])=>(i(),p(C,null,[r("span",Js,m(b)+":",1),t[16]||(t[16]=o()),r("ul",qs,[(i(!0),p(C,null,D(f,v=>{var F;return i(),p(C,null,[v.name||(F=v.matches)!=null&&F.length?(i(),p("li",_s,m(v.amount)+"x "+m(v.name??(v.matches||[])[0].name),1)):h("",!0)],64)}),256))])],64))),256))]),_:1},8,["modelValue"])):h("",!0),t[37]||(t[37]=o()),e.showAddDialog?(i(),E(u,{key:4,modelValue:e.showAddDialog,"onUpdate:modelValue":t[6]||(t[6]=b=>e.showAddDialog=b),x:"",noclose:""},{header:k(()=>[o(m(e.$referenceStore.getString("models_confirm_add_miniatures").replace("{count}",String(e.total(e.missingWithState)))),1)]),default:k(()=>[r("div",eo,[r("table",to,[r("thead",null,[r("tr",null,[r("th",null,m(e.$referenceStore.getString("models_name")),1),t[22]||(t[22]=o()),r("th",no,[o(m(e.$referenceStore.getString("models_built")),1),t[18]||(t[18]=r("br",null,null,-1)),t[19]||(t[19]=o()),r("input",{type:"checkbox",checked:e.allBuilt,onChange:t[2]||(t[2]=(...b)=>e.toggleAllBuilt&&e.toggleAllBuilt(...b)),style:{"margin-left":"5px"}},null,40,so)]),t[23]||(t[23]=o()),r("th",oo,[o(m(e.$referenceStore.getString("models_painted")),1),t[20]||(t[20]=r("br",null,null,-1)),t[21]||(t[21]=o()),r("input",{type:"checkbox",checked:e.allPainted,onChange:t[3]||(t[3]=(...b)=>e.toggleAllPainted&&e.toggleAllPainted(...b)),style:{"margin-left":"5px"}},null,40,ro)]),t[24]||(t[24]=o()),t[25]||(t[25]=r("th",{style:{width:"40px"}},null,-1))])]),t[29]||(t[29]=o()),r("tbody",null,[(i(!0),p(C,null,D(e.missingWithState,(b,f)=>(i(),p("tr",{key:f},[r("td",null,[r("strong",null,m(b.amount)+"x",1),o(" "+m(b.name)+" ",1),b.unit?(i(),p("span",io,"("+m(b.unit)+")",1)):h("",!0)]),t[26]||(t[26]=o()),r("td",ao,[P(r("input",{type:"checkbox","onUpdate:modelValue":v=>b.built=v},null,8,lo),[[I,b.built]])]),t[27]||(t[27]=o()),r("td",po,[P(r("input",{type:"checkbox","onUpdate:modelValue":v=>b.painted=v},null,8,uo),[[I,b.painted]])]),t[28]||(t[28]=o()),r("td",co,[b.amount&&b.amount>1?(i(),E(g,{key:0,class:"clickable icon-small",onClick:v=>e.splitMiniature(f),title:e.$referenceStore.getString("models_split")},null,8,["onClick","title"])):h("",!0)])]))),128))])])])]),boutons:k(()=>[r("button",{class:"bouton",onClick:t[4]||(t[4]=(...b)=>e.confirmAddMiniatures&&e.confirmAddMiniatures(...b))},m(e.$referenceStore.getString("models_add_match")),1),t[30]||(t[30]=o()),r("button",{class:"bouton",onClick:t[5]||(t[5]=b=>e.showAddDialog=!1)},m(e.$referenceStore.getString("models_cancel")),1)]),_:1},8,["modelValue"])):h("",!0),t[38]||(t[38]=o()),e.hasAnyMiniatures?h("",!0):(i(),p("div",{key:5,class:"section",innerHTML:e.$referenceStore.getString("models_no_collection_yet")},null,8,go))]),t[40]||(t[40]=o()),e.hideButtons?h("",!0):(i(),p("div",fo,[e.missing.length>0?(i(),p("button",{key:0,class:"bouton",onClick:t[7]||(t[7]=(...b)=>e.addListToMiniatures&&e.addListToMiniatures(...b)),disabled:e.missing.length===0},[w(c,{class:"icon",size:22}),o(" "+m(e.getAddMissingText()),1)],8,mo)):h("",!0),t[39]||(t[39]=o()),w(y,{onClick:t[8]||(t[8]=b=>e.$emit("close")),class:"bouton",to:{name:"app-MyModels"}},{default:k(()=>[w(x,{class:"icon",size:24,style:{"vertical-align":"bottom"}}),o(" "+m(e.$referenceStore.getString("models_my_miniatures")),1)]),_:1})]))])}const xo=Object.assign(Q(Ns,[["render",ho],["__scopeId","data-v-c7ce88cc"]]),{__name:"ListsTablelistMatchedFigurines"}),bo=G({props:{list:{type:Object,required:!0}},setup(){return{store:It()}},components:{PopupDialog:H},data(){return{show:!1,support:!1}},methods:{openMinis(){this.$userStore.isSupporter()==!1?this.support=!0:this.show=!0},addMissingModels(){const e=this.store.matchedFigurines;if(!e||(e.missing||[]).length===0)return;const n=this.$refs.matchedFigurines;n!=null&&n.addListToMiniatures&&n.addListToMiniatures()}},computed:{allMatched(){return this.$optionStore.options.enableMinis==!1?0:this.store.matchedFigurines===null||this.$userStore.isSupporter()==!1?1:this.store.allMatched()?2:3},canAddModels(){const e=this.store.matchedFigurines;return e?(e.missing||[]).length>0:!1},addMissingText(){const e=this.store.matchedFigurines;if(!e)return"";const n=(e.missing||[]).reduce((a,d)=>a+(d.amount||0),0);return this.$referenceStore.getString("models_add_missing_models").replace("{count}",String(n)).replace(/\{plural\}/g,n!==1?"s":"")}}}),yo={key:0,class:"imgContainer"},vo={key:1},wo={class:"button-stack"},Co=["disabled"];function Eo(e,t,n,s,a,d){const l=Gt,u=St,g=yn,c=vn,x=xo,y=je,b=Je,f=H,v=As,F=be;return i(),p(C,null,[e.$optionStore.options.enableMinis?(i(),p("div",yo,[r("span",{class:"figIcon imgBt",onClick:t[0]||(t[0]=(...A)=>e.openMinis&&e.openMinis(...A))},[w(l,{size:32})]),t[6]||(t[6]=o()),e.allMatched===2?(i(),E(u,{key:0,class:"check",size:15})):h("",!0),t[7]||(t[7]=o()),e.allMatched===3?(i(),E(g,{key:1,class:"excl",size:14})):h("",!0),t[8]||(t[8]=o()),e.allMatched===1?(i(),E(c,{key:2,class:"excl",size:15})):h("",!0)])):(i(),p("div",vo)),t[13]||(t[13]=o()),e.show?(i(),E(f,{key:2,modelValue:e.show,"onUpdate:modelValue":t[4]||(t[4]=A=>e.show=A),x:"",noclose:"",width:"500px"},{header:k(()=>[...t[9]||(t[9]=[o("Miniature Matching",-1)])]),boutons:k(()=>[r("div",wo,[e.canAddModels?(i(),p("button",{key:0,class:"bouton",onClick:t[2]||(t[2]=(...A)=>e.addMissingModels&&e.addMissingModels(...A)),disabled:!e.canAddModels},[w(y,{class:"icon",size:22}),o(" "+m(e.addMissingText),1)],8,Co)):h("",!0),t[10]||(t[10]=o()),w(b,{onClick:t[3]||(t[3]=A=>e.show=!1),class:"bouton",to:{name:"app-MyModels"}},{default:k(()=>[w(l,{class:"icon",size:24,style:{"vertical-align":"bottom"}}),o(" "+m(e.$referenceStore.getString("models_my_miniatures")),1)]),_:1})])]),default:k(()=>[t[11]||(t[11]=o()),w(x,{ref:"matchedFigurines",onClose:t[1]||(t[1]=A=>e.show=!1),list:e.list,"hide-buttons":!0},null,8,["list"]),t[12]||(t[12]=o())]),_:1},8,["modelValue"])):h("",!0),t[14]||(t[14]=o()),e.support?(i(),E(f,{key:3,modelValue:e.support,"onUpdate:modelValue":t[5]||(t[5]=A=>e.support=A),noclose:"",width:"500px"},{default:k(()=>[w(F,null,{default:k(()=>[w(v)]),_:1})]),_:1},8,["modelValue"])):h("",!0)],64)}const Fo=Object.assign(Q(bo,[["render",Eo],["__scopeId","data-v-895bac65"]]),{__name:"ListsTablelistFigurineIcon"}),ko=G({components:{PopupDialog:H},props:{name:{type:String,required:!1},note:{type:String,required:!1}},data(){return{editing:!1,editedName:null,editedNote:null,support:!1}},methods:{showEditPopup(e){e.stopPropagation(),this.editing=!0,this.$nextTick(()=>{var t,n;(t=this.$refs.rename)==null||t.focus(),(n=this.$refs.rename)==null||n.select()})},save(){this.$emit("change",this.editedName,this.editedNote),this.$refs.pop.close()},init(){this.editedName=this.name||null,this.note!=null?this.editedNote=this.note:this.editedNote=null},clicked(e){this.$userStore.isSupporter()==!1&&(this.support=!0)}},computed:{popupName(){const e=[];return this.name&&e.push(this.$referenceStore.getString("lists_name").toLowerCase()),this.note&&e.push(this.$referenceStore.getString("lists_note").toLowerCase()),this.$referenceStore.getString("lists_edit_dynamic").replace("{items}",e.join(" / "))}},watch:{editing(){this.editing==!0&&this.init()}}}),Do={key:0,class:"boutons"},Ao={key:1,class:"section"},Po={class:"section boutons"};function So(e,t,n,s,a,d){const l=Pe,u=ye,g=H,c=Vt,x=be;return i(),p("div",null,[r("span",{class:"imgBt editname",onClick:t[0]||(t[0]=(...y)=>e.showEditPopup&&e.showEditPopup(...y))},[w(l,{title:e.$referenceStore.getString("lists_edit_name_note")},null,8,["title"])]),t[11]||(t[11]=o()),e.editing?(i(),E(g,{key:0,modelValue:e.editing,"onUpdate:modelValue":t[4]||(t[4]=y=>e.editing=y),x:"",noclose:"",ref:"pop",width:"500px"},{header:k(()=>[o(m(e.popupName),1)]),default:k(()=>[t[8]||(t[8]=o()),e.editedName!=null?(i(),p("div",Do,[r("label",null,m(e.$referenceStore.getString("lists_name")),1),t[6]||(t[6]=o()),P(r("input",{type:"text","onUpdate:modelValue":t[1]||(t[1]=y=>e.editedName=y),ref:"rename",minlength:"3"},null,512),[[q,e.editedName]])])):h("",!0),t[9]||(t[9]=o()),e.editedNote!=null?(i(),p("div",Ao,[r("div",null,m(e.$referenceStore.getString("lists_note")),1),t[7]||(t[7]=o()),w(u,{class:"inputlike",modelValue:e.editedNote,"onUpdate:modelValue":t[2]||(t[2]=y=>e.editedNote=y),placeholder:e.$referenceStore.getString("lists_enter_note"),onClick:e.clicked,locked:e.$userStore.isSupporter()==!1},null,8,["modelValue","placeholder","onClick","locked"])])):h("",!0),t[10]||(t[10]=o()),r("div",Po,[r("button",{class:"bouton",onClick:t[3]||(t[3]=(...y)=>e.save&&e.save(...y))},m(e.$referenceStore.getString("lists_save_close")),1)])]),_:1},8,["modelValue"])):h("",!0),t[12]||(t[12]=o()),e.support?(i(),E(g,{key:1,noclose:"",modelValue:e.support,"onUpdate:modelValue":t[5]||(t[5]=y=>e.support=y)},{default:k(()=>[w(x,null,{default:k(()=>[w(c)]),_:1})]),_:1},8,["modelValue"])):h("",!0)])}const Go=Object.assign(Q(ko,[["render",So]]),{__name:"ListsEditNameNote"}),Bo=G({mixins:[nt],components:{},setup(){return{store:te()}},props:{hidden:{type:Boolean,required:!0}},data(){return{showContent:!1}},methods:{save(){this.$emit("save")},nameChanged(e,t){var s,a;let n=!1;e&&e!=this.list.row.name&&(this.list.row.name=e,(s=this.list.army)==null||s.setCustomName(e),n=!0),t!=null&&(a=this.list)!=null&&a.army&&(this.list.row.note=t,this.list.army.setNote&&this.list.army.setNote(t),n=!0),n&&this.save()}},computed:{totalCost(){return this.army?qe(this.army):""},hasNote(){var e;return this.$userStore.isSupporter()&&((e=this.list.row.note)==null?void 0:e.trim().length)},playMode(){var e,t;return((t=(e=this.list)==null?void 0:e.row.metadata)==null?void 0:t.play_mode)===!0}}}),Qo={class:"nameCosts"},Uo={class:"nameContainer"},$o={class:"listName"},Ro=["innerHTML"],Mo={class:"errorIconDesktop"},Io={class:"listOptions"},Ho={key:0,class:"errorIconMobile"},Lo={class:"errorNum"},To={key:0,class:"listNote"};function Oo(e,t,n,s,a,d){const l=Fo,u=Go,g=X;return e.list?(i(),p("div",{key:0,class:T(["rosterSection",{hidden:e.hidden,hideOnSmallScreen:e.editingUnit==!0}])},[r("h3",{class:T(["titreForce armyHeader",{hasNote:e.hasNote}])},[r("div",{onMouseup:t[0]||(t[0]=B(c=>e.debug(e.army),["middle","stop"])),class:"listTitle"},[w(l,{list:e.list},null,8,["list"]),t[3]||(t[3]=o()),r("div",Qo,[r("div",Uo,[r("span",$o,[o(m(e.list.row.name||"No list")+" ",1),e.mode==0?(i(),E(u,{key:0,note:e.list.row.note||"",name:e.list.row.name,onChange:e.nameChanged},null,8,["note","name","onChange"])):h("",!0)])]),t[1]||(t[1]=o()),e.army&&e.totalCost?(i(),p("span",{key:0,class:"titleCosts",innerHTML:e.totalCost},null,8,Ro)):h("",!0),t[2]||(t[2]=o()),r("span",Mo,[e.list.army&&e.mode===0&&!e.playMode?(i(),E(g,{key:0,errors:e.list.army.getErrors(),source:e.list.army},null,8,["errors","source"])):h("",!0)])])],32),t[6]||(t[6]=o()),r("div",Io,[e.list.army&&e.mode===0&&!e.playMode?(i(),p("span",Ho,[w(g,{errors:e.list.army.getErrors(),source:e.list.army},null,8,["errors","source"]),t[4]||(t[4]=o()),r("label",Lo,m(e.list.army.getErrors().length)+" Errors",1)])):h("",!0),t[5]||(t[5]=o()),N(e.$slots,"default",{},void 0,!0)])],2),t[7]||(t[7]=o()),e.hasNote?(i(),p("pre",To,m(e.list.row.note),1)):h("",!0)],2)):h("",!0)}const Yo=Object.assign(Q(Bo,[["render",Oo],["__scopeId","data-v-0de711c4"]]),{__name:"ListsTablelistRosterHeader"}),No={components:{ErrorIcon:X},props:{indicator:{type:String,required:!0},list:{type:Object,required:!0},cost:{type:Boolean,default:!1}},methods:{convertIdToTitleCase(e){return e.split("_").map(t=>t.charAt(0).toUpperCase()+t.slice(1).toLowerCase()).join(" ")}},computed:{army(){return this.list.army},name(){const e=this.army.book.getReferenceDetails()[this.indicator];return e||this.convertIdToTitleCase(this.indicator)},total(){const e=this.army.childrenRestrictions.refs.get(this.indicator);return this.cost==!1?(e==null?void 0:e.getTotal(null,!0))||0:(e==null?void 0:e.getTotalCost(null,!0))||0},indicatorErrors(){var t;return(((t=this.list.army)==null?void 0:t.getErrors())||[]).filter(n=>{var s;return(s=n.refs)==null?void 0:s.includes(this.indicator)})}}},Vo={key:0},jo={class:"name"};function Wo(e,t,n,s,a,d){const l=X;return d.total>0?(i(),p("div",Vo,[r("span",jo,m(d.name),1),o(": "+m(d.total)+" ",1),d.indicatorErrors.length?(i(),E(l,{key:0,errors:d.indicatorErrors,source:n.list.army},null,8,["errors","source"])):h("",!0)])):h("",!0)}const Xo=Object.assign(Q(No,[["render",Wo],["__scopeId","data-v-1e48a865"]]),{__name:"ListsIndicator"}),zo=G({components:{Indicator:Xo,ErrorIcon:X},props:{list:{type:Object,required:!0}},methods:{total(e){let t=0;const n=this.list.army;if(!n)return 0;const s=n.childrenRestrictions.refs.get(e);if(!s||!s.getNodes(null))return 0;for(const a of s.getNodes(null))t+=a.amount*a.getAmount();return t},maxForCat(e,t,n){const s=new Set;for(const d of e.getModifiedConstraints().concat(e.getModifiedExtraConstraints()))d.source.type==="max"&&d.source.childId===t&&n(d.source.field)&&s.add(d.source.id);if(!s.size)return null;let a=null;for(const d of e.getMaxConstraints(!1,!0))d.id&&s.has(d.id)&&d.value>0&&(a===null||d.value<a)&&(a=d.value);return a},unitModelCount(e){let t=0;return e.forEach(n=>{n.isModel()&&(t+=n.amount)}),t},effectiveAmount(e){let t=e.getAmount();for(let n=e.getParent();n&&t;n=n.getParent())n.source.isEntry()&&(t*=n.getAmount());return t},bsMarkedCategories(e,t,n,s=!1){var b;if(((b=this.$systemStore.selectedSystem)==null?void 0:b.engine)!=="bs")return[];const a=this.list.army;if(!a||typeof a.getCategoryIndex!="function")return[];const d=Object.values(a.getCategoryIndex()).filter(f=>{var v;return f&&((v=f.comment)==null?void 0:v.includes(e))});if(!d.length)return[];const l=new Set(d.map(f=>f.id)),u={},g={},c={},x={};a.forEach(f=>{const v=new Set,F=f.getPrimaryCategoryId();F&&l.has(F)&&v.add(F);for(const S of f.getSecondaryCategoryIds())l.has(S)&&v.add(S);if(!v.size)return;const A=f.isUnit()?f:f.getParentUnit();if(A)for(const S of v){const W=this.maxForCat(f,S,n);if(W!=null&&(g[S]===void 0||W<g[S])&&(g[S]=W),s){u[S]=(u[S]||0)+this.effectiveAmount(f);continue}const Y=x[S]||(x[S]=new Set);Y.has(A.uid)||(Y.add(A.uid),u[S]=(u[S]||0)+t(A))}});const y=[a];for(;y.length;)for(const f of y.pop().getChildInstances())if(f.isCategory()){const v=f.source.getId();if(!l.has(v))continue;for(const A of f.getMaxConstraints(!1))n(A.field)&&A.value>0&&(g[v]===void 0||A.value<g[v])&&(g[v]=A.value);const F=c[v]||(c[v]=[]);for(const A of f.checkConstraints())F.some(S=>S.hash===A.hash)||F.push(A)}else f.isUnit()||y.push(f);return d.map(f=>({id:f.id,name:f.getName(),total:u[f.id]||0,max:g[f.id]??null,errors:c[f.id]||[]})).filter(f=>f.total>0||f.errors.length>0)}},computed:{showIndicators(){if(this.indicators){for(const e of this.indicators)if(this.total(e)!=0)return!0}if(this.costIndicators){for(const e of this.costIndicators)if(this.total(e)!=0)return!0}return!1},indicators(){var e;return((e=this.list.army)==null?void 0:e.getBook()).raw.indicators||[]},costIndicators(){var e;return((e=this.list.army)==null?void 0:e.getBook()).raw.costIndicators||[]},army(){return this.list.army},bsIndicators(){return this.bsMarkedCategories("[indicator]",e=>this.unitModelCount(e),e=>e==="selections",!0)},bsCostIndicators(){return this.bsMarkedCategories("[costIndicator]",e=>e.getPointsCost(),e=>e!=="selections")},bsCostTypeIndicators(){var s;if(((s=this.$systemStore.selectedSystem)==null?void 0:s.engine)!=="bs")return[];const e=this.list.army;if(!e||typeof e.getCostIndex!="function")return[];const t=e.getCostIndex(),n=e.getTotalCosts(!0);return Object.values(t).filter(a=>{var d;return(d=a.comment)==null?void 0:d.includes("costIndicator")}).map(a=>{var d;return{id:a.id,name:a.name,total:((d=n[a.id])==null?void 0:d.value)||0,max:null,errors:[]}})},bsAllIndicators(){return[...this.bsIndicators,...this.bsCostIndicators,...this.bsCostTypeIndicators]}}}),Zo={key:0,ref:"listDiv",class:"indicators"},Ko={key:1,class:"indicators"},Jo={class:"name"};function qo(e,t,n,s,a,d){const l=R("Indicator"),u=X;return e.list&&e.list.army&&e.army.childrenRestrictions&&e.showIndicators?(i(),p("div",Zo,[(i(!0),p(C,null,D(e.indicators,(g,c)=>(i(),E(l,{key:`indicator${c}`,indicator:g,list:e.list},null,8,["indicator","list"]))),128)),t[0]||(t[0]=o()),(i(!0),p(C,null,D(e.costIndicators,(g,c)=>(i(),E(l,{key:`cost${c}`,indicator:g,list:e.list,cost:!0},null,8,["indicator","list"]))),128))],512)):e.bsAllIndicators.length?(i(),p("div",Ko,[(i(!0),p(C,null,D(e.bsAllIndicators,g=>(i(),p("div",{key:g.id},[r("span",Jo,m(g.name),1),t[1]||(t[1]=o(`:
      `,-1)),r("span",{class:T({error:g.max!=null&&g.total>g.max})},[o(m(g.total),1),g.max!=null?(i(),p(C,{key:0},[o("/"+m(g.max),1)],64)):h("",!0)],2),t[2]||(t[2]=o()),g.errors.length?(i(),E(u,{key:0,errors:g.errors,source:e.list.army},null,8,["errors","source"])):h("",!0)]))),128))])):h("",!0)}const _o=Object.assign(Q(zo,[["render",qo],["__scopeId","data-v-b5fb7da9"]]),{__name:"ListsIndicators"}),er=On("ui",{state:()=>({"roster-left":400,"roster-right":400}),persist:{storage:Yn},actions:{get(e,t){return this.$state[`${e}-${t}`]},set(e,t,n){this.$state[`${e}-${t}`]=n}}});function tr(e){const t=e.getBoundingClientRect();return{left:t.left+window.scrollX,top:t.top+window.scrollY}}const nr={props:{showLeft:{type:Boolean,default:!0},showMiddle:{type:Boolean,default:!1},showRight:{type:Boolean,default:!1},draggable:{type:Boolean,default:!1},leftWidth:{type:[String,Number],default:"auto"},rightWidth:{type:[String,Number],default:"auto"},clamp:{type:Number,default:250},id:{type:String,required:!0},loaded:{type:Boolean,default:!1}},data(){return{leftWidthPx:typeof this.leftWidth=="number"?this.leftWidth:0,rightWidthPx:typeof this.rightWidth=="number"?this.rightWidth:0,height:0,staticLeft:!1,staticRight:!1}},setup(){return{store:er()}},mounted(){var e,t;if(typeof this.leftWidth=="number"&&this.leftWidth)this.leftWidthPx=this.leftWidth,this.staticLeft=!0;else if(this.draggable&&!this.loaded){if(this.id){const n=this.store.get(this.id,"left");n&&(this.leftWidthPx=n)}if(!this.leftWidthPx&&this.$refs.left&&((e=this.$refs.left)!=null&&e.offsetWidth)&&(this.leftWidthPx=this.$refs.left.offsetWidth),this.leftWidthPx<this.clamp&&(this.leftWidthPx=this.do_clamp(typeof this.leftWidth=="number"?this.leftWidth:0)),this.id&&!this.loaded){const n=this.store.get(this.id,"right");n&&(this.rightWidthPx=n)}!this.rightWidthPx&&((t=this.$refs.right)!=null&&t.offsetWidth)&&(this.rightWidthPx=this.$refs.right.offsetWidth),this.rightWidthPx<this.clamp&&(this.rightWidthPx=this.do_clamp(typeof this.rightWidth=="number"?this.rightWidth:0))}addEventListener("resize",this.update),this.$nextTick(this.update),setTimeout(this.update,0)},unmounted(){removeEventListener("resize",this.update)},updated(){this.update()},computed:{left_draggable(){return this.staticLeft?!1:this.draggable&&this.showLeft&&(this.showMiddle||this.showRight)},right_draggable(){return this.draggable&&this.showMiddle&&this.showRight},left(){var e;return((e=this.$el)==null?void 0:e.offsetLeft)||0},leftw(){return this.leftWidthPx-this.left},right(){var e;return((e=this.$el)==null?void 0:e.offsetRight)||0},rightw(){return this.rightWidthPx-this.right},totalWidth(){return this.$el.clientWidth}},watch:{leftWidth(e){typeof e!="string"&&(e||(this.leftWidthPx=this.store.get(this.id,"left")||100,this.staticLeft=!1),e&&(this.leftWidthPx=e,this.staticLeft=!0))}},methods:{update(){var t;const e=(t=tr(this.$el))==null?void 0:t.top;this.height=innerHeight-e},do_clamp(e){return e<this.clamp?this.clamp:e>this.totalWidth-this.clamp?this.totalWidth-this.clamp:e},get_client_x(e){return e.touches?e.touches[0].clientX??0:e.clientX??0},async drag_left_handle(e,t=!1){const n=this.leftWidthPx,s=this.get_client_x(e),a=l=>{const u=this.get_client_x(l)-s;this.leftWidthPx=this.do_clamp(n+u)};addEventListener(t?"touchmove":"mousemove",a);const d=()=>{removeEventListener(t?"touchmove":"mousemove",a),this.$nextTick(()=>{this.id&&this.store.set(this.id,"left",this.leftWidthPx)})};addEventListener(t?"touchend":"mouseup",d,{once:!0,capture:!0})},async drag_right_handle(e,t=!1){const n=this.rightWidthPx,s=this.get_client_x(e),a=l=>{const u=this.get_client_x(l)-s;this.rightWidthPx=this.do_clamp(n-u)};addEventListener(t?"touchmove":"mousemove",a);const d=()=>{removeEventListener(t?"touchmove":"mousemove",a),this.$nextTick(()=>{this.id&&this.store.set(this.id,"right",this.rightWidthPx)})};addEventListener(t?"touchend":"mouseup",d,{once:!0,capture:!0})}}},sr={key:1,ref:"middle",class:"middle grow relative"};function or(e,t,n,s,a,d){return i(),p("div",{class:"splitView",style:oe(a.height>0?{height:`calc(${a.height-2}px - var(--mainContentBottom, 0px)`}:{})},[P(r("div",{class:"left relative",ref:"left",style:oe({width:d.leftw>0?`${d.leftw}px`:n.leftWidth})},[N(e.$slots,"left",{},void 0,!0)],4),[[K,n.showLeft]]),t[4]||(t[4]=o()),d.left_draggable?(i(),p("div",{key:0,class:"between unselectable",onMousedown:t[0]||(t[0]=(...l)=>d.drag_left_handle&&d.drag_left_handle(...l)),onTouchstartPassive:t[1]||(t[1]=l=>d.drag_left_handle(l,!0))},null,32)):h("",!0),t[5]||(t[5]=o()),n.showMiddle?(i(),p("div",sr,[N(e.$slots,"middle",{},void 0,!0)],512)):h("",!0),t[6]||(t[6]=o()),d.right_draggable?(i(),p("div",{key:2,class:"between unselectable",onMousedown:t[2]||(t[2]=(...l)=>d.drag_right_handle&&d.drag_right_handle(...l)),onTouchstartPassive:t[3]||(t[3]=l=>d.drag_right_handle(l,!0))},null,32)):h("",!0),t[7]||(t[7]=o()),P(r("span",{ref:"right",class:"right relative",style:oe({width:`${d.rightw}px`})},[N(e.$slots,"right",{},void 0,!0)],4),[[K,n.showRight]])],4)}const rr=Object.assign(Q(nr,[["render",or],["__scopeId","data-v-01078a77"]]),{__name:"SplitView"}),ir=G({name:"OpenCloseButton",props:{modelValue:{default:!1,type:Boolean}},data(){return{content:this.modelValue}},methods:{toggle(){this.content=!this.content,this.$emit("update:modelValue",this.content),this.content?this.$emit("open"):this.$emit("close")}},watch:{modelValue(e){this.content=e}}});function ar(e,t,n,s,a,d){const l=Bt,u=We;return i(),p("span",{class:"imgBt",onClick:t[0]||(t[0]=B(g=>e.toggle(),["stop"]))},[e.content?(i(),E(l,{key:0,title:"Hide Profiles"})):(i(),E(u,{key:1,title:"View Profiles"}))])}const zt=Object.assign(Q(ir,[["render",ar],["__scopeId","data-v-200934de"]]),{__name:"OpenCloseButton"}),lr=G({emits:["list-change","force-added","preset-created"],components:{OpenCloseButton:zt,PopupDialog:H,UnitProfiles:Ue,BsProfileTables:Qs,ErrorIcon:X},props:{book:{type:Object,required:!0},force:{type:Object,required:!0},unit:{type:Object,required:!0},childforce:{type:Boolean,default:!1},name:{type:String},costs:{type:Array,required:!1},errors:{type:Array,required:!1},parent:{type:Object,required:!0},config:{type:Boolean,default:!1}},setup(){return{store:te()}},computed:{bs(){return this.book.getSystem().engine==="bs"},forceSource(){if(!this.childforce)return null;const e=this.unit,t=e instanceof it?e.state.source:e;return t instanceof jn&&t.isForce()?t:null},forceProfiles(){return this.forceSource?[...this.forceSource.profilesIterator()]:[]},forceRules(){return this.forceSource?[...this.forceSource.rulesIterator()]:[]},forceSystem(){var n;const e=this.forceSource;if(!e)return;const t=e.target??e;return(n=e.getCatalogue()??t.main_catalogue)==null?void 0:n.getSystem()},showEye(){return this.childforce?this.forceProfiles.length>0||this.forceRules.length>0:!0},hasPresets(){const e=Ht(this.$optionStore.options,this.book.getSystem().id,this.unit.id);return e?!!Object.keys(e).length:!1},miniatureImageId(){return!this.$optionStore.options.showUnitImagesAddView||!this.$userStore.isSupporter()||this.$userStore.windowWidth>770||this.childforce?null:this.$figurineStore.getBookUnitImageId(this.book.getSystem().id,this.unit,this.book)},startingCosts(){if(this.costs)return He(this.costs);const e=this.unit;return"getStartingCosts"in e&&e.getStartingCosts?He(e.getStartingCosts()):""},constraints(){const e=this.unit;if(!e.isForce||e.isForce()){const l=this.parent.getForces(!1).filter(u=>u.source.id===this.unit.id).length;return l?`(${l})`:""}const t=[],n=new Set,s=e.getMinConstraints(!1,!1).filter(l=>l.value>0&&l.field==="selections"&&(l.amount||0)<l.value);if(s.length)for(const l of s)t.push(`<span class="error">(${l.amount}/${l.value})</span>`),n.add(l.value);const a=e.getMaxConstraints(!1,!0).filter(l=>l.value!=-1&&l.field==="selections");if(a.length){Ie(a,l=>l.amount||0),Ie(a,l=>l.value-(l.amount||0));for(const l of a){if(n.has(l.value))continue;const u=`${l.amount}/${l.value}${l.field==="selections"?"":l.cost}`;(l.amount||0)>l.value?t.push(`<span class="error">(${u})</span>`):t.push(`<span>(${u})</span>`)}}if(t.length)return t.join(" ");const d=e.getAmount();return d?`(${d})`:""},t9aconstraints(){try{let e=this.parent;e.isForce()&&(e=e.getParentRoster());let t=0,n=null,s=null;const a=e;for(const l of a.getForces())for(const u of l.getCategories())for(const g of u.getUnits())g.getId()===this.unit.id&&(n=g.field("armyHasNotOption"),s=g.field("refs"),t++);let d=0;if(n&&s)for(const l of s){const u=n.find(g=>g.refs.includes(l));if(u){d=a.calcConditionAmount(u,"armyHasNotOption");break}}return d?` (${t}/${d})`:t?` (${t})`:""}catch{return""}}},data(){return{profileOpen:!1,supportPreset:!1}},methods:{debug(e){const t=e;console.log(t.getName&&t.getName(),e),globalThis.$debugOption=e,globalThis.$debugForce=this.force},createUnit(e,t){this.doCreateUnit(!0,e,t)},createUnitNoProfile(e,t){this.doCreateUnit(!1,e,t)},async doCreateUnit(e,t,n){if(this.childforce){this.createForce();return}const s=t,a=n;if(this.config){const u=this.findExistingConfigurationUnit(s,a);if(u){e&&(this.store.setEditedUnit(u),await new Promise(g=>setTimeout(g,1)),this.$router.replace({query:{view:u.uid}}));return}}const d=Nn(this.$optionStore.options,this.book.getSystem().id,a.id);if(d){const u=new Ge;u.logOwnUnitWarnings=!1;const g=s.insertUnit(u,a,d.options);g==null?this.$showMessages(u.errorStack):(u.logWarnings&&this.$showMessages(u.warningStack),e&&(this.store.setEditedUnit(g),await new Promise(c=>setTimeout(c,1)),this.$router.replace({query:{view:g.uid}})),this.$emit("list-change"));return}const l=Vn(s,a);l.unit&&(e&&(this.store.setEditedUnit(l.unit),await new Promise(u=>setTimeout(u,1)),this.$router.replace({query:{view:l.unit.uid}})),this.$emit("list-change")),l.messages.length&&this.$showMessages(l.messages)},createForce(){this.$emit("force-added")},translate(e,t){var s;const n=t??(e instanceof it?e.name:((s=e==null?void 0:e.getName)==null?void 0:s.call(e))??(e==null?void 0:e.name));return this.book&&this.book instanceof Bs?this.book.getTranslatedUnitName(e):n},createFromPreset(e,t){this.$userStore.isSupporter()?this.$emit("preset-created",e,t):this.supportPreset=!0},findExistingConfigurationUnit(e,t){var s;const n=e.getParentRoster();if(!n)return null;for(const a of n.getForces())for(const d of a.getCategories())if((s=this.book.getSystem().settings.configurationCategories)!=null&&s.includes(d.getName())){const u=d.getUnits().find(g=>g.getId()===t.id);if(u)return u}return null}}}),dr={class:"units"},pr={class:"unit-top-row"},ur={key:0,class:"mobile eyeButton"},cr=["innerHTML"],gr={class:"name"},fr=["innerHTML"],mr={class:"right"},hr={class:"icons"},xr=["title"],br={class:"desktop eyeButton imgBt"},yr=["title"],vr=["innerHTML"],wr={key:1,class:"mobile eyeButton mobileEyeButton"};function Cr(e,t,n,s,a,d){var A;const l=jt,u=zt,g=X,c=wn,x=Xe,y=R("BsProfileTables"),b=R("UnitProfiles"),f=H,v=Ps,F=be;return i(),p("div",{class:T(["unselectable hover-darken clickable unit-wrap",{newui:e.$optionStore.options.newMobileUi,"has-image":e.miniatureImageId}]),onMouseup:t[8]||(t[8]=B(S=>e.debug(e.unit),["middle","prevent","stop"])),onClick:t[9]||(t[9]=S=>e.createUnit(e.force,e.unit)),onContextmenu:t[10]||(t[10]=B(S=>e.createUnitNoProfile(e.force,e.unit),["prevent"]))},[e.miniatureImageId?(i(),E(l,{key:0,picture:e.miniatureImageId,altText:e.translate(e.unit,e.name),class:"unit-miniature-thumb"},null,8,["picture","altText"])):h("",!0),t[22]||(t[22]=o()),r("div",dr,[r("div",pr,[e.miniatureImageId?h("",!0):(i(),p("span",ur,[e.showEye?(i(),E(u,{key:0,modelValue:e.profileOpen,"onUpdate:modelValue":t[0]||(t[0]=S=>e.profileOpen=S),class:"imgBt"},null,8,["modelValue"])):h("",!0)])),t[11]||(t[11]=o()),r("span",{class:"costs desktop",innerHTML:e.startingCosts},null,8,cr),t[12]||(t[12]=o()),r("span",gr,m(e.translate(e.unit,e.name)),1),t[13]||(t[13]=o()),r("span",{class:"constraint gray",innerHTML:e.bs?e.constraints:e.t9aconstraints},null,8,fr),t[14]||(t[14]=o()),(A=e.errors)!=null&&A.length?(i(),E(g,{key:1,errors:e.errors,source:e.unit},null,8,["errors","source"])):h("",!0)]),t[15]||(t[15]=o()),t[16]||(t[16]=r("div",{class:"unit-bottom-row"},null,-1))]),t[23]||(t[23]=o()),r("div",mr,[r("div",hr,[e.hasPresets?(i(),p("div",{key:0,title:e.$referenceStore.getString("lists_bookunit_create_favourite"),class:"imgBt plus addButton",onClick:t[1]||(t[1]=B(S=>e.createFromPreset(e.force,e.unit),["stop"]))},[w(c,{class:"icon fav"})],8,xr)):h("",!0),t[17]||(t[17]=o()),r("div",br,[e.showEye?(i(),E(u,{key:0,modelValue:e.profileOpen,"onUpdate:modelValue":t[2]||(t[2]=S=>e.profileOpen=S)},null,8,["modelValue"])):h("",!0)]),t[18]||(t[18]=o()),r("div",{onClick:t[3]||(t[3]=B(S=>e.createUnitNoProfile(e.force,e.unit),["stop"])),title:e.$referenceStore.getString("lists_bookunit_create_unit"),class:"unselectable plus imgBt addButton"},[w(x,{size:24,"stroke-mult":1.25})],8,yr)]),t[19]||(t[19]=o()),e.childforce?h("",!0):(i(),p("div",{key:0,class:"costs mobile mobileCosts",innerHTML:e.startingCosts},null,8,vr)),t[20]||(t[20]=o()),e.miniatureImageId?(i(),p("span",wr,[e.showEye?(i(),E(u,{key:0,modelValue:e.profileOpen,"onUpdate:modelValue":t[4]||(t[4]=S=>e.profileOpen=S),class:"imgBt"},null,8,["modelValue"])):h("",!0)])):h("",!0)]),t[24]||(t[24]=o()),e.profileOpen?(i(),E(f,{key:1,modelValue:e.profileOpen,"onUpdate:modelValue":t[6]||(t[6]=S=>e.profileOpen=S),text:e.$referenceStore.getString("lists_close"),width:"1200px",x:"",noclose:"",notitlebar:"",xtop:"10px",xright:"10px"},{default:k(()=>[e.forceSource?(i(),p(C,{key:0},[r("h3",null,m(e.translate(e.unit,e.name)),1),t[21]||(t[21]=o()),w(y,{profiles:e.forceProfiles,rules:e.forceRules,first:e.book.getSystem().settings.profileFilter,order:e.book.getSystem().settings.profilesOrder,system:e.forceSystem,source:e.forceSource,state:e.$optionStore.profileTypeStates},null,8,["profiles","rules","first","order","system","source","state"])],64)):(i(),E(b,{key:1,preview:"",unit:e.unit,onClose:t[5]||(t[5]=S=>e.profileOpen=!1)},null,8,["unit"]))]),_:1},8,["modelValue","text"])):h("",!0),t[25]||(t[25]=o()),e.supportPreset?(i(),E(f,{key:2,modelValue:e.supportPreset,"onUpdate:modelValue":t[7]||(t[7]=S=>e.supportPreset=S),noclose:""},{default:k(()=>[w(F,null,{default:k(()=>[w(v)]),_:1})]),_:1},8,["modelValue"])):h("",!0)],34)}const Re=Object.assign(Q(lr,[["render",Cr],["__scopeId","data-v-ac623017"]]),{__name:"ListsBookUnit"}),Er=G({emits:["add"],props:{rows:{type:Array,required:!0},book:{type:Object,required:!0}}}),Fr={class:"forces"};function kr(e,t,n,s,a,d){const l=Re;return i(),p("div",Fr,[(i(!0),p(C,null,D(e.rows,u=>(i(),E(l,{key:u.force.id,class:"force hover-darken clickable",childforce:"",unit:u.force,book:e.book,force:u.state,name:u.name,costs:u.state.getCosts(),errors:u.state.getErrors().filter(g=>{var c;return((c=g.constraint)==null?void 0:c.type)==="min"}),parent:u.parent,onForceAdded:g=>e.$emit("add",u)},null,8,["unit","book","force","name","costs","errors","parent","onForceAdded"]))),128))])}const Dr=Object.assign(Q(Er,[["render",kr],["__scopeId","data-v-f3d69311"]]),{__name:"ListsAddForceList"}),Ar=G({components:{CollapsibleBox:ne},emits:["add"],props:{availableForces:{type:Array,required:!0},book:{type:Object,required:!0}},computed:{flatRows(){const e=this.book.getId(),t=[];for(const n of this.availableForces)for(const s of n.grouped)for(const a of s.forces)t.push({force:a.force,state:a.state,book:s.book,parent:n.parent,name:a.name,parentUid:n.force.getUid(),parentLabel:n.force.getChildForcesLabel(),parentName:n.force.getCustomName()||n.force.getName(),isOwn:s.book.id===e});return t},factionGroups(){const e=new Map,t=new Map,n=new Set;for(const s of this.flatRows){const a=s.book.id+"|"+s.parentUid,d=a+"|"+s.force.getId();if(n.has(d))continue;n.add(d);let l=e.get(s.book.id);l||(l={book:s.book,isOwn:s.isOwn,count:0,parents:[]},e.set(s.book.id,l));let u=t.get(a);u||(u=[],t.set(a,u),l.parents.push({uid:s.parentUid,label:s.parentLabel,name:s.parentName,rows:u})),u.push(s),l.count++}return[...e.values()].sort((s,a)=>s.isOwn===a.isOwn?this.bookName(s.book).localeCompare(this.bookName(a.book)):s.isOwn?-1:1)}},methods:{isExpanded(e){return e.isOwn||this.factionGroups.length===1},bookName(e){return this.$referenceStore.getTranslatedName(e.name,e,this.book.getSystem())}}}),Pr={class:"unselectable"},Sr={class:"bold"},Gr={class:"gray"},Br={class:"bold"},Qr={key:0,class:"gray"};function Ur(e,t,n,s,a,d){const l=Dr,u=ne;return i(),p("div",Pr,[(i(!0),p(C,null,D(e.factionGroups,g=>(i(),E(u,{nobox:"",class:"faction",key:g.book.id,defcollapsed:!e.isExpanded(g)},{title:k(()=>[r("span",Sr,m(e.bookName(g.book)),1),t[2]||(t[2]=o()),r("span",Gr," ("+m(g.count)+")",1)]),content:k(()=>[g.parents.length===1?(i(),E(l,{key:0,rows:g.parents[0].rows,book:e.book,onAdd:t[0]||(t[0]=c=>e.$emit("add",c))},null,8,["rows","book"])):(i(!0),p(C,{key:1},D(g.parents,c=>(i(),p("div",{class:"parent",key:c.uid},[r("div",Br,[o(m(c.label)+" ",1),c.name?(i(),p("span",Qr," in "+m(c.name),1)):h("",!0)]),t[3]||(t[3]=o()),w(l,{rows:c.rows,book:e.book,onAdd:t[1]||(t[1]=x=>e.$emit("add",x))},null,8,["rows","book"])]))),128))]),_:2},1032,["defcollapsed"]))),128))])}const $r=Object.assign(Q(Ar,[["render",Ur],["__scopeId","data-v-93ba90dd"]]),{__name:"ListsAddForceNested"}),Rr=G({props:{system:Object,modelValue:[Object,null],default:Object},data(){return{selectedBook:null}},computed:{books(){if(this.system==null)return null;const e=this.system.books.array.filter(t=>t.playable);return e.length?e:this.system.books.array.length?this.system.books.array:null}},watch:{system(){this.init()}},created(){let e=null;this.default!=null&&this.books&&(e=this.books.find(t=>t.id===this.default.getId())),e?(this.selectedBook=e,this.bookSelected()):this.init()},methods:{init(){this.books&&(this.selectedBook=this.books[0],this.bookSelected())},async bookSelected(){this.selectedBook&&this.$emit("update:modelValue",this.selectedBook)},getTranslatedName(e){return this.$referenceStore.getTranslatedName(e.name,e,this.system)}}}),Mr=["value"];function Ir(e,t,n,s,a,d){return e.books?P((i(),p("select",{key:0,"onUpdate:modelValue":t[0]||(t[0]=l=>e.selectedBook=l),onChange:t[1]||(t[1]=(...l)=>e.bookSelected&&e.bookSelected(...l))},[(i(!0),p(C,null,D(e.books,l=>(i(),p("option",{key:l.id,value:l},m(e.getTranslatedName(l)),9,Mr))),128))],544)),[[Qt,e.selectedBook]]):h("",!0)}const Hr=Object.assign(Q(Rr,[["render",Ir]]),{__name:"ListsBooks"});function Lr(e){const t=[];for(const n of e.getForces(!0)){const s=n.getAvailableVisibleChildForces();s.length&&t.push({force:n,parent:n.getParentForce(),grouped:Object.values(Ke(s,a=>a.book.name)).map(a=>({book:a[0].book,forces:a}))})}return t}const Tr=G({components:{PopupDialog:H,Books:Hr},emits:["force-added","update:modelValue"],props:{roster:{type:Object,required:!0},book:{type:Object,required:!0},booksDate:{type:Object},modelValue:{type:Boolean,required:!0},nested:{type:Boolean,required:!1}},data:()=>({newForceBook:null,newForce:null,forces:[],addingForce:!1,availableForces:[]}),setup(){return{store:te()}},created(){this.addingForce=this.modelValue,this.availableForces=Lr(this.roster)},computed:{system(){return this.book.getSystem()},typedForces(){return this.forces},typedAvailableForces(){return this.availableForces},sections(){return this.typedAvailableForces.map(e=>{var t;return{force:e.force,parent:e.parent,rows:((t=e.grouped.find(n=>n.book===this.newForceBook))==null?void 0:t.forces)||[]}}).filter(e=>e.rows.length)}},methods:{closed(){this.$emit("update:modelValue",!1)},onAddChild(e){this.addChildForce(e.book,e.parent,e.force.getId())},async getForces(){var t;return await this.roster.getReactiveAvailableForces((t=this.newForceBook)==null?void 0:t.bsid,this.booksDate)},async addForce(e,t){if(!e)return;const n=await this.system.getBook(e.id),s=await this.roster.insertForce(n,t.id);this.applyPresets(s),this.addingForce=!1,this.$emit("update:modelValue",!1),this.$emit("force-added",s)},async addChildForce(e,t,n){const s=new Ge;s.logOwnUnitWarnings=!1;const a=this.booksDate,d=await this.system.getBook(e.id,a);let l=null;d&&(l=d);const u=t.insertForce(l,n);u==null?this.$mainStore.errorManager.notifyLastError(s.errorStack):(s.logWarnings&&this.$showMessages(s.warningStack),this.applyPresets(u)),this.addingForce=!1,this.$emit("update:modelValue",!1),this.$emit("force-added",u)},applyPresets(e){e&&Lt(this.$optionStore.options,this.system.id,e)}},watch:{async newForceBook(){var e;this.forces=(e=await this.getForces())==null?void 0:e.filter(t=>!t.state.hidden),this.newForce=this.forces[0]??null}}}),Or={key:0,class:"unselectable"},Yr={class:"faction"},Nr={key:0,class:"forces"},Vr={class:"bold"},jr={class:"gray"},Wr={key:0},Xr={class:"forces"};function zr(e,t,n,s,a,d){const l=$r,u=R("Books"),g=Re,c=H;return e.addingForce?(i(),E(c,{key:0,modelValue:e.addingForce,"onUpdate:modelValue":t[1]||(t[1]=x=>e.addingForce=x),onClose:e.closed,width:e.nested?"480px":void 0},{default:k(()=>[e.system.short!="t9a"?(i(),p("div",Or,[e.nested?(i(),E(l,{key:0,"available-forces":e.typedAvailableForces,book:e.book,onAdd:e.onAddChild},null,8,["available-forces","book","onAdd"])):(i(),p(C,{key:1},[r("div",Yr,[t[2]||(t[2]=r("div",{class:"bold"},"Faction",-1)),t[3]||(t[3]=o()),w(u,{class:"faction-select",modelValue:e.newForceBook,"onUpdate:modelValue":t[0]||(t[0]=x=>e.newForceBook=x),system:e.book.getSystem(),default:e.book},null,8,["modelValue","system","default"]),t[4]||(t[4]=o()),e.forces?(i(),p("div",Nr,[(i(!0),p(C,null,D(e.typedForces,x=>(i(),E(g,{key:x.id,class:"force hover-darken clickable",childforce:"",unit:x,book:e.book,force:x,costs:x.state.getCosts(),onForceAdded:y=>e.addForce(e.newForceBook,x),parent:e.roster},null,8,["unit","book","force","costs","onForceAdded","parent"]))),128))])):h("",!0)]),t[8]||(t[8]=o()),(i(!0),p(C,null,D(e.sections,({force:x,parent:y,rows:b})=>(i(),p("div",{class:"faction",key:x.id},[r("div",Vr,[o(m(x.getChildForcesLabel())+" ",1),r("span",jr,[t[5]||(t[5]=o(`
              in
              `,-1)),x.getCustomName()?(i(),p("span",Wr,m(x.getCustomName())+" - ",1)):h("",!0),t[6]||(t[6]=o()),r("span",null,m(x.getName()),1)])]),t[7]||(t[7]=o()),r("div",Xr,[(i(!0),p(C,null,D(b,f=>(i(),E(g,{key:f.force.id,class:"force hover-darken clickable",childforce:"",unit:f.force,book:e.book,force:f.force,costs:f.state.getCosts(),errors:f.state.getErrors().filter(v=>{var F;return((F=v.constraint)==null?void 0:F.type)==="min"}),onForceAdded:v=>e.addChildForce(f.book,y,f.force.getId()),parent:e.roster},null,8,["unit","book","force","costs","errors","onForceAdded","parent"]))),128))])]))),128))],64))])):h("",!0)]),_:1},8,["modelValue","onClose","width"])):h("",!0)}const Zr=Object.assign(Q(Tr,[["render",zr],["__scopeId","data-v-d89950db"]]),{__name:"ListsAddForce"}),Kr=G({props:{progress:{type:Number,default:0},progress_max:{type:Number,default:0},progress_msg:{type:String,default:""},mode:{type:String,default:"height"}},watch:{async progress_msg(){return await new Promise(e=>setTimeout(e,10))}}}),Jr={key:0,style:{width:"100%",position:"absolute",top:"45%",margin:"auto"}},qr={style:{margin:"auto","align-items":"center",display:"flex","flex-direction":"column"}},_r={style:{"align-items":"center",display:"flex"}},ei={style:{"margin-left":"5px"}},ti={key:0,style:{"text-align":"center"}},ni={key:1},si={key:1,style:{height:"100%"}},oi={style:{display:"flex","align-items":"center",height:"100%"}},ri={style:{margin:"auto","align-items":"center",display:"flex","flex-direction":"column"}},ii={style:{"align-items":"center",display:"flex"}},ai={style:{"margin-left":"5px"}},li={key:0,style:{"text-align":"center"}},di={key:1};function pi(e,t,n,s,a,d){var l,u;return e.mode==="absolute"?(i(),p("div",Jr,[r("div",qr,[r("div",_r,[t[0]||(t[0]=r("img",{class:"icon",src:gt,style:{width:"20px",height:"20px"}},null,-1)),t[1]||(t[1]=o()),r("span",ei,m(((l=e.$referenceStore)==null?void 0:l.getString("shared_loading_text"))||"Loading..."),1)]),t[3]||(t[3]=o()),r("div",null,[e.progress_max?(i(),p("div",ti,m(e.progress)+"/"+m(e.progress_max),1)):h("",!0),t[2]||(t[2]=o()),e.progress_msg?(i(),p("div",ni,m(e.progress_msg),1)):h("",!0)])])])):(i(),p("div",si,[r("div",oi,[r("div",ri,[r("div",ii,[t[4]||(t[4]=r("img",{class:"icon",src:gt,style:{width:"20px",height:"20px"}},null,-1)),t[5]||(t[5]=o()),r("span",ai,m(((u=e.$referenceStore)==null?void 0:u.getString("shared_loading_text"))||"Loading..."),1)]),t[7]||(t[7]=o()),r("div",null,[e.progress_max?(i(),p("div",li,m(e.progress)+"/"+m(e.progress_max),1)):h("",!0),t[6]||(t[6]=o()),e.progress_msg?(i(),p("div",di,m(e.progress_msg),1)):h("",!0)])])])]))}const Me=Object.assign(Q(Kr,[["render",pi]]),{__name:"Loading"}),ui=G({components:{PopupDialog:H},props:{force:{type:Object,required:!0},editable:{type:Boolean,default:!1},costs:{type:Boolean,default:!0},playMode:{type:Boolean,default:!1}},setup(){return{store:te()}},data(){return{renaming:!1,profileOpen:!1}},methods:{editName(e){e.stopPropagation(),this.renaming=!this.renaming,this.renaming&&this.$nextTick(()=>{var t,n;(t=this.$refs.rename)==null||t.focus(),(n=this.$refs.rename)==null||n.select()}),this.renaming==!1&&this.$emit("save")}},computed:{forceName:{get(){return this.force.getCustomName()??""},set(e){this.force.setCustomName(e)}},army(){return this.force.getParentRoster()},t9a(){return this.force.getBook().getSystem().engine==="t9a"},customName(){return this.force.getCustomName()},parentCatalogue(){if(this.force.getBook().getSystem().engine=="bs"&&this.army.hasMultipleCatalogues()){const e=this.force.catalogueName||this.force.getBook().getName();if(e)return e.replace(" - Adeptus Astartes - "," - ")}return this.force.getBook().getName().replace(" - Adeptus Astartes - "," - ")},book(){return this.force.getBook()},selectedSystem(){return this.force.getBook().getSystem()},errors(){return this.force.getErrors()},cost(){return qe(this.force)}}}),ci={class:"forceName"},gi={class:"bold"},fi=["innerHTML"],mi={class:"extraName"};function hi(e,t,n,s,a,d){const l=Hs,u=X,g=ye,c=Vt,x=be,y=H,b=Pe,f=We,v=Ue;return i(),p("div",ci,[r("span",null,[e.book.getId()?(i(),E(l,{key:0,system:e.selectedSystem,id_book:e.book.getId(),deficon:!0,wrapdefault:!1,deficonpath:"/assets/icons/force2.svg",class:"bookIcon"},null,8,["system","id_book"])):h("",!0),t[11]||(t[11]=o()),e.playMode?h("",!0):(i(),E(u,{key:1,errors:e.errors,source:e.force},null,8,["errors","source"])),t[12]||(t[12]=o()),r("span",gi,m(e.parentCatalogue),1),t[13]||(t[13]=o()),e.costs&&e.cost.length?(i(),p("span",{key:2,class:"titleCosts",innerHTML:e.cost},null,8,fi)):h("",!0),t[14]||(t[14]=o()),r("div",null,[e.renaming?(i(),p(C,{key:0},[e.$userStore.isSupporter()?(i(),p(C,{key:0},[e.renaming?(i(),E(g,{key:0,single:"",class:"inputlike",style:{display:"inline-block"},modelValue:e.forceName,"onUpdate:modelValue":t[0]||(t[0]=F=>e.forceName=F),ref:"rename",type:"text",onClick:t[1]||(t[1]=B(()=>{},["stop"])),onDone:e.editName},null,8,["modelValue","onDone"])):h("",!0)],64)):(i(),p(C,{key:1},[e.renaming?(i(),E(y,{key:0,modelValue:e.renaming,"onUpdate:modelValue":t[3]||(t[3]=F=>e.renaming=F),noclose:""},{default:k(()=>[w(x,{onClose:t[2]||(t[2]=F=>e.renaming=!1)},{default:k(()=>[w(c)]),_:1})]),_:1},8,["modelValue"])):h("",!0)],64))],64)):(i(),p(C,{key:1},[r("span",mi,[!e.t9a&&e.customName?(i(),p(C,{key:0},[o(m(e.customName)+" - ",1)],64)):h("",!0),o(m(e.force.getName()),1)]),t[8]||(t[8]=o()),e.editable&&!e.t9a?(i(),p("span",{key:0,class:"imgBt editname inline",onClick:t[4]||(t[4]=(...F)=>e.editName&&e.editName(...F))},[w(b,{title:e.$referenceStore.getString("lists_force_edit_name"),style:{"vertical-align":"bottom"}},null,8,["title"])])):h("",!0)],64)),t[10]||(t[10]=o()),e.t9a?h("",!0):(i(),p(C,{key:2},[r("span",{class:"imgBt",style:{display:"inline-block","vertical-align":"middle"},onClick:t[5]||(t[5]=B(F=>e.profileOpen=!e.profileOpen,["stop"]))},[w(f)]),t[9]||(t[9]=o()),e.profileOpen?(i(),E(y,{key:0,modelValue:e.profileOpen,"onUpdate:modelValue":t[7]||(t[7]=F=>e.profileOpen=F),text:e.$referenceStore.getString("lists_close"),width:"1200px"},{default:k(()=>[w(v,{unit:e.force,onClose:t[6]||(t[6]=F=>e.profileOpen=!1),all:!1},null,8,["unit"])]),_:1},8,["modelValue","text"])):h("",!0)],64))])])])}const Zt=Object.assign(Q(ui,[["render",hi],["__scopeId","data-v-31722e66"]]),{__name:"ListsForceName"});function Kt(e,t){if(t instanceof Be){const n=t.getMaxConstraints(!1).filter(l=>l.field==="selections"),s=Wn(n,l=>l.value);if(s&&s.value>=0)return(s.amount??0)>s.value?`<span class="error">(${s.amount}/${s.value})</span>`:`(${s.amount}/${s.value})`;const a=t.getMinConstraints(!1).filter(l=>l.field==="selections"),d=Xn(a,l=>l.value);if(d&&d.value>0)return(d.amount||0)<d.value?`<span class="error">(${d.amount}/${d.value})</span>`:""}else if((e==null?void 0:e.engine)==="t9a"){const n=t;if(typeof n.calcTotalCount=="function"){const s=n.calcTotalCount(),a=n.calcMaxAmount();if(a!=null)return s>a?`<span class="error">(${s}/${a})</span>`:`(${s}/${a})`}}return""}const xi=G({emits:["list-change","force-added","preset-created"],components:{CollapsibleBox:ne},props:{book:{type:Object,required:!0},army:{type:Object,required:!0},force:{type:Object,required:!0},category:{type:Object,required:!0},booksDate:{type:Object},filter:{type:String,default:""},nocollapse:{type:Boolean,default:!1}},methods:{debug(e){console.log(e.getName&&e.getName(),e),window.$debugOption=e},createFromPreset(e,t){this.$emit("preset-created",e,t)},listChange(){this.$emit("list-change")},get_filter_text(e,t){const n=new Set;if(this.$optionStore.options.searchkeywords&&(t.getAllSecondaries().forEach(n.add,n),n.add(e.name)),this.$optionStore.options.searchunits&&n.add(t.name),this.$optionStore.options.searchkeywords&&this.bs&&this.system.short.startsWith("wh40k")){const s=t.getAllModifiedProfiles(),a=t.getAllUnselectedProfiles(),d=t.getAllModifiedRules();s.push(...a);for(const l of s)for(const u of l.characteristics||[])if(u.name&&u.name.toString().toLowerCase()==="keywords"){const g=`${u.$text}`.trim();g!="-"&&g.length&&n.add(g)}for(const l of d)n.add(l.name)}return[...n].join(" ")},filter_units_by_text(e,t){let n;if(this.$optionStore.options.searchregex)try{n=new RegExp(this.filter,"i")}catch{n=at(this.filter)}else n=at(this.filter);return t.filter(s=>{if(s.isHidden(this.army||void 0))return!1;if(!this.filter)return!0;const a=this.get_filter_text(e,s);if(this.$optionStore.options.searchcosts&&this.filter.match(/[0-9]+/)&&!this.$optionStore.options.searchregex){const d=s.getStartingCosts();return d.length?d[0].value<=parseInt(this.filter)!==this.$optionStore.options.searchreverse:!1}else return a.match(n)===null===this.$optionStore.options.searchreverse})},filter_units_by_models(e){if(!this.$optionStore.options.searchmodels)return e;const t=this.$figurineStore.extra();return e.filter(n=>{const s=this.$figurineStore.getFigurinesFromBookUnit(n,this.book);return s.length?t.length?!!zn(s,t,!0).matches.length:!1:!0})},calcUnits(){const e=this.filter_units_by_text(this.category,this.category.getAvailableUnits());return this.filter_units_by_models(e)}},computed:{categoryConstraint(){return Kt(this.system,this.category)},isConfiguration(){return!!(this.system.settings.configurationCategories&&this.system.settings.configurationCategories.includes(this.category.name))},mobile(){return this.$userStore.windowWidth<1250},bs(){return this.book.getSystem().engine==="bs"},system(){return this.army.getBook().getSystem()},units(){const e=this.calcUnits()||[];switch(this.$optionStore.options.sortAvailableUnits){case"alphabetical":return _(e,t=>t.name);case"costs-ascending":return _(e,t=>Math.max(...t.getStartingCosts().map(n=>n.value),0));case"costs-descending":return Qe(e,t=>Math.max(...t.getStartingCosts().map(n=>n.value),0))}return[]}}}),bi={class:"categoryContainer"},yi=["innerHTML"],vi={class:"unitList"};function wi(e,t,n,s,a,d){const l=Re,u=ne;return e.units.length?(i(),p("div",{key:0,class:T({newui:e.$optionStore.options.newMobileUi})},[r("div",bi,[w(u,{nobox:"",title:"titreCategory",defcollapsed:e.mobile&&!e.nocollapse,collapsible:!e.nocollapse,onMouseup:t[1]||(t[1]=B(g=>e.debug(e.category),["middle","prevent"]))},{title:k(()=>[r("span",null,m(e.category.name),1),t[2]||(t[2]=o()),r("span",{class:"constraint",innerHTML:e.categoryConstraint},null,8,yi)]),content:k(()=>[r("div",vi,[(i(!0),p(C,null,D(e.units,g=>(i(),E(l,{key:g.uid,unit:g,book:e.book,force:e.force,parent:e.force,config:e.isConfiguration,onListChange:e.listChange,onForceAdded:t[0]||(t[0]=c=>e.$emit("force-added")),onPresetCreated:e.createFromPreset},null,8,["unit","book","force","parent","config","onListChange","onPresetCreated"]))),128))])]),_:1},8,["defcollapsed","collapsible"])])],2)):h("",!0)}const Ci=Object.assign(Q(xi,[["render",wi],["__scopeId","data-v-cbc6c99e"]]),{__name:"ListsBookCategory"}),Ei=G({components:{CollapsibleBox:ne},props:{book:{type:Object,required:!0},army:{type:Object,required:!0},force:{type:Object,required:!0},booksDate:{type:Object},filter:{type:String,default:""},categoryFilter:{type:String,default:""}},emits:["preset-created","list-change","force-added"],data(){return{profileOpen:!1,childForceBook:null,childForces:null,childForcesTracker:null,rerenderChildForces:!1}},mounted(){if(this.bs){const e=this.force.getAvailableChildForcesWithTracker();if(e){const{forces:t,tracker:n}=e;this.childForcesTracker=n,this.setVisibleChildForces(t),n.listen(()=>{this.rerenderChildForces=!0})}}},unmounted(){this.childForcesTracker&&this.childForcesTracker.unlisten()},methods:{createFromPreset(e,t){this.$emit("preset-created",e,t)},async addChildForce(e,t,n){const s=new Ge;s.logOwnUnitWarnings=!1;const a=this.booksDate,d=await this.system.getBook(e.id,a);let l=null;d&&(l=d);const u=t.insertForce(l,n);u==null?this.$mainStore.errorManager.notifyLastError(s.errorStack):(s.logWarnings&&this.$showMessages(s.warningStack),this.applyPresets(u)),this.$emit("list-change")},applyPresets(e){Lt(this.$optionStore.options,this.system.id,e)},categories(e){return e.getAvailableCategories()},setVisibleChildForces(e){if(e!=null&&e.length){const t=Ke(e,s=>s.book.name);this.childForces=t;const n=Object.values(t);n.length===1&&n[0].length&&(this.childForceBook=n[0][0].book.name)}else this.childForces=null}},watch:{rerenderChildForces(e){e&&(this.setVisibleChildForces(this.force.getAvailableVisibleChildForces()),this.rerenderChildForces=!1)}},computed:{bs(){return this.book.getSystem().engine==="bs"},system(){return this.army.getBook().getSystem()},singleForce(){return!this.bs}}}),Fi=["id"],ki={key:0},Di={class:"titreForce"},Ai={class:"bookContent"},Pi={class:"childForcesContent"},Si={value:null,disabled:""},Gi=["value"],Bi={key:0,class:"unitList"};function Qi(e,t,n,s,a,d){const l=Zt,u=X,g=Re,c=ne,x=Ci;return i(),p("div",{id:e.force.getUid(),class:"bookForce"},[e.singleForce?h("",!0):(i(),p("div",ki,[r("h3",Di,[w(l,{force:e.force},null,8,["force"])])])),t[7]||(t[7]=o()),r("div",Ai,[e.bs&&e.childForces&&!e.categoryFilter?(i(),E(c,{key:0,nobox:"",class:"childForces",defcollapsed:""},{title:k(()=>[o(m(e.force.getChildForcesLabel())+" ",1),w(u,{errors:e.force.getErrors().filter(y=>{var b;return((b=y.constraint)==null?void 0:b.field)==="forces"}),source:e.force,maxSeverity:"warning"},null,8,["errors","source"])]),content:k(()=>[r("div",Pi,[P(r("select",{"onUpdate:modelValue":t[0]||(t[0]=y=>e.childForceBook=y)},[r("option",Si,m(e.$referenceStore.getString("lists_select_faction"))+" ("+m(Object.keys(e.childForces).length)+") ",1),t[3]||(t[3]=o()),(i(!0),p(C,null,D(e.childForces,y=>(i(),p("option",{key:y[0].book.name,value:y[0].book.name},m(y[0].book.name),9,Gi))),128))],512),[[Qt,e.childForceBook]])]),t[4]||(t[4]=o()),e.bs&&e.childForceBook?(i(),p("div",Bi,[(i(!0),p(C,null,D(e.childForces,y=>(i(),p(C,null,[(i(!0),p(C,null,D(y,b=>(i(),p(C,null,[b.book.name===e.childForceBook?(i(),E(g,{key:b.force.id,childforce:"",unit:b.force,book:e.book,force:b.state,parent:e.force,onForceAdded:f=>e.addChildForce(b.book,e.force,b.force.id),name:b.name,errors:b.state.getErrors().filter(f=>{var v;return((v=f.constraint)==null?void 0:v.type)==="min"}),costs:b.costs},null,8,["unit","book","force","parent","onForceAdded","name","errors","costs"])):h("",!0)],64))),256))],64))),256))])):h("",!0)]),_:1})):h("",!0),t[6]||(t[6]=o()),(i(!0),p(C,null,D(e.categories(e.force),y=>(i(),p(C,null,[!e.categoryFilter||y.name===e.categoryFilter?(i(),E(x,{nocollapse:e.categoryFilter.length!=0,book:e.book,army:e.army,force:e.force,bookDate:e.booksDate,key:y.uid,category:y,filter:e.filter,onListChange:t[1]||(t[1]=b=>e.$emit("list-change")),onForceAdded:t[2]||(t[2]=b=>e.$emit("force-added")),onPresetCreated:e.createFromPreset},null,8,["nocollapse","book","army","force","bookDate","category","filter","onPresetCreated"])):h("",!0)],64))),256))])],8,Fi)}const Ui=Object.assign(Q(Ei,[["render",Qi],["__scopeId","data-v-fece3583"]]),{__name:"ListsBookForce"});function $i(e,t){let n=0,s=0,a="auto",d="start",l="nearest";typeof t=="object"&&(n=t.topOffset||n,s=t.leftOffset||s,a=t.behavior||a,d=t.block||d,l=t.inline||l);const u=e.getBoundingClientRect(),g=e.closest(".scrollable")||document.documentElement,c=g.getBoundingClientRect(),x=g.clientHeight,y=g.clientWidth,b=g.scrollLeft,f=g.scrollTop;let v=u.top-c.top+f-n,F=u.left-c.left+b-s;const A=a==="smooth"?"smooth":"auto";d==="center"?v-=(x-u.height)/2:d==="end"&&(v-=x-u.height),l==="center"?F-=(y-u.width)/2:l==="end"&&(F-=y-u.width),g.scrollTo({top:v,left:F,behavior:A})}const Ri=G({emits:["collapsed","uncollapsed","preset-created","list-change","force-added","edit-unit"],components:{PopupDialog:H,Loading:Me},props:{book:{type:Object,required:!0},army:{type:Object,required:!0},booksDate:{type:Object},nocollapse:{type:Boolean,default:!1},fixedsearchbar:{type:Boolean,default:!1},forceUid:{type:String,required:!1},categoryFilter:{type:String,required:!1}},data(){return{childForceBook:null,filter:"",tmpFilter:"",debounceTimer:null,profileOpen:!1,rendered:!1,initialized:!1,showSearchOptions:!1,showSortOptions:!1,searchOptions:{costs:!0,categories:!0,units:!0,keywords:!0,models:!1,reverse:!1,regex:!1}}},setup(){const{buttonSize:e}=Is();return{store:te(),listStore:Zn(),buttonSize:e}},updated(){this.initialized&&(this.rendered=!0)},mounted(){this.searchOptions={costs:this.$optionStore.options.searchcosts,categories:this.$optionStore.options.searchcategories,units:this.$optionStore.options.searchunits,keywords:this.$optionStore.options.searchkeywords,models:this.$optionStore.options.searchmodels,reverse:this.$optionStore.options.searchreverse,regex:this.$optionStore.options.searchregex}},computed:{playMode(){var e,t;return((t=(e=this.listStore.currentList)==null?void 0:e.row.metadata)==null?void 0:t.play_mode)===!0},sorting:{get(){return this.$optionStore.options.sortAvailableUnits},set(e){this.$optionStore.options.sortAvailableUnits=e,this.$optionStore.saveOptions()}},dropdownSrc(){return`/assets/icons/right${this.$optionStore.options.appearence.dropdownStyle||2}.svg`},bs(){return this.book.getSystem().engine==="bs"},system(){return this.army.getBook().getSystem()},is_collapsed(){return this.store.isCollapsed()&&!this.nocollapse},searchPlaceHolder(){let e="";return this.system.settings.secondaryCategoryName&&(e=", "+this.system.settings.secondaryCategoryName),`${this.$referenceStore.getString("lists_book_search_placeholder")}${e}...`},bottomPadding(){return this.$userStore.windowWidth>=1200?this.$optionStore.options.alwaysShowPlus?this.buttonSize===50?50:100:0:this.buttonSize===50?50:100}},methods:{updateSearchConfig(e,t){this.searchOptions[e]=t,this.$optionStore.updateOptions(`search${e}`,t)},collapseClicked(){this.store.addingUnit?history.back():this.toggle()},clicked(){this.store.addUnitCollapsed&&this.collapseClicked()},toggle(){this.store.addUnitCollapsed=!this.store.addUnitCollapsed},scrollTo(e){const t=document.getElementById(e),n=document.getElementById("bookBox"),s=n==null?void 0:n.childNodes[0],a=(s==null?void 0:s.getBoundingClientRect().height)||20;t&&$i(t,{block:"start",inline:"start",behavior:"smooth",topOffset:a+4})},createFromPreset(e,t){this.$emit("preset-created",e,t)}},watch:{is_collapsed:{immediate:!0,handler(e){!e&&!this.initialized&&setTimeout(()=>{this.initialized=!this.is_collapsed},0)}},tmpFilter(e){clearTimeout(this.debounceTimer),this.debounceTimer=setTimeout(()=>{e===this.tmpFilter&&(this.filter=e)},200)}}}),Mi={class:"scrollable padded"},Ii=["src","title","alt"],Hi={key:0,style:{width:"100%",display:"flex","align-items":"center","margin-top":"10px"}},Li=["title","alt"],Ti=["title","alt"],Oi=["title"],Yi=["placeholder"],Ni={class:"dropDownIcon"},Vi={class:"dropDownIcon"},ji={class:"dropDownIcon"},Wi={for:"searchmodels"},Xi={for:"searchcosts"},zi={for:"searchunits"},Zi={for:"searchkeywords"},Ki={for:"searchreverse"},Ji={for:"searchregex"};function qi(e,t,n,s,a,d){const l=Me,u=Ui,g=ze,c=Fn,x=En,y=Cn,b=$e,f=H;return i(),p("div",{class:T(["book",{bg:e.is_collapsed}]),onClick:t[24]||(t[24]=(...v)=>e.clicked&&e.clicked(...v))},[r("div",Mi,[r("img",{onClick:t[0]||(t[0]=B((...v)=>e.collapseClicked&&e.collapseClicked(...v),["stop"])),class:T(["imgBt arrow",{right:e.is_collapsed,left:!e.is_collapsed}]),src:e.dropdownSrc,title:e.is_collapsed?e.$referenceStore.getString("lists_book_uncollapse_panel"):e.$referenceStore.getString("lists_book_collapse_panel"),alt:e.is_collapsed?e.$referenceStore.getString("lists_book_uncollapse_panel"):e.$referenceStore.getString("lists_book_collapse_panel")},null,10,Ii),t[27]||(t[27]=o()),!e.is_collapsed&&!e.rendered?(i(),E(l,{key:0,mode:"absolute"})):h("",!0),t[28]||(t[28]=o()),!e.is_collapsed&&e.initialized?(i(),p(C,{key:1},[(i(!0),p(C,null,D(e.army.getForces(),v=>P((i(),E(u,{key:v.uid,book:e.book,force:v,army:e.army,filter:(e.categoryFilter,e.filter),categoryFilter:e.categoryFilter,bookDate:e.booksDate,onListChange:t[1]||(t[1]=F=>e.$emit("list-change")),onPresetCreated:e.createFromPreset},null,8,["book","force","army","filter","categoryFilter","bookDate","onPresetCreated"])),[[K,e.rendered&&(!e.forceUid||v.uid===e.forceUid)]])),128)),t[25]||(t[25]=o()),!e.playMode&&e.bs&&!e.categoryFilter?P((i(),p("div",Hi,null,512)),[[K,e.rendered]]):h("",!0),t[26]||(t[26]=o()),P(r("div",{style:oe(`min-height: ${e.bottomPadding}px`)},null,4),[[K,e.rendered]])],64)):h("",!0)]),t[49]||(t[49]=o()),e.is_collapsed?h("",!0):(i(),p("span",{key:0,class:"bottom",style:oe(e.fixedsearchbar?{position:"fixed"}:{position:"relative"})},[r("span",{onClick:t[2]||(t[2]=v=>e.showSearchOptions=!0),class:"imgBt searchOption",title:e.$referenceStore.getString("lists_book_additional_search_options"),alt:e.$referenceStore.getString("lists_book_additional_search_options")},[w(g,{style:{"max-height":"24px"}})],8,Li),t[44]||(t[44]=o()),r("span",{onClick:t[3]||(t[3]=v=>e.showSortOptions=!0),class:"imgBt sortOption",title:e.$referenceStore.getString("lists_book_sorting_options"),alt:e.$referenceStore.getString("lists_book_sorting_options")},[e.sorting==="costs-ascending"?(i(),E(c,{key:0,style:{"max-height":"24px"}})):e.sorting==="costs-descending"?(i(),E(x,{key:1,style:{"max-height":"24px"}})):(i(),E(y,{key:2,style:{"max-height":"24px"}}))],8,Ti),t[45]||(t[45]=o()),e.tmpFilter?(i(),p("span",{key:0,onMousedown:t[4]||(t[4]=B(()=>{},["prevent"])),onClick:t[5]||(t[5]=v=>e.tmpFilter=""),class:"imgBt clearOption",title:e.$referenceStore.getString("clear"),role:"button"},[...t[29]||(t[29]=[r("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2"},[r("path",{d:"m6 6 12 12M18 6 6 18"})],-1)])],40,Oi)):h("",!0),t[46]||(t[46]=o()),P(r("input",{class:T(["search-box",{clearable:e.tmpFilter}]),"onUpdate:modelValue":t[6]||(t[6]=v=>e.tmpFilter=v),type:"search",placeholder:e.searchPlaceHolder},null,10,Yi),[[q,e.tmpFilter]]),t[47]||(t[47]=o()),e.showSortOptions?(i(),E(b,{key:1,modelValue:e.showSortOptions,"onUpdate:modelValue":t[10]||(t[10]=v=>e.showSortOptions=v),direction:"up",anchorleft:"",anchorright:"",capture:""},{default:k(()=>[r("div",{class:"sort-option imgBt","data-sort":"name-asc",onClick:t[7]||(t[7]=v=>e.sorting="alphabetical")},[r("span",Ni,[w(y)]),o(" "+m(e.$referenceStore.getString("lists_book_sort_name")),1)]),t[30]||(t[30]=o()),r("div",{class:"sort-option imgBt","data-sort":"cost-desc",onClick:t[8]||(t[8]=v=>e.sorting="costs-descending")},[r("span",Vi,[w(x)]),o(" "+m(e.$referenceStore.getString("lists_book_sort_costs_descending")),1)]),t[31]||(t[31]=o()),r("div",{class:"sort-option imgBt","data-sort":"cost-asc",onClick:t[9]||(t[9]=v=>e.sorting="costs-ascending")},[r("span",ji,[w(c)]),o(" "+m(e.$referenceStore.getString("lists_book_sort_costs_ascending")),1)])]),_:1},8,["modelValue"])):h("",!0),t[48]||(t[48]=o()),e.showSearchOptions?(i(),E(f,{key:2,modelValue:e.showSearchOptions,"onUpdate:modelValue":t[23]||(t[23]=v=>e.showSearchOptions=v),x:"",noclose:"",width:"500px"},{header:k(()=>[o(m(e.$referenceStore.getString("lists_book_search_options")),1)]),default:k(()=>[t[38]||(t[38]=o()),r("div",null,[P(r("input",{onChange:t[11]||(t[11]=v=>e.updateSearchConfig("models",e.searchOptions.models)),id:"searchmodels",type:"checkbox","onUpdate:modelValue":t[12]||(t[12]=v=>e.searchOptions.models=v)},null,544),[[I,e.searchOptions.models]]),t[32]||(t[32]=o()),r("label",Wi,m(e.$referenceStore.getString("lists_book_only_owned_models")),1)]),t[39]||(t[39]=o()),r("div",null,[P(r("input",{onChange:t[13]||(t[13]=v=>e.updateSearchConfig("costs",e.searchOptions.costs)),id:"searchcosts",type:"checkbox","onUpdate:modelValue":t[14]||(t[14]=v=>e.searchOptions.costs=v)},null,544),[[I,e.searchOptions.costs]]),t[33]||(t[33]=o()),r("label",Xi,m(e.$referenceStore.getString("lists_book_search_costs")),1)]),t[40]||(t[40]=o()),r("div",null,[P(r("input",{onChange:t[15]||(t[15]=v=>e.updateSearchConfig("units",e.searchOptions.units)),id:"searchunits",type:"checkbox","onUpdate:modelValue":t[16]||(t[16]=v=>e.searchOptions.units=v)},null,544),[[I,e.searchOptions.units]]),t[34]||(t[34]=o()),r("label",zi,m(e.$referenceStore.getString("lists_book_search_units")),1)]),t[41]||(t[41]=o()),r("div",null,[P(r("input",{onChange:t[17]||(t[17]=v=>e.updateSearchConfig("keywords",e.searchOptions.keywords)),id:"searchkeywords",type:"checkbox","onUpdate:modelValue":t[18]||(t[18]=v=>e.searchOptions.keywords=v)},null,544),[[I,e.searchOptions.keywords]]),t[35]||(t[35]=o()),r("label",Zi,m(e.$referenceStore.getString("lists_book_search_categories"))+" "+m(e.system.settings.secondaryCategoryName||"Categories"),1)]),t[42]||(t[42]=o()),r("div",null,[P(r("input",{onChange:t[19]||(t[19]=v=>e.updateSearchConfig("reverse",e.searchOptions.reverse)),id:"searchreverse",type:"checkbox","onUpdate:modelValue":t[20]||(t[20]=v=>e.searchOptions.reverse=v)},null,544),[[I,e.searchOptions.reverse]]),t[36]||(t[36]=o()),r("label",Ki,m(e.$referenceStore.getString("lists_book_reverse_search")),1)]),t[43]||(t[43]=o()),r("div",null,[P(r("input",{onChange:t[21]||(t[21]=v=>e.updateSearchConfig("regex",e.searchOptions.regex)),id:"searchregex",type:"checkbox","onUpdate:modelValue":t[22]||(t[22]=v=>e.searchOptions.regex=v)},null,544),[[I,e.searchOptions.regex]]),t[37]||(t[37]=o()),r("label",Ji,m(e.$referenceStore.getString("lists_book_regex_search")),1)])]),_:1},8,["modelValue"])):h("",!0)],4))],2)}const _i=Object.assign(Q(Ri,[["render",qi],["__scopeId","data-v-e052fea0"]]),{__name:"ListsBook"});function Jt(e,t,n){if(e.metadata.custom_categories||(e.metadata.custom_categories=[]),n){const a=e.metadata.custom_categories.find(d=>d.uid==n);if(a)return a}const s={uid:n||Kn(),name:t,units:[]};return e.metadata.custom_categories.push(s),s}function ea(e,t){var n;if(!((n=e.metadata)!=null&&n.custom_categories))return!1;for(const s of e.metadata.custom_categories)if(s.units.includes(t))return!0;return!1}function ta(e,t){var s,a;const n=(a=(s=e.metadata)==null?void 0:s.custom_categories)==null?void 0:a.findIndex(d=>d.uid===t);if(n!=null&&n>=1){const d=e.metadata.custom_categories.splice(n,1);e.metadata.custom_categories.splice(n-1,0,d[0])}}function na(e,t,n){var a,d;const s=(d=(a=e.metadata)==null?void 0:a.custom_categories)==null?void 0:d.find(l=>l.uid===t);s&&(s.name=n)}function sa(e,t){var s,a;const n=(a=(s=e.metadata)==null?void 0:s.custom_categories)==null?void 0:a.findIndex(d=>d.uid===t);return n==null||n===-1?!1:(e.metadata.custom_categories.splice(n,1),!0)}function oa(e,t,n,s,a){var g;const d=((g=e.metadata)==null?void 0:g.custom_categories)||[],l=d.find(c=>c.uid===n);if(l){const c=l.units.indexOf(t);c!==-1&&l.units.splice(c,1)}const u=d.find(c=>c.uid===s);u&&u.units.splice(a,0,t)}function ra(e,t){for(const n of t.getCategories()){if(!n.getUnits().length)continue;const s=Jt(e,n.getName(),n.uid);for(const a of n.getUnits())ea(e,a.uid)||s.units.push(a.uid)}}function mt(e,t){const n={uid:e.uid,custom:!0,getName:()=>e.name,getId:()=>e.uid,getMaxConstraints:()=>[],getMinConstraints:()=>[],getAvailableUnits:()=>[],isExportable:()=>!0,isTracked:()=>!1,isHidden:()=>!1,isCollapsible:()=>!0,isConstant:()=>!1,isConstantRecursive:()=>!1,isCategory:()=>!0,isUnit:()=>!1,isForce:()=>!1,isRoster:()=>!1,isGroup:()=>!1,isHeader:()=>!1,isSubUnit:()=>!1,isModel:()=>!1,isCrew:()=>!1,getUid:()=>e.uid,getOriginalName:()=>e.name,getCustomName:()=>{},getType:()=>"category",getBook:()=>t.getBook(),getParent:()=>t,getParentForce:()=>t,getParentRoster:()=>t.getParentRoster(),getCosts:()=>[],calcTotalCostsForOne:()=>[],getTags:()=>[],getAmount:()=>0,getChildren:()=>n.getUnits(),getAvailableChildren:()=>[],countVisibleActivatedChildren:()=>n.getUnits().length,forEach:s=>n.getUnits().forEach(s),forEachIncludeInactive:s=>n.getUnits().forEach(s),amout:0,calcTotalCosts(){const s={};for(const a of n.getUnits())for(const d of a.calcTotalCosts())s[d.typeId]||(s[d.typeId]={typeId:d.typeId,name:d.name,value:0}),s[d.typeId].value+=d.value;return Object.values(s)},getUnits:()=>[],getErrors:()=>[]};return n}function ia(e,t,n){var u;const s=[],a={};for(const g of((u=e.metadata)==null?void 0:u.custom_categories)||[]){const c=mt(g,t),x=[];for(const y of g.units){const b=aa(t,y);b&&(x.push(b),a[y]=!0)}c.getUnits=()=>x,s.push(c)}const d=[];for(const g of t.getCategories())for(const c of g.getUnits())a[c.uid]||d.push(c);const l=mt({name:n,uid:"uncategorized"},t);return l.getUnits=()=>d,s.push(l),s}function aa(e,t){for(const n of e.getCategories())for(const s of n.getUnits())if(s.uid===t)return s;return null}async function la(e,t){const n=e.army,a=await n.getBook().loadRosterFromJson(n.toJson(),n.booksDate),d=a.getForces(!0).find(u=>u.uid===t.uid);if(d){const u=new Set([d.uid,...d.getForces(!0).map(g=>g.uid)]);for(const g of a.getForces(!0)){const c=u.has(g.uid);g.isExportable=()=>c}}const l=n.getCustomName();return l&&a.setCustomName(l),{book:e.book,army:a,row:{...e.row,text:void 0}}}let z=null;const ht=.55,da=.4,pa={name:"SwipeActions",emits:["left","right"],props:{disabled:Boolean,panelWidth:{type:Number,default:84},leftColor:{type:String,default:"var(--color-blue)"},rightColor:{type:String,default:"var(--color-red)"}},data(){return{pointerId:null,startX:0,startY:0,base:0,offset:0,width:0,dragging:!1,committing:!1,pastCommit:!1,suppressClick:!1,moveSamples:[],openWidth:0,openSide:"",closeRef:null}},created(){this.closeRef=()=>this.close()},beforeUnmount(){z===this.closeRef&&(z=null),document.removeEventListener("pointerdown",this.onOutsidePointer,!0)},methods:{onPointerDown(e){this.disabled||e.pointerType==="mouse"||this.pointerId!==null||e.clientX<15||e.clientX>window.innerWidth-15||(this.pointerId=e.pointerId,this.startX=e.clientX,this.startY=e.clientY,this.base=this.offset,this.width=this.$el.offsetWidth,this.moveSamples=[])},releaseVelocity(){const e=this.moveSamples;if(e.length<2)return 0;const t=e[e.length-1],n=e[0],s=t.t-n.t;return s>0?(t.x-n.x)/s:0},onPointerMove(e){var d;if(e.pointerId!==this.pointerId)return;const t=e.clientX-this.startX,n=e.clientY-this.startY;if(!this.dragging){if(Math.abs(t)<8||Math.abs(t)<Math.abs(n)*1.2)return;this.dragging=!0,e.currentTarget.setPointerCapture(e.pointerId),z&&z!==this.closeRef&&z()}let s=this.base+t;this.$slots.left||(s=Math.min(s,0)),this.$slots.right||(s=Math.max(s,0)),s=Math.max(-this.width,Math.min(this.width,s));const a=Math.abs(s)>this.width*ht;for(a!==this.pastCommit&&(this.pastCommit=a,(d=navigator.vibrate)==null||d.call(navigator,10)),this.moveSamples.push({x:e.clientX,t:e.timeStamp});this.moveSamples.length>1&&e.timeStamp-this.moveSamples[0].t>100;)this.moveSamples.shift();this.offset=s},onPointerUp(e){if(e.pointerId!==this.pointerId||(this.pointerId=null,!this.dragging))return;this.dragging=!1,this.suppressClick=!0,window.setTimeout(()=>this.suppressClick=!1,300);const t=this.offset,n=this.releaseVelocity();Math.abs(t)>this.width*ht?this.commit(t>0?"left":"right"):Math.abs(n)>=da?n>0&&t>0?this.open("left"):n<0&&t<0?this.open("right"):this.close():t>this.panelWidth/2&&this.$slots.left?this.open("left"):t<-this.panelWidth/2&&this.$slots.right?this.open("right"):this.close()},onPointerCancel(e){e.pointerId===this.pointerId&&(this.pointerId=null,this.dragging=!1,this.offset=this.openSide==="left"?this.openWidth:this.openSide==="right"?-this.openWidth:0)},commit(e){this.committing=!0,this.offset=e==="left"?this.width:-this.width,window.setTimeout(()=>{this.$emit(e),this.committing=!1,this.close()},180)},trigger(e){this.committing||!this.openSide||(this.$emit(e),this.close())},open(e){z&&z!==this.closeRef&&z(),z=this.closeRef,this.openSide=e;const t=e==="left"?this.$refs.panelLeft:this.$refs.panelRight,n=t==null?void 0:t.firstElementChild;this.openWidth=Math.max(this.panelWidth,n instanceof HTMLElement?n.offsetWidth:0),this.offset=e==="left"?this.openWidth:-this.openWidth,document.addEventListener("pointerdown",this.onOutsidePointer,!0)},close(){z===this.closeRef&&(z=null),document.removeEventListener("pointerdown",this.onOutsidePointer,!0),this.openSide="",this.offset=0},onOutsidePointer(e){this.$el.contains(e.target)||this.close()},onClickCapture(e){if(this.suppressClick){this.suppressClick=!1,e.stopPropagation(),e.preventDefault();return}this.openSide&&this.$refs.content.contains(e.target)&&(e.stopPropagation(),e.preventDefault(),this.close())}}};function ua(e,t,n,s,a,d){return i(),p("div",{class:T(["swipeActions",{dragging:a.dragging,committing:a.committing}]),onClickCapture:t[6]||(t[6]=(...l)=>d.onClickCapture&&d.onClickCapture(...l))},[e.$slots.left?P((i(),p("div",{key:0,ref:"panelLeft",class:"panel left",style:oe({background:n.leftColor,width:`${Math.max(a.offset,0)}px`}),onClick:t[0]||(t[0]=B(l=>d.trigger("left"),["stop"]))},[N(e.$slots,"left",{},void 0,!0)],4)),[[K,a.offset>0]]):h("",!0),t[7]||(t[7]=o()),e.$slots.right?P((i(),p("div",{key:1,ref:"panelRight",class:"panel right",style:oe({background:n.rightColor,width:`${Math.max(-a.offset,0)}px`}),onClick:t[1]||(t[1]=B(l=>d.trigger("right"),["stop"]))},[N(e.$slots,"right",{},void 0,!0)],4)),[[K,a.offset<0]]):h("",!0),t[8]||(t[8]=o()),r("div",{ref:"content",class:"swipeContent",style:oe({transform:`translateX(${a.offset}px)`}),onPointerdown:t[2]||(t[2]=(...l)=>d.onPointerDown&&d.onPointerDown(...l)),onPointermove:t[3]||(t[3]=(...l)=>d.onPointerMove&&d.onPointerMove(...l)),onPointerup:t[4]||(t[4]=(...l)=>d.onPointerUp&&d.onPointerUp(...l)),onPointercancel:t[5]||(t[5]=(...l)=>d.onPointerCancel&&d.onPointerCancel(...l))},[N(e.$slots,"default",{},void 0,!0)],36)],34)}const ca=Object.assign(Q(pa,[["render",ua],["__scopeId","data-v-8c721d26"]]),{__name:"SwipeActions"}),ga=G({name:"SubMenu",props:{capture:{type:Boolean,required:!1},direction:{type:String,required:!1},anchorleft:{type:Boolean,required:!1},anchorright:{type:Boolean,required:!1}},data(){return{open:!1}}});function fa(e,t,n,s,a,d){const l=$e;return i(),p(C,null,[r("div",{onClick:t[0]||(t[0]=B(u=>e.open=!e.open,["stop"]))},[N(e.$slots,"trigger")]),t[2]||(t[2]=o()),e.open?(i(),E(l,{key:0,anchorleft:e.anchorleft,anchorright:e.anchorright,direction:e.direction,capture:e.capture,modelValue:e.open,"onUpdate:modelValue":t[1]||(t[1]=u=>e.open=u)},{default:k(()=>[N(e.$slots,"submenu")]),_:3},8,["anchorleft","anchorright","direction","capture","modelValue"])):h("",!0)],64)}const ma=Object.assign(Q(ga,[["render",fa]]),{__name:"InlineSubMenu"}),st={components:{ErrorIcon:X,PopupDialog:H,UnitProfiles:Ue},name:"UnitRow",emits:["edit-unit","list-change","detach"],setup(){return{store:te()}},props:{unit:{type:Object,required:!0},player:{type:Object,required:!1},mode:Number,categoryuid:{type:String,required:!0},depth:{type:Number,default:0},associationParent:{type:Object,required:!1}},data(){return{draggedOver:!1,popupProfiles:null}},computed:{associationChild(){return!!this.associationParent},playMode(){var t;const e=(t=this.row)==null?void 0:t.metadata;return(e==null?void 0:e.play_mode)===!0},note(){return this.unit.getNote()},subUnitsHaveOwnRows(){return this.t9a?!1:this.unit.getAllUnits(!1).length>0},hasNestedRows(){return this.childs.length>0},swipeEnabled(){return this.playMode?!1:this.depth===0||this.associationChild},dragged(){var e;return((e=this.store.dragged)==null?void 0:e.uid)===this.unit.uid},hideOptionsListSmall(){return this.$optionStore.options.optionsListLargeScreen&&this.$optionStore.options.optionsListSmallScreen?"block":"none"},hideOptionsList(){return this.$optionStore.options.optionsListLargeScreen?"block":"none"},t9a(){var e;return((e=this.$systemStore.selectedSystem)==null?void 0:e.short)=="t9a"},hasLeaders(){const e=this.$systemStore.selectedSystem;return e?V(e).hasLeaders():!1},ledUnits(){var n;if(this.depth>=1)return[];if(!this.hasLeaders)return[];const e=V(this.$systemStore.selectedSystem),t=(n=this.row)==null?void 0:n.metadata;return t?e.getLedUnits(t,this.unitIndex,this.unit):[]},unitIndex(){const e=[...this.unit.getParentRoster().iterateUnits()],t={};for(const n of e)t[n.uid]=n;return t},errors(){return this.unit.getErrors()},optionsList(){var n,s;const e=this.playMode&&!this.t9a?(s=(n=this.row)==null?void 0:n.metadata)==null?void 0:s.casualties:void 0;return V(this.unit.getParentRoster().getBook().getSystem()).optionsList(this.unit,this.$optionStore.options.mainViewConstants,!this.subUnitsHaveOwnRows,e,this.groupAttached,this.associationParent)},optionsListHtml(){const e=es(this.optionsList),t=new RegExp(ts+"(\\d+)","g");return e.replace(t,'<svg class="skull-icon nr-icon" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C7.5 2 4 5.5 4 10c0 2.5 1 4.5 2.5 6v4.5c0 .8.7 1.5 1.5 1.5h1v-3h2v3h2v-3h2v3h1c.8 0 1.5-.7 1.5-1.5V16c1.5-1.5 2.5-3.5 2.5-6 0-4.5-3.5-8-8-8zM9 13c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm6 0c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/></svg><span class="wound-count">$1</span>')},costsLeft(){return this.$optionStore.options.appearence.costsLeft},categoryIcons(){return this.$optionStore.options.appearence.categoryIcons},allModelsDead(){var t,n;if(!this.playMode||this.t9a)return!1;const e=(n=(t=this.row)==null?void 0:t.metadata)==null?void 0:n.casualties;return e?Le(this.unit,e):!1},hasAliveChildren(){var t,n;if(!this.allModelsDead||this.t9a)return!1;const e=(n=(t=this.row)==null?void 0:t.metadata)==null?void 0:n.casualties;return e?this.ledUnits.some(s=>!Le(s,e)):!1},unitStatus(){var e;return(e=this.player)==null?void 0:e.unitStatuses[this.unit.uid]},unitStatusText(){var t,n,s,a;let e="";return(t=this.unitStatus)!=null&&t.fleeing&&(e+=" <span class='unitStatus'>fleeing</span>"),(n=this.unitStatus)!=null&&n.captured&&(e+=" <span class='unitStatus'>captured</span>"),((s=this.unitStatus)==null?void 0:s.status)==1&&(e+=" <span class='unitStatus'>shattered</span>"),((a=this.unitStatus)==null?void 0:a.status)==2&&(e+=" <span class='unitStatus'>dead</span>"),e},categoryIcon(){const e=this.unit.getCategoryIcon();return e||(this.hasNestedRows?"/assets/icons/banner.png":"/assets/icons/helmet.svg")},scoring(){return this.unit.isScoring()},totalUnitSize(){const e=this.unit.calcTotalUnitSize();return e>1?e:""},deadModelCount(){var t,n;if(!this.playMode||this.t9a)return 0;const e=(n=(t=this.row)==null?void 0:t.metadata)==null?void 0:n.casualties;return e?_n(this.unit,e):0},survivingCount(){return Math.max(0,this.unit.calcTotalUnitSize()-this.deadModelCount)},hasDeadModels(){return this.deadModelCount>0},unitPartialWoundsForTitle(){var t,n;if(!this.playMode||this.t9a||this.unit.calcTotalUnitSize()!==1)return 0;const e=(n=(t=this.row)==null?void 0:t.metadata)==null?void 0:n.casualties;return e?qn(this.unit,e):0},editing(){var e;return((e=this.store.editedUnit)==null?void 0:e.uid)===this.unit.uid},totalCost(){if(this.mode==1&&this.unitStatus){const e=[{name:"pts",typeId:"pts",value:this.unitStatus.totalCost}],t=[{name:"pts",typeId:"pts",value:V(this.unit.getParentRoster().getBook().getSystem()).calcVp(this.unitStatus)}];return Jn(t,e)}else{const e=this.unit.calcTotalCosts();return He(e)}},row(){var e,t,n;return((t=(e=this.player)==null?void 0:e.list)==null?void 0:t.row)||((n=this.$listStore.currentList)==null?void 0:n.row)},groupAttached(){return this.$optionStore.options.groupAttachedUnits!==!1},childs(){var n;const e=this.unit,t=this.groupAttached?e.getAttachedUnits("group"):[];if(this.playMode&&this.hasLeaders){const s=(n=this.row)==null?void 0:n.metadata,a=(s==null?void 0:s.combineLeadersView)!==!1?this.ledUnits:[];return[...t,...e.getAllUnits(!1),...a]}return this.t9a?[]:[...t,...e.getAllUnits(!1)]},miniatureImageId(){if(!this.$optionStore.options.showUnitImagesMainView||!this.$userStore.isSupporter())return null;const e=this.unit.getParentRoster().getBook().getSystem().id;return this.$figurineStore.getMiniatureImageId(e,this.unit)}},methods:{debug(e){console.log(e.getName(),e),window.$debugOption=e},modifyClicked(){this.$emit("edit-unit",this.unit)},dragOver(){this.draggedOver=!0},dragLeave(){this.draggedOver=!1},toUnit(e){return e},setPopupProfiles(e){this.popupProfiles=e},isAssociationChild(e){var n;const t=e;return(((n=t.getNestedAssociations)==null?void 0:n.call(t,"group"))??[]).some(s=>s.getAssociates().some(a=>a.instance.getUnit()===this.unit))},detachChild(e){var n;const t=e;for(const s of((n=t.getNestedAssociations)==null?void 0:n.call(t,"group"))??[]){const a=s.getAssociates().find(d=>d.instance.getUnit()===this.unit);a&&s.popAssociation(a.instance)}this.$emit("list-change")},async dupeChild(e){const t=await e.dupe();if(t&&t.length>=1){this.$showMessages(t);return}this.$emit("list-change")},async swipeDupe(){const e=await this.unit.dupe();if(e&&e.length>=1){this.$showMessages(e);return}this.$emit("list-change")},swipeTrailing(){if(this.associationChild){this.$emit("detach");return}this.deleteChild(this.unit)},deleteChild(e){var s,a,d;const t=e;t.delete();const n=(d=(a=(s=t.getBook)==null?void 0:s.call(t))==null?void 0:a.getSystem)==null?void 0:d.call(a);n&&this.row&&V(n).onUnitDelete(this.row,t),this.$emit("list-change")}}},xt=()=>{Ut(e=>({v31a55708:e.hideOptionsList,v8736842a:e.hideOptionsListSmall}))},bt=st.setup;st.setup=bt?(e,t)=>(xt(),bt(e,t)):xt;const ha={class:"swipeLabel"},xa={key:0,class:"swipeLabel"},ba={key:1,class:"swipeLabel"},ya={key:0,class:"icons"},va=["src"],wa=["innerHTML"],Ca={class:"displayName"},Ea={key:0,class:"gray"},Fa={class:"red"},ka={key:1,class:"gray"},Da={class:"gray"},Aa={class:"wound-count"},Pa=["innerHTML"],Sa=["innerHTML"],Ga=["innerHTML"],Ba={key:1,class:"section blue notes"},Qa={class:"actionButtonsNested"},Ua=["onClick"],$a={class:"actions imgBt"},Ra=["onClick"],Ma={class:"imgBt"},Ia=["onClick"],Ha={class:"imgBt"},La=["onClick"],Ta=["onClick"],Oa=["onClick"];function Ya(e,t,n,s,a,d){const l=jt,u=Ze,g=kn,c=Se,x=Dn,y=X,b=An,f=ca,v=R("UnitProfiles"),F=H,A=We,S=Rt,W=ma,Y=qt;return i(),p("div",{class:T(["unitRow highlight",{fleeing:d.unitStatus&&d.unitStatus.fleeing,dead:(d.unitStatus&&d.unitStatus.status==2||d.allModelsDead)&&!d.hasAliveChildren,"self-dead":d.allModelsDead&&d.hasAliveChildren,shattered:d.unitStatus&&d.unitStatus.status==1,editing:d.editing||d.dragged,draggedOver:a.draggedOver,nested:n.depth>0,noBackgroundOnNameContent:!e.$optionStore.options.optionsListSmallScreen,"has-miniature-image":d.miniatureImageId}]),onDragover:t[5]||(t[5]=B((...L)=>d.dragOver&&d.dragOver(...L),["prevent"])),onDragleave:t[6]||(t[6]=(...L)=>d.dragLeave&&d.dragLeave(...L)),onDrop:t[7]||(t[7]=(...L)=>d.dragLeave&&d.dragLeave(...L))},[d.miniatureImageId?(i(),E(l,{key:0,picture:d.miniatureImageId,altText:n.unit.getName(),class:"unit-miniature-thumb-row"},null,8,["picture","altText"])):h("",!0),t[32]||(t[32]=o()),r("div",{class:"name",onClick:t[3]||(t[3]=B((...L)=>d.modifyClicked&&d.modifyClicked(...L),["stop"])),onMouseup:t[4]||(t[4]=B(L=>d.debug(n.unit),["middle","stop"]))},[w(f,{class:"rowSwipe",disabled:!d.swipeEnabled,"left-color":"var(--input-highlights, #0063fb)","right-color":d.associationChild?"#ff9500":"var(--color-red)",onLeft:d.swipeDupe,onRight:d.swipeTrailing},$t({default:k(()=>[t[21]||(t[21]=o()),t[22]||(t[22]=o()),r("div",{class:T(["nameContent",{twoColumns:d.categoryIcons}])},[d.categoryIcons?(i(),p("div",ya,[r("img",{class:"icon",src:d.categoryIcon},null,8,va)])):h("",!0),t[19]||(t[19]=o()),r("div",null,[d.costsLeft?(i(),p("span",{key:0,innerHTML:d.totalCost},null,8,wa)):h("",!0),t[15]||(t[15]=o()),d.scoring?(i(),E(x,{key:1,class:"icon scoring"})):h("",!0),t[16]||(t[16]=o()),r("span",Ca,[!d.subUnitsHaveOwnRows&&d.hasDeadModels?(i(),p("span",Ea,[r("span",Fa,m(d.survivingCount),1),o(" / "+m(n.unit.calcTotalUnitSize()),1)])):d.subUnitsHaveOwnRows?h("",!0):(i(),p("span",ka,m(d.totalUnitSize),1)),t[11]||(t[11]=o()),n.unit.getAmount()>1?(i(),p(C,{key:2},[o(m(n.unit.getAmount())+"x",1)],64)):h("",!0),t[12]||(t[12]=o()),n.unit.getCustomName()?(i(),p(C,{key:3},[o(m(n.unit.getCustomName())+" ",1),r("span",Da,"- "+m(n.unit.getName()),1)],64)):(i(),p(C,{key:4},[o(m(n.unit.getName()),1)],64)),t[13]||(t[13]=o()),d.playMode?h("",!0):(i(),E(y,{key:5,errors:d.errors,source:n.unit},null,8,["errors","source"])),t[14]||(t[14]=o()),d.unitPartialWoundsForTitle?(i(),p(C,{key:6},[w(b,{class:"skull-icon",size:"1em"}),r("span",Aa,m(d.unitPartialWoundsForTitle),1)],64)):h("",!0)]),t[17]||(t[17]=o()),r("span",{innerHTML:d.unitStatusText},null,8,Pa),t[18]||(t[18]=o()),d.costsLeft?h("",!0):(i(),p("span",{key:2,innerHTML:d.totalCost},null,8,Sa))]),t[20]||(t[20]=o()),N(e.$slots,"default",{unit:n.unit},void 0,!0)],2),t[23]||(t[23]=o()),d.optionsList?(i(),p("div",{key:0,class:"optionsList",style:{"white-space":"pre-wrap"},innerHTML:d.optionsListHtml},null,8,Ga)):h("",!0),t[24]||(t[24]=o()),d.playMode&&d.note&&d.note.length?(i(),p("div",Ba,m(d.note),1)):h("",!0)]),_:2},[d.swipeEnabled&&!d.associationChild?{name:"left",fn:k(()=>[r("div",ha,[w(u,{title:e.$referenceStore.getString("duplicate_unit")},null,8,["title"]),t[8]||(t[8]=o()),r("span",null,m(e.$referenceStore.getString("duplicate_unit")),1)])]),key:"0"}:void 0,d.swipeEnabled?{name:"right",fn:k(()=>[d.associationChild?(i(),p("div",xa,[w(g,{size:20,title:e.$referenceStore.getString("detach_unit")},null,8,["title"]),t[9]||(t[9]=o()),r("span",null,m(e.$referenceStore.getString("detach_unit")),1)])):(i(),p("div",ba,[w(c,{title:e.$referenceStore.getString("delete_unit")},null,8,["title"]),t[10]||(t[10]=o()),r("span",null,m(e.$referenceStore.getString("delete_unit")),1)]))]),key:"1"}:void 0]),1032,["disabled","right-color","onLeft","onRight"]),t[31]||(t[31]=o()),(i(!0),p(C,null,D(d.childs,L=>(i(),p(C,{key:L.getUid()},[L.getAmount()?(i(),E(Y,{key:0,unit:d.toUnit(L),class:"unitRow nested",style:{"margin-left":"8px"},categoryuid:"null",mode:n.mode,player:n.player,onEditUnit:t[1]||(t[1]=j=>e.$emit("edit-unit",j)),onListChange:t[2]||(t[2]=j=>e.$emit("list-change")),depth:n.depth+1,"association-parent":d.isAssociationChild(L)?n.unit:void 0,onDetach:j=>d.detachChild(L)},{default:k(()=>[r("div",Qa,[a.popupProfiles?(i(),E(F,{key:0,onClose:t[0]||(t[0]=j=>a.popupProfiles=null),width:"1200px",x:"",noclose:"",notitlebar:"",xtop:"10px",xright:"10px"},{default:k(()=>[w(v,{unit:a.popupProfiles},null,8,["unit"])]),_:1})):h("",!0),t[29]||(t[29]=o()),d.playMode?h("",!0):(i(),p("div",{key:1,class:"actions imgBt",onClick:B(j=>d.setPopupProfiles(L),["stop"])},[w(A,{title:e.$referenceStore.getString("view_profiles"),"stroke-mult":1.2},null,8,["title"])],8,Ua)),t[30]||(t[30]=o()),!d.playMode&&d.isAssociationChild(L)?(i(),p(C,{key:2},[e.$mainStore.mobileScreen?(i(),E(W,{key:0,anchorright:"",anchorleft:!1,capture:""},{trigger:k(()=>[r("div",$a,[w(S)])]),submenu:k(()=>[r("div",{class:"actions",onClick:B(j=>d.detachChild(L),["stop"])},[r("span",Ma,[w(g,{size:20,title:e.$referenceStore.getString("detach_from_unit")},null,8,["title"])]),o(" "+m(e.$referenceStore.getString("detach_from_unit")),1)],8,Ra),t[25]||(t[25]=o()),r("div",{class:"actions trash",onClick:B(j=>d.deleteChild(L),["stop"])},[r("span",Ha,[w(c,{title:e.$referenceStore.getString("delete_unit")},null,8,["title"])]),o(" "+m(e.$referenceStore.getString("delete_unit")),1)],8,Ia)]),_:2},1024)):(i(),p(C,{key:1},[r("div",{class:"actions imgBt",onClick:B(j=>d.detachChild(L),["stop"])},[w(g,{size:21,title:e.$referenceStore.getString("detach_from_unit")},null,8,["title"])],8,La),t[27]||(t[27]=o()),r("div",{class:"actions imgBt",onClick:B(j=>d.dupeChild(L),["stop"])},[w(u,{title:e.$referenceStore.getString("duplicate_unit"),strokeMult:.9},null,8,["title"])],8,Ta),t[28]||(t[28]=o()),r("div",{class:"actions imgBt trash",onClick:B(j=>d.deleteChild(L),["stop"])},[w(c,{title:e.$referenceStore.getString("delete_unit"),strokeMult:.95},null,8,["title"])],8,Oa)],64))],64)):h("",!0)])]),_:2},1032,["unit","mode","player","depth","association-parent","onDetach"])):h("",!0)],64))),128))],32)],34)}const qt=Object.assign(Q(st,[["render",Ya],["__scopeId","data-v-886591c4"]]),{__name:"UnitRow"}),ot=G({emits:["edit-unit","save-list","add-unit-to-category"],components:{CollapsibleBox:ne,ErrorIcon:X},setup(){return{store:te()}},props:{list:{required:!0,type:Object},category:{type:Object,required:!0},player:{required:!1,type:Object},mode:{type:Number,required:!0},custom:{type:Boolean,default:!1},mobile:{type:Boolean,default:!1}},data(){return{editingName:!1,categoryName:"",draggedOver:!1,pressTimer:void 0,collapsed:!1}},created(){this.categoryName=this.category.getName();const e=this.getCategoryKey();this.collapsed=this.$mainStore.getCollapsibleStatus(e)},methods:{isDetachmentUnit(e){const t=e.source;return((t?se(t,"name"):e.getName())||"").toLowerCase().includes("detachment")},dragOver(){this.draggedOver=!0},dragLeave(){this.draggedOver=!1},editUnit(e){if(this.store.dragged==null)this.$emit("edit-unit",e);else{const t=this.units.indexOf(e);this.dropItem(t)}},onTouchStart(e){var t;this.pressTimer&&clearTimeout(this.pressTimer),(t=this.metadata)!=null&&t.custom_view&&(this.playMode||this.store.dragged||(this.pressTimer=setTimeout(()=>{this.dragStart(e)},1e3)))},async onTouchEnd(){clearTimeout(this.pressTimer)},editName(e){e.stopPropagation(),this.editingName=!this.editingName,!this.editingName&&this.listRow&&(na(this.listRow,this.category.uid,this.categoryName),this.saveList())},async deleteCategory(){await customConfirm(this.$referenceStore.getString("lists_category_delete_confirm"))&&this.listRow&&sa(this.listRow,this.category.uid)&&this.saveList()},moveCategoryUp(){this.listRow&&(ta(this.listRow,this.category.uid),this.saveList())},saveList(){this.$emit("save-list")},onOpen(){this.collapsed=!1,this.saveCategoryCollapsedState()},onClose(){this.collapsed=!0,this.saveCategoryCollapsedState()},saveCategoryCollapsedState(){const e=this.getCategoryKey();this.$mainStore.setCollapsibleStatus(e,this.collapsed)},getCategoryKey(){var e;if(((e=this.system)==null?void 0:e.engine)==="t9a"){const t=this.list.row.list_key,n=this.category.getId?this.category.getId():this.category.getName();return`${t}_${n}`}else return this.category.uid},debug(e){console.log(e.getName(),e),window.$debugOption=e},dragStart(e){this.store.oldCategoryUid=this.category.uid,this.store.dragged=e},dropUnit(e){this.store.dragged&&(e.stopPropagation(),e.stopImmediatePropagation(),this.dropItem(0))},dropItem(e){e==-1&&this.category.getUnits().length!=0||(e==-1&&(e=0),this.store.dragged&&this.store.oldCategoryUid&&this.listRow&&oa(this.listRow,this.store.dragged.uid,this.store.oldCategoryUid,this.category.uid,e),this.saveList(),this.store.oldCategoryUid=null,this.store.dragged=null)},isUnitDead(e){var n,s,a,d;if(((s=(n=this.player)==null?void 0:n.unitStatuses[e.uid])==null?void 0:s.status)===2)return!0;if(((a=this.system)==null?void 0:a.engine)==="t9a")return!1;const t=(d=this.metadata)==null?void 0:d.casualties;return t?Le(e,t):!1},hasAliveLedUnits(e){var n;const t=this.metadata;if(!(t!=null&&t.leaders))return!1;for(const s in t.leaders)if(t.leaders[s].includes(e.uid)){const d=(n=this.list.army)==null?void 0:n.findUnit(s);if(d&&!this.isUnitDead(d))return!0}return!1},addUnitToCategory(){this.$emit("add-unit-to-category",this.category.getName())}},computed:{metadata(){var e;return(e=this.listRow)==null?void 0:e.metadata},listRow(){var t,n,s;const e=(n=(t=this.player)==null?void 0:t.list)==null?void 0:n.row;return e!=null&&e.metadata?e:(s=this.$listStore.currentList)==null?void 0:s.row},playMode(){const e=this.metadata;return(e==null?void 0:e.play_mode)===!0},gameAssist(){return this.mode===3},empty(){var e;return!((e=this.units)!=null&&e.length)},hasUnits(){return this.category.getAvailableUnits().some(e=>!e.isHidden())},flexTableList(){return this.$optionStore.options.flexTableList},flexItemWidth(){return`${this.$optionStore.options.flexTableItemWidth}px`},categoryConstraint(){var e;return Kt(this.system,this.category)||(this.collapsed&&((e=this.units)!=null&&e.length)?`(${this.units.length})`:"")},categoryLimit(){return qe(this.category)},editable(){return this.playMode?!1:this.custom&&this.category.uid!="uncategorized"},hidden(){var e,t,n;if(this.editable)return!1;if(this.playMode&&this.units.length==0)return!0;if(this.units.length>=1||this.category.isTracked())return!1;for(const s of this.category.calcTotalCosts())if(s.value!=0)return!1;return(e=this.errors)!=null&&e.length?!1:(n=(t=this.category).isHidden)!=null&&n.call(t)?!0:this.$optionStore.options.showEmptyCategoriesSmallScreen&&(!this.$mainStore.largeScreen||this.$optionStore.options.alwaysShowPlus)?this.category.getId()==="(Illegal Units)"||!this.category.getAvailableUnits().some(s=>!s.isHidden()):!0},units(){var n;let e=this.category.getUnits();const t=this.metadata;if(this.playMode&&(e=e.filter(s=>s.isExportable())),this.gameAssist&&this.category.getId()===ns.CONFIGURATION&&(e=e.filter(s=>this.isDetachmentUnit(s))),t!=null&&t.play_mode&&this.hasLeaders&&t.combineLeadersView!==!1&&(e=e.filter(s=>{var a;if(t.leaders){if((t.leaders[s.uid]||[]).filter(l=>{var g;const u=(g=this.list.army)==null?void 0:g.findUnit(l);return!(!u||u.isHidden()||u.getParentForce().isExportable()==!1&&t.play_mode)}).length>=1)return!1;for(const l in t.leaders)if((a=this.list.army)!=null&&a.findUnit(l)){const u=t.leaders[l].filter(g=>{var c;return(c=this.list.army)==null?void 0:c.findUnit(g)});if(u&&u.indexOf(s.uid)>=1)return!1}}return!0})),((n=this.system)==null?void 0:n.short)!=="t9a"&&this.$optionStore.options.groupAttachedUnits!==!1&&(e=e.filter(s=>{const a=s.getNestedAssociations("group").flatMap(d=>d.getAssociates());return a.length?!a.some(d=>{var u;const l=d.instance.getUnit();return l?!this.playMode||!(((u=t==null?void 0:t.leaders)==null?void 0:u[l.uid])||[]).length:!1}):!0})),this.playMode&&this.$optionStore.options.hideDeadUnits){const s=this.metadata,a=this.hasLeaders&&(s==null?void 0:s.combineLeadersView)!==!1;e=e.filter(d=>!this.isUnitDead(d)||a&&this.hasAliveLedUnits(d))}return e},system(){return this.$systemStore.selectedSystem},errors(){return this.category.getErrors()},hasLeaders(){const e=this.$systemStore.selectedSystem;return e?V(e).hasLeaders():!1},isCollapsed(){const e=this.getCategoryKey();return this.$mainStore.getCollapsibleStatus(e)}},watch:{category(){this.categoryName=this.category.getName()}}}),yt=()=>{Ut(e=>({b40ae03c:e.flexItemWidth}))},vt=ot.setup;ot.setup=vt?(e,t)=>(yt(),vt(e,t)):yt;const Na={key:0},Va={key:1,class:"category-name"},ja=["innerHTML"],Wa=["innerHTML"],Xa={class:"rightButtons"};function za(e,t,n,s,a,d){const l=ye,u=X,g=Pe,c=Pn,x=Se,y=Xe,b=qt,f=ne;return i(),p("div",{class:T(["category",{hidden:e.hidden,draggedOverCat:e.draggedOver&&e.empty,gameAssist:e.mode===3}]),onDrop:t[6]||(t[6]=v=>e.dropItem(-1)),onDragover:t[7]||(t[7]=B((...v)=>e.dragOver&&e.dragOver(...v),["prevent"])),onDragleave:t[8]||(t[8]=(...v)=>e.dragLeave&&e.dragLeave(...v)),onClick:t[9]||(t[9]=(...v)=>e.dropUnit&&e.dropUnit(...v))},[e.hidden?h("",!0):(i(),p("div",Na,[w(f,{title:"titreCategory",nobox:!0,collapsible:!e.empty,icon:!e.$mainStore.mobileScreen,defcollapsed:e.isCollapsed,locked:e.store.dragged!=null,"icon-location":"right",onOpen:e.onOpen,onClose:e.onClose},{title:k(()=>[r("span",{onMouseup:t[2]||(t[2]=B(v=>e.debug(e.category),["middle","stop"]))},[e.editingName?(i(),E(l,{key:0,class:"inputlike",style:{display:"inline-block"},modelValue:e.categoryName,"onUpdate:modelValue":t[0]||(t[0]=v=>e.categoryName=v),ref:"rename",type:"text",onClick:t[1]||(t[1]=B(()=>{},["stop"])),onDone:e.editName,single:""},null,8,["modelValue","onDone"])):(i(),p("span",Va,m(e.category.getName()),1)),t[10]||(t[10]=o()),e.playMode?h("",!0):(i(),E(u,{key:2,errors:e.errors,source:e.category},null,8,["errors","source"])),t[11]||(t[11]=o()),e.editable?(i(),E(g,{key:3,class:"imgBt editname",title:e.$referenceStore.getString("lists_category_edit_name"),onClick:e.editName},null,8,["title","onClick"])):h("",!0),t[12]||(t[12]=o()),e.mode!=3?(i(),p("span",{key:4,innerHTML:e.categoryLimit},null,8,ja)):h("",!0),t[13]||(t[13]=o()),r("span",{class:"constraint",innerHTML:e.categoryConstraint},null,8,Wa)],32),t[16]||(t[16]=o()),r("div",Xa,[e.editable&&!e.playMode?(i(),p("span",{key:0,class:"imgBt",onClick:t[3]||(t[3]=B((...v)=>e.moveCategoryUp&&e.moveCategoryUp(...v),["stop"]))},[w(c)])):h("",!0),t[14]||(t[14]=o()),e.editable?(i(),p("span",{key:1,class:"imgBt trash",onClick:t[4]||(t[4]=B((...v)=>e.deleteCategory&&e.deleteCategory(...v),["stop"]))},[w(x)])):h("",!0),t[15]||(t[15]=o()),e.mobile&&!e.playMode&&e.hasUnits?(i(),p("div",{key:2,onClick:t[5]||(t[5]=B((...v)=>e.addUnitToCategory&&e.addUnitToCategory(...v),["stop"])),class:"hover-darken clickable plusButton"},[w(y,{class:"plusIcon icon",size:29})])):h("",!0)])]),content:k(()=>{var v;return[(e.mode==0||e.mode==3)&&((v=e.units)==null?void 0:v.length)>=1?(i(),p("div",{key:0,class:T({categoryFlex:e.$optionStore.options.flexTableList})},[(i(!0),p(C,null,D(e.units,(F,A)=>(i(),E(b,{key:F.uid,draggable:e.custom&&!e.playMode,mode:e.mode==3?1:0,categoryuid:e.category.uid,unit:F,player:e.player,onDragstart:S=>e.dragStart(F),onListChange:e.saveList,onEditUnit:e.editUnit,onDrop:S=>e.dropItem(A),onTouchstartPassive:S=>e.onTouchStart(F),onTouchend:e.onTouchEnd},{default:k(()=>[N(e.$slots,"default",{unit:F},void 0,!0)]),_:2},1032,["draggable","mode","categoryuid","unit","player","onDragstart","onListChange","onEditUnit","onDrop","onTouchstartPassive","onTouchend"]))),128)),t[17]||(t[17]=o()),e.flexTableList?(i(),p(C,{key:0},D(6,F=>r("div",{key:F})),64)):h("",!0)],2)):h("",!0)]}),_:3},8,["collapsible","icon","defcollapsed","locked","onOpen","onClose"])]))],34)}const Za=Object.assign(Q(ot,[["render",za],["__scopeId","data-v-466db378"]]),{__name:"ListsCategory"}),Ka=G({components:{PopupDialog:H},name:"ForceList",props:{items:{type:Array,default:()=>[],required:!1},for:{type:String,default:""}},computed:{title(){return this.for?this.$referenceStore.getString("lists_select_force_replace").replace("{force}",this.for):this.$referenceStore.getString("lists_select_force")}}}),Ja={class:"contentTable"},qa=["onClick"],_a={class:"block"},el={class:"presetName"};function tl(e,t,n,s,a,d){const l=H;return i(),E(l,{onClose:t[0]||(t[0]=u=>e.$emit("cancel")),text:e.$referenceStore.getString("cancel")},{default:k(()=>[r("h2",null,m(e.title),1),t[3]||(t[3]=o()),r("div",Ja,[r("table",null,[r("tbody",null,[(i(!0),p(C,null,D(e.items,u=>(i(),p(C,null,[u.getHidden()?h("",!0):(i(),p("tr",{key:0,class:"itemRow",onClick:g=>e.$emit("select",u)},[r("td",null,[r("div",_a,[r("span",el,m(u.getName()),1),t[1]||(t[1]=o()),t[2]||(t[2]=r("span",{class:"presetAge"},null,-1))])])],8,qa))],64))),256))])])])]),_:1},8,["text"])}const nl=Object.assign(Q(Ka,[["render",tl],["__scopeId","data-v-a3f1c526"]]),{__name:"ListsForceList"}),sl=["txt","pdf","pretty","templates","rosz","ros","json","close","yellow","nryellow","spells","twohg","share"],ol=G({props:{system:{type:Object,required:!0},hideLink:{type:Boolean,default:!1},hideRos:{type:Boolean,default:!1}},emits:[...sl],methods:{emit(e){this.$emit(e)}},computed:{bs(){return this.system.engine==="bs"},wh40k(){return this.system.short.includes("wh40k")},isAdmin(){return this.$userStore.isAdmin()},has2hg(){return!1}}}),wt=_e("/assets/icons/bs.png"),rl=_e("/assets/icons/yellowscribe.png"),il=_e("/assets/icons/2hg.png"),al={class:"section"},ll={class:"exports"},dl={style:{"text-align":"center"}},pl=["innerHTML"],ul={key:0,class:"section"},cl={class:"underline",href:"https://2ndhandgeek.com/signup?r=66e04210-ef15-4bc6-ad72-1400f740c7ff"};function gl(e,t,n,s,a,d){const l=Sn,u=Gn,g=Bn,c=Mt;return i(),p("div",null,[r("div",al,[r("div",ll,[r("div",{onClick:t[0]||(t[0]=x=>e.emit("txt")),class:"imgBt"},[w(l,{size:24}),t[11]||(t[11]=o()),r("span",null,m(e.$referenceStore.getString("text")),1)]),t[26]||(t[26]=o()),e.bs?h("",!0):(i(),p("div",{key:0,onClick:t[1]||(t[1]=x=>e.emit("pdf")),class:"imgBt"},[w(u,{size:24}),t[12]||(t[12]=o()),r("span",null,m(e.$referenceStore.getString("pdf")),1)])),t[27]||(t[27]=o()),r("div",{onClick:t[2]||(t[2]=x=>e.emit("pretty")),class:"imgBt"},[w(u,{size:24}),t[13]||(t[13]=o()),r("span",null,m(e.$referenceStore.getString("pretty")),1)]),t[28]||(t[28]=o()),e.bs?(i(),p("div",{key:1,onClick:t[3]||(t[3]=x=>e.emit("templates")),class:"imgBt"},[w(u,{size:24}),t[14]||(t[14]=o()),r("span",dl,m(e.$referenceStore.getString("templates")),1)])):h("",!0),t[29]||(t[29]=o()),e.bs&&!e.hideRos?(i(),p("div",{key:2,onClick:t[4]||(t[4]=x=>e.emit("rosz")),class:"imgBt"},[...t[15]||(t[15]=[r("img",{src:wt},null,-1),o(),r("span",null,".rosz",-1)])])):h("",!0),t[30]||(t[30]=o()),e.bs&&!e.hideRos?(i(),p("div",{key:3,onClick:t[5]||(t[5]=x=>e.emit("ros")),class:"imgBt"},[...t[16]||(t[16]=[r("img",{src:wt},null,-1),o(),r("span",null,".ros",-1)])])):h("",!0),t[31]||(t[31]=o()),e.bs?(i(),p("div",{key:4,onClick:t[6]||(t[6]=x=>e.emit("json")),class:"imgBt"},[w(g,{size:24}),t[17]||(t[17]=o()),t[18]||(t[18]=r("span",null,"json",-1))])):h("",!0),t[32]||(t[32]=o()),e.wh40k||e.isAdmin?(i(),p("div",{key:5,onClick:t[7]||(t[7]=x=>e.emit("nryellow")),class:"imgBt"},[t[19]||(t[19]=r("img",{src:rl},null,-1)),t[20]||(t[20]=o()),r("span",{innerHTML:e.$referenceStore.getString("export_yellow_scribe")},null,8,pl)])):h("",!0),t[33]||(t[33]=o()),e.system.spells?(i(),p("div",{key:6,onClick:t[8]||(t[8]=x=>e.emit("spells")),class:"imgBt"},[w(u,{class:"txt",size:24}),t[22]||(t[22]=o()),r("span",null,[o(m(e.$referenceStore.getString("spells")),1),t[21]||(t[21]=r("br",null,null,-1)),o("("+m(e.$referenceStore.getString("pdf"))+")",1)])])):h("",!0),t[34]||(t[34]=o()),e.has2hg?(i(),p("div",{key:7,onClick:t[9]||(t[9]=x=>e.emit("twohg"))},[t[23]||(t[23]=r("img",{alt:"export 2 handed geek",src:il,class:"imgBt thg"},null,-1)),t[24]||(t[24]=o()),r("span",null,m(e.$referenceStore.getString("2nd_hand_geek")),1)])):h("",!0),t[35]||(t[35]=o()),e.hideLink?h("",!0):(i(),p("div",{key:8,onClick:t[10]||(t[10]=x=>e.emit("share")),class:"imgBt"},[w(c,{size:24}),t[25]||(t[25]=o()),r("span",null,m(e.$referenceStore.getString("link")),1)]))]),t[39]||(t[39]=o()),e.has2hg?(i(),p("p",ul,[o(m(e.$referenceStore.getString("with_2hg_promo")),1),t[36]||(t[36]=r("br",null,null,-1)),t[37]||(t[37]=r("br",null,null,-1)),o(" "+m(e.$referenceStore.getString("click_link_if_interested"))+" ",1),r("a",cl,m(e.$referenceStore.getString("this_link")),1),t[38]||(t[38]=o(`.
      `,-1))])):h("",!0)])])}const _t=Object.assign(Q(ol,[["render",gl],["__scopeId","data-v-f019673d"]]),{__name:"ExportPanel"}),fl=G({name:"PillTabs",emits:["update:modelValue"],props:{modelValue:{type:String,default:""},items:{type:Array,required:!0},wrap:{type:Boolean,default:!1}},data(){return{canLeft:!1,canRight:!1}},mounted(){this.update(),this.scrollToSelected(!1),window.addEventListener("resize",this.update)},unmounted(){window.removeEventListener("resize",this.update)},watch:{modelValue(){this.$nextTick(()=>this.scrollToSelected(!0))},items(){this.$nextTick(this.update)}},methods:{update(){const e=this.$refs.row;!e||this.wrap||(this.canLeft=e.scrollLeft>2,this.canRight=e.scrollLeft<e.scrollWidth-e.clientWidth-2)},scrollToSelected(e){var n;const t=this.$refs.row;(n=t==null?void 0:t.querySelector(".sel"))==null||n.scrollIntoView({behavior:e?"smooth":"instant",inline:"nearest",block:"nearest"}),this.update()}}}),ml={class:"pill-tabs"},hl=["onClick"];function xl(e,t,n,s,a,d){return i(),p("div",ml,[r("div",{class:T(["row",{fadeL:e.canLeft,fadeR:e.canRight,wrap:e.wrap}]),ref:"row",onScrollPassive:t[0]||(t[0]=(...l)=>e.update&&e.update(...l))},[(i(!0),p(C,null,D(e.items,l=>(i(),p("button",{key:l,type:"button",class:T(["pill",{sel:l===e.modelValue}]),onClick:u=>e.$emit("update:modelValue",l)},m(l),11,hl))),128))],34)])}const en=Object.assign(Q(fl,[["render",xl],["__scopeId","data-v-5fea7405"]]),{__name:"PillTabs"}),bl=G({components:{TextExport:Xt,PopupDialog:H,PillTabs:en},props:{list:{required:!0,type:Object},onlyExportable:{type:Boolean,default:!1}},data(){return{format:"",includePlayerName:!1,includeTeamName:!1,characterCount:0,copied:!1,copiedTimer:null,exported:!1}},created(){this.$optionStore.options.textFormat.playerName!=null&&(this.includePlayerName=!0),this.$optionStore.options.textFormat.teamName!=null&&(this.includeTeamName=!0)},unmounted(){this.exported&&is()},watch:{format(e){e&&this.$optionStore.setSystemOption(this.systemId,"exportFormat",e)}},computed:{army(){return this.list&&this.list.army||null},mobile(){return this.$mainStore.mobileMode||this.$mainStore.smallScreen},systemId(){var e;return((e=this.army)==null?void 0:e.getBook().getSystem().id)??null},wtc(){return this.format.includes("WTC")||this.format==="GW"||this.format==="Tournament"},supportsConstants(){return this.format==="NR"||this.wtc||this.format==="Tournament"},formats(){if(this.army&&this.t9a===!1){const e=Array.from(new Set([...this.army.exportFormats(),"NR","Simple"]));return this.selectInitialFormat(e),e}return[]},t9a(){var e;return((e=this.army)==null?void 0:e.getBook().getSystem().engine)==="t9a"},t9aOptions(){return this.t9a||this.format==="T9A"},canShare(){return rs()&&this.mobile}},methods:{async share(){const e=this.$refs.export;if(e!=null&&e.html)try{await os(ke(e.html),this.list.row.name),this.exported=!0}catch{}},download(){const e=this.$refs.export;if(!(e!=null&&e.html))return;const t=ke(e.html);ss.saveAs(new Blob([t],{type:"text/plain;charset=utf-8"}),`${this.list.row.name||"list"}.txt`),this.exported=!0},clip(){const e=this.$refs.export;e!=null&&e.html&&(Tt(ke(e.html)),this.exported=!0,this.copied=!0,this.copiedTimer&&clearTimeout(this.copiedTimer),this.copiedTimer=setTimeout(()=>this.copied=!1,1500))},playerNameChange(){var e;this.includePlayerName===!1?this.$optionStore.options.textFormat.playerName=void 0:this.$optionStore.options.textFormat.playerName=((e=this.$userStore.user)==null?void 0:e.login)||this.$referenceStore.getString("player"),this.updateOptions("textFormat")},teamNameChange(){this.includeTeamName===!1?this.$optionStore.options.textFormat.teamName=void 0:this.$optionStore.options.textFormat.teamName=this.$referenceStore.getString("my_team"),this.updateOptions("textFormat")},selectInitialFormat(e){var t;if(!this.format&&(e!=null&&e.length)){const n=(t=this.$optionStore.options.systemOptions[this.systemId??""])==null?void 0:t.exportFormat;this.format=n&&e.includes(n)?n:e[0]}},async updateOptions(e){await this.$optionStore.updateOptions(e)}}}),yl={key:0,class:"split"},vl={class:"side"},wl={class:"group-label"},Cl=["onClick"],El={class:"group-label"},Fl={class:"check"},kl={for:"cbSweed"},Dl={class:"check"},Al={for:"addX"},Pl={class:"check"},Sl={for:"catRecap"},Gl={class:"check"},Bl={for:"cbPlayerName"},Ql={key:0,class:"group-label"},Ul={key:1,class:"check"},$l={for:"constant"},Rl={key:2,class:"check"},Ml={for:"includeHeader"},Il={class:"check"},Hl={class:"check"},Ll={class:"check"},Tl={class:"group-label"},Ol={class:"check"},Yl={for:"discord"},Nl={class:"check"},Vl={for:"cbPlayerName"},jl={class:"check"},Wl={for:"cbTeamName"},Xl={class:"main"},zl={class:"foot"},Zl={class:"count"},Kl={class:"stack"},Jl={key:1,class:"sheet"},ql={key:0,class:"opt-grid"},_l={key:0,class:"opt"},ed={key:1,class:"opt"},td={class:"opt"},nd={class:"opt"},sd={class:"opt"},od={class:"opt full"},rd={key:0},id={class:"opt full"},ad={key:0},ld={key:1,class:"opt-grid single"},dd={class:"opt"},pd={class:"opt"},ud={class:"opt"},cd={class:"sheet-foot"},gd={class:"stack"};function fd(e,t,n,s,a,d){const l=Xt,u=Qn,g=Ze,c=Un,x=en,y=Mt,b=H;return i(),E(b,{width:e.mobile?void 0:"980px",x:"",noclose:""},{header:k(()=>[o(m(e.$referenceStore.getString("text_export")),1)]),default:k(()=>[t[126]||(t[126]=o()),e.mobile?(i(),p("div",Jl,[w(x,{modelValue:e.format,"onUpdate:modelValue":t[32]||(t[32]=f=>e.format=f),items:e.formats,wrap:"",class:"chips"},null,8,["modelValue","items"]),t[123]||(t[123]=o()),!e.t9aOptions&&(e.supportsConstants||e.wtc||e.format==="NR")?(i(),p("div",ql,[e.supportsConstants?(i(),p("label",_l,[r("span",null,m(e.$referenceStore.getString("export_opt_constants")),1),t[100]||(t[100]=o()),P(r("input",{"onUpdate:modelValue":t[33]||(t[33]=f=>e.$optionStore.options.textFormat.includeConstants=f),type:"checkbox",class:"sw",onChange:t[34]||(t[34]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.includeConstants]])])):h("",!0),t[113]||(t[113]=o()),e.wtc?(i(),p("label",ed,[r("span",null,m(e.$referenceStore.getString("export_opt_header")),1),t[101]||(t[101]=o()),P(r("input",{"onUpdate:modelValue":t[35]||(t[35]=f=>e.$optionStore.options.textFormat.includeHeader=f),type:"checkbox",class:"sw",onChange:t[36]||(t[36]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.includeHeader]])])):h("",!0),t[114]||(t[114]=o()),e.format==="NR"?(i(),p(C,{key:2},[r("label",td,[t[102]||(t[102]=r("span",null,"Categories",-1)),t[103]||(t[103]=o()),P(r("input",{"onUpdate:modelValue":t[37]||(t[37]=f=>e.$optionStore.options.textFormat.includeCategories=f),type:"checkbox",class:"sw",onChange:t[38]||(t[38]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.includeCategories]])]),t[108]||(t[108]=o()),r("label",nd,[t[104]||(t[104]=r("span",null,"Forces",-1)),t[105]||(t[105]=o()),P(r("input",{"onUpdate:modelValue":t[39]||(t[39]=f=>e.$optionStore.options.textFormat.includeForces=f),type:"checkbox",class:"sw",onChange:t[40]||(t[40]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.includeForces]])]),t[109]||(t[109]=o()),r("label",sd,[t[106]||(t[106]=r("span",null,"Units without models",-1)),t[107]||(t[107]=o()),P(r("input",{"onUpdate:modelValue":t[41]||(t[41]=f=>e.$optionStore.options.textFormat.includeWithoutModels=f),type:"checkbox",class:"sw",onChange:t[42]||(t[42]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.includeWithoutModels]])])],64)):h("",!0),t[115]||(t[115]=o()),e.wtc&&e.$optionStore.options.textFormat.includeHeader?(i(),p(C,{key:3},[r("div",od,[e.includePlayerName?P((i(),p("input",{key:1,"onUpdate:modelValue":t[43]||(t[43]=f=>e.$optionStore.options.textFormat.playerName=f),type:"text",class:"inline",onChange:t[44]||(t[44]=f=>e.updateOptions("textFormat"))},null,544)),[[q,e.$optionStore.options.textFormat.playerName]]):(i(),p("span",rd,m(e.$referenceStore.getString("export_opt_player_name")),1)),t[110]||(t[110]=o()),P(r("input",{"onUpdate:modelValue":t[45]||(t[45]=f=>e.includePlayerName=f),type:"checkbox",class:"sw",onChange:t[46]||(t[46]=(...f)=>e.playerNameChange&&e.playerNameChange(...f))},null,544),[[I,e.includePlayerName]])]),t[112]||(t[112]=o()),r("div",id,[e.includeTeamName?P((i(),p("input",{key:1,"onUpdate:modelValue":t[47]||(t[47]=f=>e.$optionStore.options.textFormat.teamName=f),type:"text",class:"inline",onChange:t[48]||(t[48]=f=>e.updateOptions("textFormat"))},null,544)),[[q,e.$optionStore.options.textFormat.teamName]]):(i(),p("span",ad,m(e.$referenceStore.getString("export_opt_team_name")),1)),t[111]||(t[111]=o()),P(r("input",{"onUpdate:modelValue":t[49]||(t[49]=f=>e.includeTeamName=f),type:"checkbox",class:"sw",onChange:t[50]||(t[50]=(...f)=>e.teamNameChange&&e.teamNameChange(...f))},null,544),[[I,e.includeTeamName]])])],64)):h("",!0)])):e.t9aOptions?(i(),p("div",ld,[r("label",dd,[r("span",null,m(e.$referenceStore.getString("shift_point_costs")),1),t[116]||(t[116]=o()),P(r("input",{"onUpdate:modelValue":t[51]||(t[51]=f=>e.$optionStore.options.textFormat.sweedish=f),type:"checkbox",class:"sw",onChange:t[52]||(t[52]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.sweedish]])]),t[119]||(t[119]=o()),r("label",pd,[r("span",null,m(e.$referenceStore.getString("add_x_unit")),1),t[117]||(t[117]=o()),P(r("input",{"onUpdate:modelValue":t[53]||(t[53]=f=>e.$optionStore.options.textFormat.addX=f),type:"checkbox",class:"sw",onChange:t[54]||(t[54]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.addX]])]),t[120]||(t[120]=o()),r("label",ud,[r("span",null,m(e.$referenceStore.getString("insert_category_recap")),1),t[118]||(t[118]=o()),P(r("input",{"onUpdate:modelValue":t[55]||(t[55]=f=>e.$optionStore.options.textFormat.catRecap=f),type:"checkbox",class:"sw",onChange:t[56]||(t[56]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.catRecap]])])])):h("",!0),t[124]||(t[124]=o()),w(l,{ref:"export",class:"output",list:e.list,name:!0,options:!0,format:e.format,textformat:e.onlyExportable?{onlyExportable:!0}:void 0,onSize:t[57]||(t[57]=f=>e.characterCount=f)},null,8,["list","format","textformat"]),t[125]||(t[125]=o()),r("div",cd,[e.canShare?(i(),p("button",{key:0,class:"btn wide",onClick:t[58]||(t[58]=(...f)=>e.share&&e.share(...f))},[w(y,{size:15}),o(m(e.$referenceStore.getString("models_share")),1)])):h("",!0),t[122]||(t[122]=o()),r("button",{class:T(["btn wide",{ghost:e.canShare}]),onClick:t[59]||(t[59]=(...f)=>e.clip&&e.clip(...f))},[r("span",gd,[r("span",{class:T({ghostLabel:e.copied})},[w(g,{size:15}),o(m(e.$referenceStore.getString("copy")),1)],2),t[121]||(t[121]=o()),r("span",{class:T({ghostLabel:!e.copied})},[w(c,{size:15}),o(m(e.$referenceStore.getString("copied")),1)],2)])],2)])])):(i(),p("div",yl,[r("div",vl,[e.formats&&e.formats.length>1?(i(),p(C,{key:0},[r("div",wl,m(e.$referenceStore.getString("export_format")),1),t[60]||(t[60]=o()),(i(!0),p(C,null,D(e.formats,f=>(i(),p("button",{key:f,type:"button",class:T(["fmt",{sel:e.format===f}]),onClick:v=>e.format=f},m(f),11,Cl))),128))],64)):h("",!0),t[92]||(t[92]=o()),e.t9aOptions?(i(),p(C,{key:1},[r("div",El,m(e.$referenceStore.getString("export_options")),1),t[65]||(t[65]=o()),r("div",Fl,[P(r("input",{id:"cbSweed","onUpdate:modelValue":t[0]||(t[0]=f=>e.$optionStore.options.textFormat.sweedish=f),type:"checkbox",onChange:t[1]||(t[1]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.sweedish]]),t[61]||(t[61]=o()),r("label",kl,m(e.$referenceStore.getString("shift_point_costs")),1)]),t[66]||(t[66]=o()),r("div",Dl,[P(r("input",{id:"addX","onUpdate:modelValue":t[2]||(t[2]=f=>e.$optionStore.options.textFormat.addX=f),type:"checkbox",onChange:t[3]||(t[3]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.addX]]),t[62]||(t[62]=o()),r("label",Al,m(e.$referenceStore.getString("add_x_unit")),1)]),t[67]||(t[67]=o()),r("div",Pl,[P(r("input",{id:"catRecap","onUpdate:modelValue":t[4]||(t[4]=f=>e.$optionStore.options.textFormat.catRecap=f),type:"checkbox",onChange:t[5]||(t[5]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.catRecap]]),t[63]||(t[63]=o()),r("label",Sl,m(e.$referenceStore.getString("insert_category_recap")),1)]),t[68]||(t[68]=o()),r("div",Gl,[P(r("input",{id:"cbPlayerName","onUpdate:modelValue":t[6]||(t[6]=f=>e.includePlayerName=f),type:"checkbox",onChange:t[7]||(t[7]=(...f)=>e.playerNameChange&&e.playerNameChange(...f))},null,544),[[I,e.includePlayerName]]),t[64]||(t[64]=o()),r("label",Bl,m(e.$referenceStore.getString("export_opt_player_name")),1)]),t[69]||(t[69]=o()),e.includePlayerName?P((i(),p("input",{key:0,"onUpdate:modelValue":t[8]||(t[8]=f=>e.$optionStore.options.textFormat.playerName=f),type:"text",onChange:t[9]||(t[9]=f=>e.updateOptions("textFormat"))},null,544)),[[q,e.$optionStore.options.textFormat.playerName]]):h("",!0)],64)):(i(),p(C,{key:2},[e.supportsConstants||e.wtc||e.format==="NR"?(i(),p("div",Ql,m(e.$referenceStore.getString("export_group_content")),1)):h("",!0),t[86]||(t[86]=o()),e.supportsConstants?(i(),p("div",Ul,[P(r("input",{id:"constant","onUpdate:modelValue":t[10]||(t[10]=f=>e.$optionStore.options.textFormat.includeConstants=f),type:"checkbox",onChange:t[11]||(t[11]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.includeConstants]]),t[70]||(t[70]=o()),r("label",$l,m(e.$referenceStore.getString("export_opt_constants")),1)])):h("",!0),t[87]||(t[87]=o()),e.wtc?(i(),p("div",Rl,[P(r("input",{id:"includeHeader","onUpdate:modelValue":t[12]||(t[12]=f=>e.$optionStore.options.textFormat.includeHeader=f),type:"checkbox",onChange:t[13]||(t[13]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.includeHeader]]),t[71]||(t[71]=o()),r("label",Ml,m(e.$referenceStore.getString("export_opt_header")),1)])):h("",!0),t[88]||(t[88]=o()),e.format==="NR"?(i(),p(C,{key:3},[r("div",Il,[P(r("input",{id:"categories","onUpdate:modelValue":t[14]||(t[14]=f=>e.$optionStore.options.textFormat.includeCategories=f),type:"checkbox",onChange:t[15]||(t[15]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.includeCategories]]),t[72]||(t[72]=o()),t[73]||(t[73]=r("label",{for:"categories"},"Categories",-1))]),t[78]||(t[78]=o()),r("div",Hl,[P(r("input",{id:"forces","onUpdate:modelValue":t[16]||(t[16]=f=>e.$optionStore.options.textFormat.includeForces=f),type:"checkbox",onChange:t[17]||(t[17]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.includeForces]]),t[74]||(t[74]=o()),t[75]||(t[75]=r("label",{for:"forces"},"Forces",-1))]),t[79]||(t[79]=o()),r("div",Ll,[P(r("input",{id:"models","onUpdate:modelValue":t[18]||(t[18]=f=>e.$optionStore.options.textFormat.includeWithoutModels=f),type:"checkbox",onChange:t[19]||(t[19]=f=>e.updateOptions("textFormat"))},null,544),[[I,e.$optionStore.options.textFormat.includeWithoutModels]]),t[76]||(t[76]=o()),t[77]||(t[77]=r("label",{for:"models"},"Units without models",-1))])],64)):h("",!0),t[89]||(t[89]=o()),r("div",Tl,m(e.$referenceStore.getString("export_group_sharing")),1),t[90]||(t[90]=o()),r("div",Ol,[P(r("input",{id:"discord","onUpdate:modelValue":t[20]||(t[20]=f=>e.$optionStore.options.textFormat.discord=f),type:"checkbox"},null,512),[[I,e.$optionStore.options.textFormat.discord]]),t[80]||(t[80]=o()),r("label",Yl,m(e.$referenceStore.getString("split_discord")),1)]),t[91]||(t[91]=o()),e.wtc?(i(),p(C,{key:4},[r("div",Nl,[P(r("input",{id:"cbPlayerName","onUpdate:modelValue":t[21]||(t[21]=f=>e.includePlayerName=f),type:"checkbox",onChange:t[22]||(t[22]=(...f)=>e.playerNameChange&&e.playerNameChange(...f))},null,544),[[I,e.includePlayerName]]),t[81]||(t[81]=o()),r("label",Vl,m(e.$referenceStore.getString("export_opt_player_name")),1)]),t[83]||(t[83]=o()),e.includePlayerName?P((i(),p("input",{key:0,"onUpdate:modelValue":t[23]||(t[23]=f=>e.$optionStore.options.textFormat.playerName=f),type:"text",onChange:t[24]||(t[24]=f=>e.updateOptions("textFormat"))},null,544)),[[q,e.$optionStore.options.textFormat.playerName]]):h("",!0),t[84]||(t[84]=o()),r("div",jl,[P(r("input",{id:"cbTeamName","onUpdate:modelValue":t[25]||(t[25]=f=>e.includeTeamName=f),type:"checkbox",onChange:t[26]||(t[26]=(...f)=>e.teamNameChange&&e.teamNameChange(...f))},null,544),[[I,e.includeTeamName]]),t[82]||(t[82]=o()),r("label",Wl,m(e.$referenceStore.getString("export_opt_team_name")),1)]),t[85]||(t[85]=o()),e.includeTeamName?P((i(),p("input",{key:1,"onUpdate:modelValue":t[27]||(t[27]=f=>e.$optionStore.options.textFormat.teamName=f),type:"text",onChange:t[28]||(t[28]=f=>e.updateOptions("textFormat"))},null,544)),[[q,e.$optionStore.options.textFormat.teamName]]):h("",!0)],64)):h("",!0)],64))]),t[99]||(t[99]=o()),r("div",Xl,[w(l,{ref:"export",class:"output",list:e.list,name:!0,options:!0,format:e.format,textformat:e.onlyExportable?{onlyExportable:!0}:void 0,onSize:t[29]||(t[29]=f=>e.characterCount=f)},null,8,["list","format","textformat"]),t[98]||(t[98]=o()),r("div",zl,[r("span",Zl,m(e.characterCount)+" "+m(e.$referenceStore.getString("characters")),1),t[94]||(t[94]=o()),t[95]||(t[95]=r("span",{class:"spacer"},null,-1)),t[96]||(t[96]=o()),r("button",{class:"btn ghost",onClick:t[30]||(t[30]=(...f)=>e.download&&e.download(...f))},[w(u,{size:15}),o(m(e.$referenceStore.getString("download"))+" .txt",1)]),t[97]||(t[97]=o()),r("button",{class:"btn",onClick:t[31]||(t[31]=(...f)=>e.clip&&e.clip(...f))},[r("span",Kl,[r("span",{class:T({ghostLabel:e.copied})},[w(g,{size:15}),o(m(e.$referenceStore.getString("copy_to_clipboard")),1)],2),t[93]||(t[93]=o()),r("span",{class:T({ghostLabel:!e.copied})},[w(c,{size:15}),o(m(e.$referenceStore.getString("copied")),1)],2)])])])])]))]),_:1},8,["width"])}const md=Object.assign(Q(bl,[["render",fd],["__scopeId","data-v-55759fe7"]]),{__name:"ListsExport"});function ee(e,t){if(!t)return[];if(t.sort&&!t.grouped&&(e=_(e,n=>n.name)),t.include){const n=t.include;e=e.filter(s=>!!(s.kind&&n.includes(s.kind)||n.includes((se(s,"typeName")??"").toLowerCase())))}if(t.exclude){const n=t.exclude;e=e.filter(s=>!(s.kind&&n.includes(s.kind)||n.includes((se(s,"typeName")??"").toLowerCase())))}if((t==null?void 0:t.dedupe)!=!1&&!t.grouped&&(e=as(e,t.amount)),t.grouped){let n=ls(e,t.large||40,t.amount);if(t.sort&&(n=n.map(s=>_(s,a=>a.name))),t.order){const s=t.order;n=_(n,a=>{const d=s.indexOf((se(a[0],"typeName")??"").toLowerCase());return d===-1?s.length:d})}return n}if(t.order){const n=t.order;e=_(e,s=>{const a=n.indexOf((se(s,"typeName")??"").toLowerCase());return a===-1?n.length:a})}return e}function hd(e){const t=[];for(const n of e){const s=n.getAllUnits();s.length?(he(n,{constants:!0,costs:!1,units:!1,trim:!0})&&t.push(n),t.push(...s)):t.push(n)}return t}function tn(e){return e.getUnits().filter(t=>t.isExportable())}function nn(e,t){const n=[];for(const s of me(e.getCategories().filter(a=>a.isExportable()),t))n.push(...tn(s));return n}function xd(e,t){const n=[];for(const s of e.getForces().filter(a=>a.isExportable()))n.push(...nn(s,t));return n}function bd(e,t={}){return e.isCategory()?tn(e):e.isForce()?nn(e,t):e.isRoster()?xd(e,t):[]}function ue(e,t){if(t.flatten&&(e=hd(e)),e=e.filter(n=>t.includeEmpty===!1?n.calcOptionsList().length>0:!0),t.dedupe&&(e=ge(e,t.dedupe)),t.sort&&(t.sort==="name-asc"&&(e=_(e,n=>n.getName())),t.sort==="name-desc"&&(e=Qe(e,n=>n.getName()))),t.order){const n=t.order;e=_(e,s=>{const a=n.indexOf(s.getName());return a===-1?n.length:a})}return e}const yd=new Set(["add","minus","multiply","divide","modulo"]),vd=new Set(["toLowerCase","toUpperCase","trim","replace","replaceAll","match","matchAll","find","startswith","endswith","split","includes"]),Te={isNaN,isFinite,parseInt,parseFloat,Number,BigInt,Math,Date,String,Boolean,Symbol,Object,Array,RegExp,JSON,encodeURI,decodeURI,encodeURIComponent,decodeURIComponent,Map,Set,WeakMap,WeakSet,Error,EvalError,RangeError,ReferenceError,SyntaxError,TypeError,URIError,console};function wd(e,t){function n(c,x){return x in c||x in Te}function s(c,x){return c[x]??(c.self&&c.self[x])}function a(c,x,y){return c[x]=y,!0}const d={has:n,get:s,set:a},l=new Proxy(e,d),u=`
    with (sandbox) {
       return ${t}
    }
  `;return new Function("sandbox",u)(l)}function Cd(e,t){function n(c,x){return!0}function s(c,x){return x in Te?Te[x]:x in c?c[x]:x==="scope"?e:c.self&&c.self[x]}function a(c,x,y){return c[x]=y,!0}const d={has:n,get:s,set:a},l=new Proxy(e,d),u=`
    with (sandbox) {
      ${t}
    }
  `;return new Function("sandbox",u)(l),e}function De(e,t){const n=Object.create(e);for(const s in t)n[s]=t[s];return n}function Oe(e,t="xml"){if(t==="html"){const a=document.createElement("body");return a.innerHTML=e,a}return new DOMParser().parseFromString(e,"text/xml").children[0]}function Ed(e){return e.endsWith("ies")?lt(e,"ies")+"y":lt(e,"s")}function Fd(e,t){const n=[];let s=!0;for(const a of e)s?s=!1:n.push(t),n.push(a);return n}function O(e,t,n){const s=e.getAttribute(n);if(s&&typeof s=="string")return s.split(",").map(a=>a.trim().toLowerCase())}function sn(e,t){const n=t.split(".");return n.length<=1?e.self:e[n[0]]}function on(e,t){const n=e.getAttribute("field")??"",s=sn(t,n),a=fe(t,n),d=e.getAttribute("type"),l=de(e.getAttribute("value")??"",t),u=e.getAttribute("js");if(u)return wd(t,u);if(n==="length")return!0;switch(d){case"equals":return l===String(a);case"not-equals":return l!==String(a);case"match":return!!new RegExp(l,e.getAttribute("flags")??"").test(a);case"not-match":return!new RegExp(l,e.getAttribute("flags")??"").test(a);case"has-rule":return!!(e.getAttribute("recursive")==="true"?s.getAllModifiedRules(!1):s.getModifiedRules()).length;case"includes":return!!l.includes(String(a));case"has-profile":{const g=e.getAttribute("recursive")==="true"?s.getAllModifiedProfiles():s.getModifiedProfiles();return!!ee(g,{include:l.length?l.split(",").map(x=>x.trim().toLowerCase()):void 0}).length}case"has-not-profile":{const g=e.getAttribute("recursive")==="true"?s.getAllModifiedProfiles():s.getModifiedProfiles();return!ee(g,{include:l.length?l.split(",").map(x=>x.trim().toLowerCase()):void 0}).length}case"not":return!a;case"greater":case">":return Number(a)>Number(l);case"atleast":case">=":return Number(a)>=Number(l);case"less":case"<":return Number(a)<Number(l);case"atmost":case"<=":return Number(a)<=Number(l);default:return!!a}}function kd(e,t,n){switch(e){case"greater":case">":return t>n;case"atleast":case">=":return t>=n;case"less":case"<":return t<n;case"atmost":case"<=":return t<=n;case"equals":case"=":return t===n;case"not-equals":case"!=":return t!=n;default:return!!t}}function Ye(e,t){let n=on(e,t);for(const s of e.children){const a=s.tagName.toLowerCase();if(a==="or"){if(n)continue;n=Ye(s,t)}if(a==="and"&&(n&&(n=Ye(s,t)),!n))return!1}return n}function Ct(e,t){for(let n=0;n<t.length-1;n++){const s=e[t[n]];if(!xe(s))return;e=s}return e}function fe(e,t){var n,s,a;try{const d=t.split("."),l=d.length>1?Ct(e.self,d)??Ct(e,d):e.self,u=d[d.length-1];switch(u){case"options":return he(l,{costs:!1,trim:!0,dedupeOptions:!0});case"secondaries":if(l.getAllSecondaries)return l.getAllSecondaries().join(", ");break;case"primary":if(l.getPrimaryCategory)return l.getPrimaryCategory();break;case"type":if(l.getType)return l.getType();break;case"primary-catalogue":case"primaryCatalogue":case"catalogue":if(l.getBook)return(n=l.getBook())==null?void 0:n.getName();break;case"name":if(l.getName)return l.getName();break;case"note":case"notes":if(l.getNote)return l.getNote();break;case"hidden":if(l.isHidden)return l.isHidden();break;case"size":if(l.calcTotalUnitSize)return l.calcTotalUnitSize();break;case"customName":if(l.getCustomName)return l.getCustomName();break;case"value":return l.value??l.$text;case"miniatureImageId":if(l.getName&&e.figurinesStore&&e.system){const g=e.system.id,c=e.figurinesStore.getMiniatureImageId(g,l);return c==null?void 0:c.fileId}break;case"miniatureUserId":if(l.getName&&e.figurinesStore&&e.system){const g=e.system.id,c=e.figurinesStore.getMiniatureImageId(g,l);if(c)return c.userId}if((a=(s=e.userStore)==null?void 0:s.user)!=null&&a._id)return e.userStore.user._id;break;case"miniatureImageUrl":if(l.getName&&e.figurinesStore&&e.system){const g=e.system.id,c=e.figurinesStore.getMiniatureImageId(g,l);if(c)return`/api/miniature-image/${c.userId}/${c.fileId}`}break}return l[u]??e[u]}catch(d){return console.warn("Export template error",d),String(d)}}function de(e,t){return e.match(/{{.*?}}/g)?e.replace(/{{ *(.*?) *}}/g,(n,s)=>fe(t,s)??""):e}function Et(e){const t=[];for(;e;e=e.parentNode)t.push(e);return t}function Ft(e,t){const n=[...Et(t.parentElement)];let s=e;for(;s&&s.element;)n.push(...Et(s.element)),s=s.parent;return n}function rn(e,t,n){var d,l,u,g;const s=sn(n,t);switch(t){case"units":if(s.iterateUnits){const c=s.getUnits().filter(f=>{var v,F;return((F=(v=f.getParentForce)==null?void 0:v.call(f))==null?void 0:F.isExportable())!==!1});let x=ue(c.filter(f=>f.isExportable()),{dedupe:e.getAttribute("dedupe")?{json:!0,associations:!0}:void 0});const y=O(e,n,"exclude-primary-categories");y!=null&&y.length&&(x=x.filter(f=>{var v;return!y.includes(((v=f.getPrimaryCategory())==null?void 0:v.toLowerCase())||"")}));const b=O(e,n,"include-primary-categories");return b!=null&&b.length&&(x=x.filter(f=>{var v;return b.includes(((v=f.getPrimaryCategory())==null?void 0:v.toLowerCase())||"")})),x}break;case"forces":return(d=s.getForces)==null?void 0:d.call(s).filter(c=>c.isExportable());case"categories":return(l=s.isForce)!=null&&l.call(s)?s.getCategories().filter(c=>c.isExportable()):(e.getAttribute("recursive")!=="false"?s.getAllSecondaryCategories():s.getSecondaryCategories()).filter(y=>y.isExportable());case"profiles":{if(s.getModifiedProfiles){const c=e.getAttribute("recursive")==="false",x=O(e,n,"exclude-entry-type"),y=O(e,n,"exclude-entries-with-profile"),b=e.getAttribute("include-rules")==="true",f=s,v=c?f.getModifiedProfiles():f.getAllModifiedProfiles(F=>{if(!F.isForce()&&(!F.isExportable()||!F.getParentForce().isExportable())||x!=null&&x.length&&x.includes(F.getType())||y!=null&&y.length&&F.getModifiedProfiles().find(S=>y.includes((se(S,"typeName")??"").toLowerCase())))return!0},b);return ee(v,{include:O(e,n,"include"),order:O(e,n,"order")??O(e,n,"include")??((g=(u=n.system.settings)==null?void 0:u.profilesOrder)==null?void 0:g.map(F=>F.toLowerCase())),exclude:O(e,n,"exclude"),grouped:e.getAttribute("grouped")==="true",sort:e.getAttribute("sort")==="true",amount:e.getAttribute("amount")?e.getAttribute("amount")==="true":void 0})}break}case"rules":{if(s.getModifiedRules){const c=e.getAttribute("recursive")==="false",x=O(e,n,"exclude-entry-type"),y=O(e,n,"exclude-entries-with-profile"),b=s;return c?b.getModifiedRules():b.getAllModifiedRules(e.getAttribute("skip-forces")==="true",f=>{if(!f.isForce()&&(!f.isExportable()||!f.getParentForce().isExportable())||x!=null&&x.length&&x.includes(f.getType())||y&&f.getModifiedProfiles().find(F=>y.includes((se(F,"typeName")??"").toLowerCase())))return!0})}break}case"characteristics":return ie(s.characteristics,{include:O(e,n,"include"),exclude:O(e,n,"exclude"),order:O(e,n,"order")??O(e,n,"include")});case"attributes":return ie(s.attributes,{include:O(e,n,"include"),exclude:O(e,n,"exclude"),order:O(e,n,"order")??O(e,n,"include")});case"models":if(s.getAllModels)return ue([...s.getAllModels("unit",!0)],{dedupe:e.getAttribute("dedupe")?!0:void 0});break;case"entries":{const c=[];return e.getAttribute("self")==="false"?s.forEachChild(x=>{x.isGroup()||c.push(x)}):s.forEach(x=>{x.isGroup()||c.push(x)}),e.getAttribute("associations")==="true"?ps(c):c}case"costs":if(s.calcTotalCosts)return s.calcTotalCosts(e.getAttribute("include-hidden")==="true",!0);break;case"secondaries":if(s.getSecondaryCategories)return s.getSecondaryCategories();break;case"stratagems":{const c=n.system,x=new ds(c),y=n.roster.getForces(!0).filter(f=>f.isExportable()).map(f=>f.getUnits()).flat(1).filter(f=>se(f.source,"name").toLowerCase().includes("detachment")).map(f=>f.calcOptionsList(!1,!1,!0)).filter(f=>f).map(f=>n.self.isRoster()?x.getDetachmentStratagems(f):x.getUnitStratagems(f,n.self)).flat(1),b={};for(const f of y)b[f.name]=f;return Object.values(b)}case"items":return Array.isArray(n.self)?[...n.self]:n.self.items;case"primary-catalogue":case"catalogue":if(s.getBook)return[s.getBook()];break}const a=s[t]??n[t];if(a)return a}function an(e){let t=e;if(e.includes(".")){const n=e.split(".");t=n[n.length-1]}return t}function Dd(e,t){var a,d;const n=e.nodeName,s=an(n);for(const l of e.getAttributeNames()){const u=e.getAttribute(l);u&&u.match(/{{.*?}}/g)&&e.setAttribute(l,u.replace(/{{(.*?)}}/g,(g,c)=>fe(t,c)))}switch(s){case"log":return console.log(t),null;case"and":case"or":return null;case"elseIf":case"elseif":case"else-if":if(e.getAttribute("branch")!=="true")return null;case"if":if(Ye(e,t))return Z(e,t);(d=(a=e.nextElementSibling)==null?void 0:a.tagName)!=null&&d.toLowerCase().startsWith("else")&&e.nextElementSibling.setAttribute("branch","true");case"else":return e.getAttribute("branch")!=="true"?null:Z(e,t);case"groups":return Z(e,t);case"options":return he(t.self,{constants:e.getAttribute("constants")==="true",models:e.getAttribute("models")==="true",units:e.getAttribute("units")==="true"});case"setting":{let l=function(x){if(x===void 0||x===null)return x;try{return JSON.parse(x)}catch{return x}};Z(e,Ae(t)),t.config.fields||(t.config.fields={});const u=e.getAttribute("id"),g=e.getAttribute("type"),c=e.getAttribute("label")??e.getAttribute("id");if(u&&g&&c&&!t.config.fields[u]){const x=l(e.getAttribute("default"));t.config.fields[u]={type:g,label:c,field:u,default:x},t.settings[u]===void 0&&(t.settings[u]={state:x});const y=u.split("."),b=y[y.length-1];let f=t.config;for(let v=0;v<y.length-1;v++){const F=y[v];f.fields||(f.fields={}),f.fields[F]||(f.fields[F]={}),f=f.fields[F]}f.fields||(f.fields={}),f.fields[b]={type:g,label:c,field:b,default:x},f[u]===void 0&&(f[u]={state:x})}return null}case"set":case"call":{Z(e,Ae(t));const l=e.getAttribute("name"),u=e.getAttribute("value"),g=e.getAttribute("fn"),c=e.getAttribute("index");if(l&&u){let x=fe(t,u)??u;if(g){const y=[];for(const b of e.attributes)if(b.name.startsWith("number")){const f=Number(b.name.replace("number",""))-1,v=de(b.value??"",t);y[f]=Number(v)}else if(b.name.startsWith("string")){const f=Number(b.name.replace("string",""))-1,v=de(b.value??"",t);y[f]=String(v)}else if(b.name.startsWith("regex")){const f=Number(b.name.replace("regex",""))-1,v=de(b.value??"",t);y[f]=new RegExp(v,e.getAttribute("flags")??"")}if(yd.has(g))switch(g){case"add":x=x+y[0];break;case"minus":case"subtract":x=x-y[0];break;case"multiply":x=x*y[0];break;case"divide":x=x/y[0];break;case"modulo":x=x%y[0];break}else vd.has(g)&&(x=x[g](...y))}c!==null&&(Array.isArray(x)?x=x[Number(c)]:x=void 0),s==="set"&&(t[l]=x,t.self&&(t.self[l]=x))}return null}case"set-attribute":{const l=e.getAttribute("in")??":not(if):not(and):not(or)",u=e.getAttribute("name"),g=e.getAttribute("value");if(u&&g&&l){const c=Ft(t,e).find(x=>x.matches(l));c&&(c==null||c.setAttribute(u,g))}return null}case"append-attribute":{const l=e.getAttribute("in")??":not(if):not(and):not(or)",u=e.getAttribute("name"),g=e.getAttribute("value"),c=e.getAttribute("join")??" ";if(u&&g&&l){const x=Ft(t,e).find(y=>y.matches(l));if(x){const y=x.getAttribute(u);x==null||x.setAttribute(u,y!=null&&y.length?`${y}${c}${g}`:g)}}return null}case"dedupe":{const l=Z(e,t),u=new Set,g=[];for(const c of l)u.has(c.innerHTML)||(u.add(c.innerHTML),g.push(c));return g}case"sort":case"sortby":case"sort-by":case"order":case"orderby":case"order-by":{const l=e.getAttribute("field")??"order",u=Z(e,t);return((e.getAttribute("direction")??"ascending")==="descending"?Qe:_)(u,x=>{var f,v;const y=((f=x.getAttribute)==null?void 0:f.call(x,l))??null;if(y!==null)return y;const b=(v=x.querySelector)==null?void 0:v.call(x,`[${l}]`);return b?(b==null?void 0:b.getAttribute(l))??"":""})}case"groupBy":case"group-by":case"groupby":return Ad(e,t);default:{if(e.getAttribute("if")&&!fe(t,e.getAttribute("if")))return null;const l=rn(e,s,t);return l?Ne(e,t,l):(Z(e,t),e)}}}function Ne(e,t,n,s=!1){var c,x;!Array.isArray(n)&&xe(n)&&(n=Object.entries(n).map(([y,b])=>({key:y,value:b})));const a=e.nodeName.toLowerCase(),d=Ed(a),l=t;function u(y,b,f){var v,F;for(const A of y.children){const S=A.nodeName.toLowerCase();if(S.endsWith("s"))continue;if(S!=="if"){u(A,b,f);continue}if(A.getAttribute("field")==="length"){const Y=de(A.getAttribute("value")??"",f);if(kd(A.getAttribute("type"),b.length,Y===null?void 0:Number(Y))){A.replaceWith(...y.childNodes);continue}else{(F=(v=A.nextElementSibling)==null?void 0:v.tagName)!=null&&F.toLowerCase().startsWith("else")&&A.nextElementSibling.setAttribute("branch","true"),A.remove();continue}}const W=b.filter(Y=>on(A,De(l,{[d]:Y,self:Y,parent:f,element:e.parentElement})));u(A,W,f)}}if(u(e,n,t),e.getAttribute("max")){const y=parseInt(e.getAttribute("max"));n.length>y&&(n=n.slice(0,y))}const g=n.map((y,b,f)=>{if(Array.isArray(y))return Z(e.cloneNode(!0),De(l,{...l,[d]:y,self:y,parent:t,element:e.parentElement}));const v=Ae(y);v.first=b===0,v.last=b===f.length-1,v.even=b%2===0,v.odd=b%2===1,v.length=f.length,v.index=b;const F=Z(e.cloneNode(!0),De(l,{[d]:v,self:v,parent:t,element:e.parentElement}));return s?{source:v,childs:F}:F}).flat(2);return g.some(y=>{var b;return y!==null&&((b=y.outerHTML)==null?void 0:b.trim())})||(x=(c=e.nextElementSibling)==null?void 0:c.tagName)!=null&&x.toLowerCase().startsWith("else")&&e.nextElementSibling.setAttribute("branch","true"),g}function Z(e,t){for(const n of[...e.childNodes]){if(n.nodeName==="#text"&&n.textContent&&(n.textContent=de(n.textContent,t)),n.nodeName==="script"){try{Cd(t,n.textContent||"")}catch(s){console.warn("Export template error",s)}n.remove();continue}if(n.tagName)try{const s=Dd(n,t);if(s!==n)if(s&&Array.isArray(s)&&s.length>0){const a=s;n.getAttribute("split")?n.replaceWith(...Fd(a,n.getAttribute("split"))):n.replaceWith(...a)}else s?n.replaceWith(s):n.remove()}catch(s){console.warn("Export template error",s),n.replaceWith(`${s}`)}}return[...e.childNodes]}function Ad(e,t){var g;const n={},s=[];for(const c of[...e.childNodes])if(c.tagName&&c.tagName!=="items"&&c.tagName!=="groups")try{const x=rn(c,an(c.nodeName.toLowerCase()),t);if(!x)continue;const y=Ne(c,t,x,!0).filter(b=>b.childs.find(f=>{var v;return(v=f.textContent)==null?void 0:v.trim()}));for(const b of y){const f=(((g=b.childs.find(v=>v.nodeName==="by"))==null?void 0:g.textContent)??"").trim();Ot(n,f,b.source),s.push(b.source)}}catch(x){console.warn("Export template error",x),c.replaceWith(`${x}`)}const a=[...e.childNodes].find(c=>c.nodeName==="groups");if(!a)return null;const d=(O(e,t,"order")??[]).reverse(),l=Qe(Object.entries(n),([c,x])=>(d==null?void 0:d.indexOf(c.toLowerCase()))??-1).map(([c,x])=>({key:c,items:x}));return Ne(a,De(t,{groups:l,ungrouped:s}),l)}function ln(e){for(const t of e.childNodes)t.childNodes.length===0&&t.nodeType===Node.ELEMENT_NODE&&t.appendChild(e.ownerDocument.createTextNode("")),ln(t)}function Pd(e){const t=document.createElement("textarea");return t.innerHTML=e,t.value}function dn(e){for(const n of[...e.children])dn(n);if(e.tagName==="SCRIPT"){e.innerHTML=Pd(e.innerHTML);return}const t=e.getAttribute("type");if(t==="card")e.prepend(Oe(`
        <div class="card-controls print-display-none" style="display: flex; align-items: center; justify-content: flex-end; gap: 15px;">
            <label class="button" style="cursor: pointer" onclick="
            const parent = this.parentElement.parentElement
            const previous = parent.previousElementSibling
            if (previous?.getAttribute('type') === 'card') previous.before(parent)
        ">
                <span>Move up 
                <svg viewBox="0 0 24 24" width="16" height="16" fill="#111113" style="display: inline-block;" xmlns="http://www.w3.org/2000/svg"><path d="M12 4V20M12 4L8 8M12 4L16 8" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                </span>
            </label>
            <label class="button" style="cursor: pointer" onclick="
            const parent = this.parentElement.parentElement
            const next = parent.nextElementSibling
            if (next?.getAttribute('type') === 'card') next.after(parent)
        ">
                <span>Move down 
                <svg viewBox="0 0 24 24" width="16" height="16" fill="#111113"  style="display: inline-block;" xmlns="http://www.w3.org/2000/svg"><path d="M12 4V20M12 20L8 16M12 20L16 16" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                </span>
            </label>
            <label class="button" style="cursor: pointer"">
                <input type="checkbox" style="cursor: pointer;" onclick="
            this.parentElement.parentElement.parentElement?.classList.toggle('print-display-none', this.checked);
        ">
                <span>Don't print this card.</span>
            </label>
        </div>`,"html"));else if(t==="markdown"){const n=new ft.Converter({sanitize:!0,strikethrough:!0,tables:!0,extensions:[{type:"lang",regex:/\^\^(.*?)\^\^/g,replace:'<span style="font-variant: small-caps;">$1</span>'},{type:"output",regex:/<\/?p[^>]*>/g,replace:""}]});e.innerHTML=n.makeHtml((e.innerHTML||"").replace(/\u00a0/g," "))}else if(t==="stripmarkdown"){const n=new ft.Converter({sanitize:!0,strikethrough:!0,tables:!0,extensions:[{type:"lang",regex:/\^\^(.*?)\^\^/g,replace:'<span style="font-variant: small-caps;">$1</span>'},{type:"output",regex:/<\/?p[^>]*>/g,replace:""}]}),s=document.createElement("span");s.innerHTML=n.makeHtml((e.innerHTML||"").replace(/\u00a0/g," ")),e.innerHTML=s.innerText,s.remove()}else t==="html"&&(e.innerHTML=e.textContent||"");return[...e.children]}function Sd(e){const t=[],n=[];let s="{}";e=e.replace(/<style[\s\S]*?>[\s\S]*?<\/style>/gi,l=>(t.push(l),"")),e=e.replace(/<config[\s\S]*?>([\s\S]*?)<\/config>/i,(l,u)=>(s=u,""));const a=[];e=e.replace(/<template[\s\S]*?>([\s\S]*?)<\/template>/gi,l=>{const u=`<!--TEMPLATE_PLACEHOLDER_${a.length}-->`;return a.push(l),u}),e=e.replace(/<script[\s\S]*?>([\s\S]*?)<\/script>/gi,l=>(n.push(l),"")),a.forEach((l,u)=>{e=e.replace(`<!--TEMPLATE_PLACEHOLDER_${u}-->`,l)});let d={};try{const l=JSON.parse(s);xe(l)&&(d=l)}catch{}return{xml:e.trim(),styles:t,config:d,scripts:n}}function Gd(e,t){var x,y;t.self||(t.self=Object.values(t)[0]);const{xml:n,styles:s,config:a,scripts:d}=Sd(e);Object.keys(t.config).length===0&&Object.assign(t.config,a),(y=(x=t.settings)==null?void 0:x.oneCardPerPage)!=null&&y.state&&s.push(`<style>
@media print {
  *[type="card"] {
    page-break-after: always;
  }
}
</style>`),s.unshift(`<style>
html {
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  -webkit-text-size-adjust: 100%;
}
* {
  box-sizing: border-box;
  print-color-adjust: exact;
  -webkit-print-color-adjust: exact
}
*[type="card"] {
    position: relative;
    page-break-inside: avoid;
    -moz-column-break-inside: avoid;
    break-inside: avoid;
}
*[type="markdown"] {
  white-space: pre-wrap; 
  white-space-collapse: preserve-breaks;
  text-wrap: wrap;
}
*[type="markdown"] * li {
    margin-top: -1.5em;
}    
*[type="markdown"] > p:first-child {
    display: inline;
}
*[type="markdown"] > p:first-childp::after {
    content: "";
    display: inline-block;
}
.button:hover {
  filter: brightness(var(--hover-darken-pct, 85%));
  background-color:  var(--hover-darken-color, rgba(0, 0, 0, 0.15)); 
  border-radius: 4px !important;
}
.crossed {
  text-decoration: line-through;
}
.removable {
  cursor: pointer;
}
@media print { 
    .print-display-none, .print-display-none * {
        display: none !important
    }
    body { 
        margin: 0px !important;  
    } 
}
@media screen and (max-width: 600px) {
    html {
        zoom: 0.8;
    }
}
@media screen and (max-width: 500px) {
    html {
        zoom: 0.7;
    }
}
@media screen and (max-width: 400px) {
    html {
        zoom: 0.6;
    }
}
@media screen and (max-width: 300px) {
    html {
        zoom: 0.5;
    }
}
@page {
  margin: 10px;
}

</style>`);const l=Oe(n);Z(l,t);const u=new XMLSerializer;ln(l);const g=[...l.childNodes].map(b=>u.serializeToString(b)).join(`
`),c=Oe(g,"html");return dn(c),c.setAttribute("onmouseover","this.ownerDocument.lastHoveredElement = event.target.closest('.removable');"),c.setAttribute("onmouseleave","this.ownerDocument.lastHoveredElement = undefined;"),c.setAttribute("onclick",`
this.ownerDocument.lastHoveredElement?.classList.toggle('crossed');
this.ownerDocument.lastHoveredElement?.classList.toggle('print-display-none', this.ownerDocument.lastHoveredElement?.classList.contains('crossed'));
`),{html:[c.outerHTML,...s,...d].join(`
`),config:a}}const Bd=`<template>
  <setting id="titleBackgroundGraphics" label="Title Background Graphics" type="checkbox" default="true" />
  <setting id="cardBackgroundGraphics" label="Card Background Graphics" type="checkbox" default="true" />
  <setting id="customWarscrollNames" label="Original warscroll names (when using Custom Names)" type="checkbox" default="false" />
  <units dedupe="true">
    <entries>
      <if field="type" type="equals" value="unit">
        <or field="name" type="match" value="^(.+ Lore|Battle Traits.+?|Battle Tactic Cards|Arcane Tome|Campaign Progress|Honour Guard|Battle Formation|Emberstone Vault|Regiment of Renown.+?)*$" />
        <div class="avoid-page-break" type="card" catalogue="{{catalogue}}">
          <div class="card">
            <if field="settings.cardBackgroundGraphics.state" type="equals" value="true">
              <append-attribute name="class" value="bg" />
            </if>
            <div class="card-header">
              <if field="name" type="match" value="^(.+ Lore|Battle Traits.+?|Battle Tactic Cards|Arcane Tome|Campaign Progress|Honour Guard|Battle Formation|Emberstone Vault|Regiment of Renown.+?)*$">
                <span class="section-header">{{name}}</span>
              </if>
              <if field="type" type="equals" value="unit">
                <entries>
                  <if type="has-profile" value="model,unit,stats,manifestation">
                    <secondaries>
                      <if field="name" type="match" value="^WARD \\((\\d\\+)\\)$">
                        <set name="wardValue" value="{{name}}" fn="match" regex1=".?(\\d\\+)." index="1" />
                        <div class="ward">
                          <span>{{wardValue}}</span>
                        </div>
                      </if>
                    </secondaries>
                    <profiles include="model,unit,stats,manifestation" recursive="false">
                      <div class="statWheel">
                        <div class="statWheelStats">
                          <characteristics>
                            <div class="statwheelEntry">
                              <div class="statLabel">
                                <svg>
                                  <text>
                                    <if field="last" type="match" value="true">
                                      <textPath href="#circlePathReversed" startOffset="50%">{{name}}</textPath>
                                    </if>
                                    <else>
                                      <textPath href="#circlePath" startOffset="50%">{{name}}</textPath>
                                    </else>
                                  </text>
                                </svg>
                              </div>
                              <div class="stat">{{$text}}</div>
                            </div>
                          </characteristics>
                        </div>
                      </div>
                    </profiles>
                    <div class="titleWrap">
                      <div class="titleCard">
                        <div class="title">
                          <if field="customName">{{customName}}
                            <if field="settings.customWarscrollNames.state" type="equals" value="true">
                              <div class="subtitle">{{name}}</div>
                            </if>
                          </if>
                          <else>{{name}}</else>
                        </div>
                      </div>
                    </div>
                  </if>
                </entries>
              </if>
            </div>
            <!-- Rules -->
            <if type="has-rule" recursive="true">
              <div class="rules">
                <forces>
                  <if type="has-rule">
                    <div class="force">
                      <span class="force-name">{{name}}</span>
                      <span class="force-catalogue">({{catalogue}})</span>
                      <rules recursive="false">
                        <div class="rule nested">
                          <span class="rule-name">{{name}}</span>
                          <span class="rule-desc" type="markdown">{{description}}</span>
                        </div>
                      </rules>
                    </div>
                  </if>
                </forces>
                <rules skip-forces="true">
                  <div class="rule">
                    <span class="rule-name">{{name}}</span>
                    <span class="rule-desc" type="markdown">{{description}}</span>
                  </div>
                </rules>
                <profiles include="special rule,rule,rules">
                  <div class="rule">
                    <span class="rule-name">{{name}}</span>
                    <characteristics>
                      <span class="rule-desc" type="markdown">{{value}}</span>
                    </characteristics>
                  </div>
                </profiles>
              </div>
            </if>
            <!--body-->
            <if field="type" type="equals" value="unit">
              <table cellspacing="0" class="weapons-table">
                <thead>
                  <profiles include="ranged weapon" max="1">
                    <tr>
                      <td><span>Ranged Weapons</span></td>
                      <characteristics>
                        <td><span>{{name}}</span></td>
                      </characteristics>
                    </tr>
                  </profiles>
                </thead>
                <tbody>
                  <profiles include="ranged weapon">
                    <tr>
                      <td><span>{{name}}</span></td>
                      <characteristics include="rng,atk,hit,wnd,rnd,dmg,ability">
                        <td>
                          <span type="markdown">{{$text}}</span>
                        </td>
                      </characteristics>
                    </tr>
                  </profiles>
                </tbody>
                <thead>
                  <profiles include="melee weapon" max="1">
                    <tr>
                      <td><span>Melee Weapons</span></td>
                      <td class="placeholder" />
                      <characteristics>
                        <td><span>{{name}}</span></td>
                      </characteristics>
                    </tr>
                  </profiles>
                </thead>
                <tbody>
                  <profiles include="melee weapon">
                    <tr>
                      <td><span>{{name}}</span></td>
                      <td class="placeholder" />
                      <characteristics include="atk,hit,wnd,rnd,dmg,ability">
                        <td>
                          <span type="markdown">{{$text}}</span>
                        </td>
                      </characteristics>
                    </tr>
                  </profiles>
                </tbody>
              </table>
            </if>
            <div class="hide-if-empty ability-section">
              <if field="name" type="match" value="^(.+ Lore|Arcane Tome)*$">
                <set name="profileIncludes" value="ability (spell), ability (prayer)" />
              </if>
              <else>
                <set name="profileIncludes" value="ability (passive),ability (activated),ability (command),ability (spell), ability (prayer), battle tactic card" />
              </else>
              <profiles include="{{profileIncludes}}" split="">
                <div class="ability-box">
                  <characteristics include="casting value">
                    <div class="cast icon">
                      <img src="https://raw.githubusercontent.com/BSData/age-of-sigmar-4th/main/images/casting.png" alt="" />
                      <div>{{$text}}</div>
                    </div>
                  </characteristics>
                  <characteristics include="chanting value">
                    <div class="chant icon">
                      <img src="https://raw.githubusercontent.com/BSData/age-of-sigmar-4th/main/images/chanting.png" alt="" />
                      <div>{{$text}}</div>
                    </div>
                  </characteristics>
                  <characteristics include="cost">
                    <div class="command icon">
                      <img src="https://raw.githubusercontent.com/BSData/age-of-sigmar-4th/main/images/command.png" alt="" />
                      <div>{{$text}}</div>
                    </div>
                  </characteristics>
                  <div class="header">
                    <if field="settings.titleBackgroundGraphics.state" type="equals" value="true">
                      <append-attribute name="class" value="bg" />
                    </if>
                    <attributes include="type">
                      <svg class="header-icon" viewBox="0 0 15 15">
                        <use href="#icon{{$text}}" />
                      </svg>
                    </attributes>
                    <attributes include="color">
                      <set-attribute name="color" value="{{$text}}" in=".ability-box" />
                    </attributes>
                    <if type="equals" field="typeName" value="Ability (Passive)">
                      <set-attribute name="timing" value="Passive" in=".ability-box" />
                      <span>Passive</span>
                    </if>
                    <if type="equals" field="typeName" value="Battle Tactic Card">
                      <set-attribute name="timing" value="Battle Tactic Card" in=".ability-box" />
                      <span>Battle Tactic Card</span>
                    </if>
                    <else>
                      <characteristics include="timing">
                        <set-attribute name="timing" value="{{$text}}" in=".ability-box" />
                        <span type="markdown">{{$text}}</span>
                      </characteristics>
                    </else>
                  </div>
                  <div class="ability-wrapper">
                    <div class="ability-description">
                      <div style="text-transform: uppercase">
                        <strong>{{name}}</strong>
                      </div>
                      <characteristics include="declare,used by,effect, card, affray, strike, domination">
                        <if field="$text">
                          <div>
                            <span><strong>{{name}}</strong>: </span><span type="markdown">{{$text}}</span>
                          </div>
                        </if>
                      </characteristics>
                    </div>
                    <characteristics include="keywords">
                      <if field="$text">
                        <div class="ability-keywords">
                          <span class="header"> Keywords </span>
                          <span>
                            <span type="markdown" style="padding-left: 10px">{{$text}}</span>
                          </span>
                        </div>
                      </if>
                    </characteristics>
                  </div>
                </div>
              </profiles>
            </div>
            <div class="keyword-box">
              <div class="header">Keywords</div>
              <div class="keywords">
                <secondaries>
                  <span class="">
                    <if field="name" type="match" value="^(Army Composition|Configuration|Reference)*$">
                      <append-attribute name="class" value="hide-keywords" />
                    </if>
                  </span>
                  <if field="name" type="match" value="^(?!.*[a-z]).+$">
                    <span type="markdown" class="split">{{name}}
                      <if field="last" type="not">, </if>
                    </span>
                  </if>
                </secondaries>
              </div>
            </div>
          </div>
        </div>
      </if>
    </entries>
  </units>
  <svg style="width: 0; height: 0" viewBox="0 0 150 150">
    <path id="circlePath" d="M29,75c0-25.4,20.6-46,46-46s46,20.6,46,46-20.6,46-46,46-46-20.6-46-46" />
    <path id="circlePathReversed" d="M22.6,75c0,28.9,23.5,52.4,52.4,52.4s52.4-23.5,52.4-52.4-23.5-52.4-52.4-52.4-52.4,23.5-52.4,52.4" />
  </svg>
  <svg style="width: 0; height: 0" viewBox="0 0 15 15">
    <defs>
      <path id="iconMovement" d="M5.6,3.6L.9,5.2l5.6.7L1.9,11l2.8,2.6,4.6-4.9,1.2,5.5L14.1.8,5.6,3.6Z" />
      <path id="iconOffensive" d="M13.5,12.7l.3-.3v-.3l-.2-.2h-.3l-1.5-1.5h-.3v-.4l-2.1-2.1,4.4-4.5.9-2.2-2.2.9-4.4,4.4h0l-2.1-2.1,1.3-1.3h.3v-.3l-1.8-1.8-.9-.9h-.3v.3h0L.8,4.3h-.3v.3l2.6,2.6h.3v-.3h0l1.3-1.3.9.9,1.2,1.2h0l-1.2,1.2-.8.8v.8h-.2c-.3,0-.5-.3-.4-.6,0-.1,0-.2-.2-.2h-1.1l1.3,1.4-1.9,1.9v.3h-.4l-.2.3c-.1,0-.3,0-.3.3s-.1.4.1.6.2.2.3.2h.3c.3,0,.2-.2.3-.3l.3-.2v-.4h.3l1.9-2,1.3,1.4v-1.3h-.4s-.3-.2-.3-.4v-.3h.8l2-2,2,2h.4v.4l1.5,1.5h0v.3l.2.2h.3l.3-.3c-.2.2,0,.6,0,.8.1.1.5.2.7.2s.8-.7.8-.7c.2-.2,0-.6,0-.8-.1-.1-.5-.3-.8-.2h-.2Z" />
      <path id="iconDefensive" d="M12.3,4.7c0-1.8.2-2.4.5-3.2v-.6H1.8v.6c.5.8.7,1.9.7,3.5s-.7,3.1-.7,3.1v.7c1.5,4,5.7,5.4,5.7,5.4.3-.1,4.5-1.8,5.4-5.4v-.7s-.6-1.5-.7-3.3h.1ZM9.3,9.2c.1,1.1-.4,2.1-1.6,2.3h-.2c-.8,0-1.5-.5-1.8-1.1s-.2-.5-.2-.7c0-.8.2-1.1.2-1.2l-1-2.6,1.1.2-.6-1.7h.8l-.4-1.1-.4-1.1.4.5,1.7,2.4h-.8s.6,1.4.7,1.7h-.8l.3.9h1.4l.3-.9h-.8c0-.3.7-1.7.7-1.7h-.8l2-2.9-.7,2.2h.8l-.6,1.7,1.1-.2-.9,2.6c.1.2.2.7.2.7h-.1Z" />
      <path id="iconShooting" d="M13.4,10.4c.7-1.2.7-1.6.6-2.9s-1.5-2.4-1.5-2.4c-.4.5-.8.6-1,.6s-.5-.2-1.1-.6l1.2-1.3.3.6,1.8-3.7-3.5,2.1.6.2-1.2,1.3c-.7-.6-1-1.2-.2-1.9,0,0-.9-1.3-2.4-1.3s-2.2.3-2.9.8c-.4.3-.9.4-1.5.4s-1.3-.3-1.5-.9c0-.3-.2-.4-.3-.4-.3,0-.7,1.1,0,1.9.5.5,1.3.8,2,.8s.8,0,1.1-.3c1.7-.9,2.5-.8,2.8-.7.7.2.4.8.3,1-.3.9.3,1.7,1,2.3l-3.8,4.1h-1c0-.1-2.3,2.3-2.3,2.3l2-.2v2l2-2.4v-1.1l3.8-4.1c1.6,1.3,2.2,1,2.4.9.7-.2.9,0,1,.3.2.7.1,1.4-.5,2.9-.4,1-.1,2.4.8,3.1,1.6.8,2.3-.2,1.4-.4h0s-1.7-.4-.4-3Z" />
      <path id="iconRallying" d="M11.9,4.6l1.1-4.1s-3.5,1-4.9.7-2.2,1.2-3.9.9c-.7,0-2,.3-2,.3v-.3c0-.2.3-.4.2-.7s-.4-.7-1.1-.6-.9.5-.8.9c0,.4.3.5.7.5l2.1,12.3h.9c0-.1-.7-4.1-.7-4.1,1-.3,1.5-.6,1.8-.6,1.8,1.1,2.9-1.7,6-.7s3.6-1.4,3.6-1.4h0s-3-3.1-3-3.1ZM3.3,8.8l-.8-4.8,1.4-.3.8,4.8s-1.4.3-1.4.3Z" />
      <path id="iconSpecial" d="M15,7.6l-3.3-.5c0-.5-.2-.9-.4-1.3l1.4-1.2-1.7.6c-.3-.5-.7-.8-1.1-1.1l.7-1.7-1.2,1.4c-.4-.2-.9-.3-1.3-.4L7.6.1l-.5,3.3c-.5,0-.9.2-1.3.4h0l-1.2-1.4.6,1.7c-.5.3-.8.7-1.1,1.1l-1.7-.6,1.4,1.2c-.2.4-.3.9-.4,1.3l-3.4.4,3.3.5c0,.5.2.9.4,1.3l-1.4,1.2,1.7-.6c.3.4.7.8,1.1,1.1l-.6,1.7,1.2-1.4h0c.4.2.8.3,1.3.4l.5,3.3.5-3.3c.5,0,.9-.2,1.3-.4l1.2,1.4-.7-1.7c.5-.3.8-.7,1.1-1.1l1.7.6-1.4-1.2c.2-.4.3-.8.4-1.2,0,0,3.4-.5,3.4-.5ZM7.5,10c-.7,0-1.4-.3-1.9-.9-.4-.4-.6-1-.6-1.6s.2-1.2.6-1.6c.5-.5,1.1-.9,1.9-.9,1.4,0,2.5,1.1,2.5,2.5s-1.1,2.5-2.5,2.5Z" />
      <path id="iconControl" d="M7.5,1.3C-.5,1.1-.5,13.9,7.5,13.7c8,0,8-12.5,0-12.4h0Z" />
      <path id="iconDamage" d="M6,14.3c-.9-.5-.8-1.4-.9-2.3,0-.6-.5-.8-1-.8s-.5,0-.7-.2v-.2c-.3-.5-.8-1-.6-1.7,0-.5.2-1,0-1.5-.5-1.3-.2-2.7.1-4.1C4.8-1.7,14,.9,12.6,6.5c0,.8-.7,1.6-.2,2.5,0,.2,0,2-.9,2.3-.3,0-1.5-.2-1.6.5s0,1.8-.5,2.2c-1.1.8-3.4.3-3.4.3ZM10,9.3c1.1,0,1-.4,1.1-.7s.2-1.2-.5-1.3c-.7,0-1.2,0-1.8.2-.3,0-.4.4-.3.7s.4,1.1,1.5,1.1ZM3.8,8.2c0,.5.2,1,.5,1.1s1.5.2,1.9-.4c.2-.2.4-.7.2-.9-.2-.2-.9-.5-1.9-.6s-.7.3-.7.8ZM7.5,10.6h0c0,.2.1.4.1.4s.8,0,.7-.5c-.2-.5-.5-1.2-.6-1.3s-.3,0-.6,0c0,.2-.5.8-.5,1.4s.6.5.7.4.1-.2.1-.4h0Z" />
    </defs>
  </svg>
</template>
<style>
  @import url("https://cdn.jsdelivr.net/npm/@fontsource-variable/newsreader@5.1.1/index.min.css");

  /* @import url("https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,200..800;1,6..72,200..800&display=swap"); */
  :root {
    --jagged-edges: polygon(0.2% 2.7%, 0.7% 0.1%, 1.8% 5%, 3.2% 3%, 3.9% 1.1%, 4.9% 4.1%, 6.2% 0%, 10% 1.4%, 12.4% 0.5%, 13.5% 3%, 14.1% 0.4%, 15.2% 1.9%, 15.7% 3.6%, 16.1% 4.9%, 18.2% 0.7%, 18.7% 4.6%, 19.5% 0.4%, 20.2% 2.7%, 20.7% 0.1%, 21.8% 5%, 23.2% 3%, 23.9% 1.1%, 24.9% 4.1%, 26.2% 0%, 30% 1.4%, 32.4% 0.5%, 33.5% 3%, 34.1% 0.4%, 35.2% 1.9%, 35.7% 3.6%, 36.1% 4.9%, 38.2% 0.7%, 38.7% 4.6%, 39.5% 0.4%, 40.2% 2.7%, 40.7% 0.1%, 41.8% 5%, 43.2% 3%, 43.9% 1.1%, 44.9% 4.1%, 46.2% 0%, 50% 1.4%, 52.4% 0.5%, 53.5% 3%, 54.1% 0.4%, 55.2% 1.9%, 55.7% 3.6%, 56.1% 4.9%, 58.2% 0.7%, 58.7% 4.6%, 59.5% 0.4%, 60.2% 2.7%, 60.7% 0.1%, 61.8% 5%, 63.2% 3%, 63.9% 1.1%, 64.9% 4.1%, 66.2% 0%, 70% 1.4%, 72.4% 0.5%, 73.5% 3%, 74.1% 0.4%, 75.2% 1.9%, 75.7% 3.6%, 76.1% 4.9%, 78.2% 0.7%, 78.7% 4.6%, 79.5% 0.4%, 80.2% 2.7%, 80.7% 0.1%, 81.8% 5%, 83.2% 3%, 83.9% 1.1%, 84.9% 4.1%, 86.2% 0%, 90% 1.4%, 92.4% 0.5%, 93.5% 3%, 94.1% 0.4%, 95.2% 1.9%, 95.7% 3.6%, 96.1% 4.9%, 98.2% 0.7%, 98.7% 4.6%, 99.5% 0.4%, 100% 10%, 100% 90%, 99.5% 99.6%, 98.7% 95.4%, 98.2% 99.3%, 96.1% 95.1%, 95.7% 96.4%, 95.2% 98.1%, 94.1% 99.6%, 93.5% 97%, 92.4% 99.5%, 90% 98.7%, 86.2% 100%, 84.9% 96%, 83.9% 98.9%, 83.2% 97%, 81.8% 95%, 80.7% 99.9%, 80.2% 97.3%, 79.5% 99.6%, 78.7% 95.4%, 78.2% 99.3%, 76.1% 95.1%, 75.7% 96.4%, 75.2% 98.1%, 74.1% 99.6%, 73.5% 97%, 72.4% 99.5%, 70% 98.7%, 66.2% 100%, 64.9% 96%, 63.9% 98.9%, 63.2% 97%, 61.8% 95%, 60.7% 99.9%, 60.2% 97.3%, 59.5% 99.6%, 58.7% 95.4%, 58.2% 99.3%, 56.1% 95.1%, 55.7% 96.4%, 55.2% 98.1%, 54.1% 99.6%, 53.5% 97%, 52.4% 99.5%, 50% 98.7%, 46.2% 100%, 44.9% 96%, 43.9% 98.9%, 43.2% 97%, 41.8% 95%, 40.7% 99.9%, 40.2% 97.3%, 39.5% 99.6%, 38.7% 95.4%, 38.2% 99.3%, 36.1% 95.1%, 35.7% 96.4%, 35.2% 98.1%, 34.1% 99.6%, 33.5% 97%, 32.4% 99.5%, 30% 98.7%, 26.2% 100%, 24.9% 96%, 23.9% 98.9%, 23.2% 97%, 21.8% 95%, 20.7% 99.9%, 20.2% 97.3%, 19.5% 99.6%, 18.7% 95.4%, 18.2% 99.3%, 16.1% 95.1%, 15.7% 96.4%, 15.2% 98.1%, 14.1% 99.6%, 13.5% 97%, 12.4% 99.5%, 10% 98.7%, 6.2% 100%, 4.9% 96%, 3.9% 98.9%, 3.2% 97%, 1.8% 95%, 0.7% 99.9%, 0.2% 97.3%, 0% 100%, 0% 0%);
    --jagged-edges-header: polygon(100% 45.727%, 100% 45.727%, 99.948% 44.428%, 99.919% 43.078%, 99.909% 41.688%, 99.912% 40.269%, 99.923% 38.833%, 99.937% 37.391%, 99.948% 35.956%, 99.952% 34.54%, 99.943% 33.152%, 99.915% 31.806%, 99.915% 31.806%, 99.963% 30.566%, 99.983% 29.33%, 99.982% 28.096%, 99.967% 26.862%, 99.945% 25.628%, 99.923% 24.39%, 99.907% 23.149%, 99.904% 21.902%, 99.921% 20.647%, 99.965% 19.383%, 99.965% 19.383%, 100.001% 18.199%, 99.987% 17.166%, 99.94% 16.253%, 99.874% 15.43%, 99.806% 14.67%, 99.75% 13.94%, 99.722% 13.213%, 99.739% 12.459%, 99.814% 11.647%, 99.965% 10.749%, 99.965% 10.749%, 99.926% 9.711%, 99.889% 8.659%, 99.854% 7.597%, 99.821% 6.527%, 99.789% 5.452%, 99.758% 4.374%, 99.728% 3.296%, 99.698% 2.22%, 99.669% 1.15%, 99.639% 0.088%, 0.304% 0.088%, 0.304% 0.088%, 0.358% 2.035%, 0.386% 3.92%, 0.393% 5.752%, 0.383% 7.544%, 0.36% 9.306%, 0.328% 11.05%, 0.292% 12.786%, 0.255% 14.526%, 0.223% 16.281%, 0.198% 18.062%, 0.198% 18.062%, 0.393% 18.664%, 0.496% 19.398%, 0.525% 20.245%, 0.498% 21.183%, 0.431% 22.192%, 0.341% 23.251%, 0.247% 24.339%, 0.165% 25.437%, 0.112% 26.523%, 0.106% 27.577%, 0.106% 27.577%, 0.125% 28.281%, 0.14% 29.287%, 0.152% 30.521%, 0.16% 31.91%, 0.165% 33.381%, 0.168% 34.86%, 0.168% 36.273%, 0.165% 37.546%, 0.161% 38.608%, 0.156% 39.383%, 0.156% 39.383%, 0.075% 40.475%, 0.03% 41.583%, 0.011% 42.708%, 0.013% 43.851%, 0.028% 45.011%, 0.049% 46.19%, 0.069% 47.388%, 0.08% 48.605%, 0.076% 49.843%, 0.05% 51.101%, 0.05% 51.101%, 0.121% 51.006%, 0.201% 51.118%, 0.281% 51.404%, 0.357% 51.829%, 0.421% 52.357%, 0.467% 52.954%, 0.489% 53.584%, 0.481% 54.214%, 0.435% 54.808%, 0.347% 55.33%, 0.347% 55.33%, 0.246% 55.81%, 0.164% 56.668%, 0.1% 57.831%, 0.052% 59.224%, 0.021% 60.771%, 0.005% 62.397%, 0.004% 64.028%, 0.016% 65.587%, 0.041% 67.001%, 0.078% 68.194%, 0.078% 68.194%, 0.097% 69.082%, 0.103% 70.084%, 0.1% 71.166%, 0.093% 72.295%, 0.085% 73.436%, 0.081% 74.556%, 0.087% 75.622%, 0.105% 76.598%, 0.14% 77.452%, 0.198% 78.15%, 0.198% 78.15%, 0.256% 78.387%, 0.301% 78.671%, 0.334% 78.996%, 0.356% 79.356%, 0.369% 79.747%, 0.374% 80.161%, 0.374% 80.593%, 0.369% 81.037%, 0.362% 81.487%, 0.354% 81.938%, 0.354% 81.938%, 0.328% 82.988%, 0.354% 83.845%, 0.415% 84.559%, 0.493% 85.181%, 0.572% 85.76%, 0.635% 86.347%, 0.664% 86.993%, 0.643% 87.746%, 0.555% 88.659%, 0.382% 89.78%, 0.382% 89.78%, 0.392% 90.216%, 0.397% 90.628%, 0.396% 91.016%, 0.389% 91.383%, 0.376% 91.729%, 0.356% 92.057%, 0.329% 92.368%, 0.295% 92.664%, 0.254% 92.946%, 0.205% 93.216%, 0.205% 93.216%, 0.168% 93.725%, 0.149% 94.336%, 0.145% 95.025%, 0.15% 95.769%, 0.158% 96.542%, 0.166% 97.32%, 0.167% 98.079%, 0.158% 98.795%, 0.132% 99.444%, 0.085% 100%, 99.908% 100%, 99.908% 100%, 99.968% 96.779%, 99.995% 93.517%, 99.996% 90.22%, 99.977% 86.894%, 99.945% 83.546%, 99.907% 80.183%, 99.869% 76.809%, 99.838% 73.433%, 99.821% 70.06%, 99.823% 66.696%, 99.823% 66.696%, 99.87% 66.006%, 99.896% 65.312%, 99.904% 64.613%, 99.897% 63.91%, 99.88% 63.205%, 99.856% 62.497%, 99.829% 61.786%, 99.802% 61.074%, 99.78% 60.361%, 99.767% 59.648%, 99.767% 59.648%, 99.754% 58.91%, 99.76% 58.22%, 99.779% 57.562%, 99.807% 56.92%, 99.84% 56.278%, 99.873% 55.619%, 99.9% 54.93%, 99.918% 54.192%, 99.923% 53.391%, 99.908% 52.511%, 99.908% 52.511%, 99.71% 52.01%, 99.565% 51.333%, 99.47% 50.532%, 99.423% 49.659%, 99.421% 48.767%, 99.461% 47.906%, 99.542% 47.128%, 99.66% 46.486%, 99.814% 46.031%, 100% 45.815%);
  }

  body {
    margin: 0;
  }

  html {
    font-family: "Newsreader Variable", sans-serif, Inter, system-ui, Avenir, Helvetica, Arial, sans-serif;
    font-weight: 400;
    font-size: 14px;
    color-scheme: light dark;
    color: #111113;
    background-color: #fff;
    text-rendering: optimizeLegibility;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-text-size-adjust: 100%;

    column-count: 1;
    column-gap: 0;

    @media screen and (min-width: 1400px) {
      column-count: 2;
    }

    @media screen and (min-width: 1950px) {
      column-count: 3;
    }

    @media screen and (min-width: 2600px) {
      column-count: 4;
    }
  }

  .avoid-page-break {
    margin-bottom: 32px;
    padding: 2%;
  }

  .avoid-page-break:not(:has(:is(.ability-box, .weapons-table))) {
    display: none;
  }

  .section-header {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1em 0 0.2em;
    font-weight: bold;
    font-variant: small-caps;
    font-size: 2em;
  }

  .card-header:not(:has(*)),
  .hide-if-empty:not(:has(*)) {
    display: none;
  }

  .card-header {
    position: relative;
  }

  .titleWrap {
    padding: 20px 30px 30px 80px;
    height: 100%;
  }

  .titleCard {
    height: 100%;
    display: flex;
    background: url(https://raw.githubusercontent.com/giloushaker/nr-templates/refs/heads/main/assets/backgrounds/aos-title.png),
      var(--primary-color, black);
    background-blend-mode: color-burn;
    background-size: cover;
    clip-path: var(--jagged-edges);
  }

  .title {
    margin: auto;
    font-size: xx-large;
    text-align: center;
    padding-left: 80px;
    padding-right: 20px;
    color: white;
    text-transform: uppercase;
    height: 110px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }

  .subtitle {
    font-size: large;
  }

  .ward {
    left: 115px;
    top: 3px;
    position: absolute;
    aspect-ratio: 1;
    z-index: 1;
    display: grid;
    grid-template-columns: 34px;
    grid-template-rows: 34px;
    gap: 0px 0px;
    grid-template-areas: "icon";
    align-items: anchor-center;
    justify-items: center;

    span {
      color: white;
      font-size: 1.6em;
      white-space: nowrap;
      line-height: 1;
      grid-area: icon;
      height: 100%;
      height: auto;
      transform: translate(2px, 2px);
    }

    &::before {
      content: "";
      background: rgb(126 10 17);
      border-radius: 50%;
      border: 2px solid rgb(139 122 90);
      width: 100%;
      height: 100%;
      grid-area: icon;
    }
  }

  .statWheel {
    position: absolute;
    background-image: url("https://raw.githubusercontent.com/BSData/age-of-sigmar-4th/main/images/statwheel.png");
    background-repeat: no-repeat;
    background-size: cover;
    height: 150px;
    width: 150px;
    z-index: 1;

    .statWheelStats {
      position: relative;
      height: 150px;
      width: 150px;
    }

    .statwheelEntry {
      position: absolute;
      text-align: center;
      height: 100%;
      width: 100%;
      color: white;

      .statLabel {
        font-size: 7px;
        text-transform: uppercase;

        svg {
          position: absolute;
          font-size: 1.2em;
          top: 0;
          left: 0;
          width: 150px;
          height: 150px;

          text {
            fill: #ffffff;
          }

          textPath {
            text-anchor: middle;
          }

          path {
            fill: transparent;
          }
        }
      }

      .stat {
        font-size: 1.6em;
        font-weight: 500;
      }
    }

    .statwheelEntry:nth-child(1) {
      .stat {
        transform: translate(2px, 38px);
      }

      svg {
        transform: rotate(-90deg);
      }
    }

    .statwheelEntry:nth-child(2) {
      .stat {
        transform: translate(-30px, 67px);
      }

      svg {
        transform: rotate(-180deg);
      }
    }

    .statwheelEntry:nth-child(3) {
      .stat {
        transform: translate(30px, 67px);
      }

      svg {
        transform: rotate(0deg);
      }
    }

    .statwheelEntry:nth-child(4) {
      .stat {
        transform: translateY(96px);
      }

      svg {
        transform: rotate(90deg);
      }
    }
  }

  .weapons-table {
    td>* {
      vertical-align: sub;
      vertical-align: -webkit-baseline-middle;
    }

    td,
    td {
      border: 1px solid var(--primary-color, cadetblue);
    }

    td:not(.placeholder) {
      padding: 3px;
    }

    td:has(+ .placeholder) {
      border-right: none;
    }

    td:first-child {
      border-left: none;
    }

    td:last-child {
      border-right: none;
    }

    td.placeholder {
      border-left: none;
      border-right: none;
    }

    thead {
      color: white;
      background-color: var(--primary-color, cadetblue);
    }

    thead tr td:first-child {
      text-transform: uppercase;
    }

    tbody tr:nth-child(even) {
      background-color: color-mix(in srgb, var(--primary-color, cadetblue) 25%, transparent);
    }

    border-collapse: collapse;
    padding: 0 20px;
    width: calc(100% - 50px);
    margin: 0 auto;
    text-align: center;
  }

  .rules {
    width: calc(100% - 50px);
    margin: 0 auto;

    .rule {
      margin-bottom: 1em;
    }

    .rule-name {
      font-weight: bold;

      &::after {
        content: ":";
      }
    }
  }

  .ability-section {
    gap: 8px;
    margin: 20px;
    width: calc(100% - 40px);
    column-count: 2;
    column-gap: 10px;

    @media screen and (max-width: 950px) {
      column-count: 1;
    }
  }

  .ability-wrapper {
    border: 1px solid var(--ability-color, black);
    border-top: none;
    margin: 0px 5px;
    background: rgba(255, 255, 255, 0.4);
  }

  .ability-description {
    padding: 8px;

    &>div:not(:last-child) {
      margin-bottom: 5px;
    }
  }

  .ability-keywords {
    display: flex;
    align-items: center;
    flex-wrap: nowrap;
    border-top: 1px solid var(--ability-color, black);

    .header {
      font-variant: small-caps;
      font-weight: 700;
      color: white;
    }
  }

  .ability-box {
    -webkit-column-break-inside: avoid;
    page-break-inside: avoid;
    /* Firefox is dumb */
    break-inside: avoid;
    padding: 0;
    height: min-content;
    position: relative;
    margin-bottom: 15px;

    .header-icon {
      width: 18px;
      height: 18px;
      fill: currentColor;
      vertical-align: text-bottom;

      &:has(use[href="#icon"]) {
        width: 0;
        height: 0;
      }
    }

    span[style*="small-caps"] {
      font-weight: 900;
    }

    td,
    td {
      border: none;
      text-align: left;
    }
  }

  .icon {
    position: absolute;
    z-index: 1;
    right: 0px;
    transform: translateX(calc(50% - var(--offset-x, 5px))) translateY(var(--offset-y, 0px));
    font-size: 14px;
    font-weight: bold;
    color: white;
    display: grid;
    grid-template-columns: 50px;
    grid-template-rows: 50px;
    gap: 0px 0px;
    grid-template-areas: "icon";
    align-items: center;
    justify-items: center;
    top: 2px;

    img,
    span,
    div {
      aspect-ratio: 1;
      grid-area: icon;
      width: 100%;
    }

    span,
    div {
      /* Flex, not block + align-content: Safari ignores align-content here and leaves the number at the top, outside the diamond */
      display: flex;
      align-items: center;
      justify-content: center;
    }
  }

  .cast {
    --offset-y: -15px;
    --offset-x: 22px;

    img {
      width: 46px;
      margin-top: -1px;
    }

    span,
    div {
      background-color: black;
      border-radius: 50vh;
      width: 28px;
      padding-top: 2px;
    }
  }

  .chant {
    --offset-y: -15px;
    --offset-x: 14px;
  }

  .command {
    --offset-y: -15px;
    --offset-x: 18px;

    span,
    div {
      color: black;
    }
  }

  .keyword-box {
    .header {
      font-weight: 700;
      align-self: stretch;
      align-content: center;
      background-color: var(--primary-color, black);
    }

    .split {
      &::first-letter {
        text-transform: uppercase;
      }

      text-transform: lowercase;
    }

    .header,
    .split {
      font-variant: small-caps;
    }

    .keywords {
      margin: 10px;
      display: inline;
      text-align: center;
      width: 100%;
      font-size: 1em;
      font-weight: 700;

      .split {
        white-space: nowrap;
        display: inline-block;
        /* for ::first-letter to work */
      }
    }

    &:has(.hide-keywords) {
      display: none;
    }

    display: flex;
    align-items: center;
    flex-wrap: nowrap;
    border: 1px solid var(--primary-color, black);
    width: calc(100% - 50px);
    margin: 20px auto 1.5em 1.5em;
  }

  .header {
    background-color: var(--ability-color, black);
    color: white;
    padding: 5px 10px 3px;
    font-weight: 500;
  }

  .header.bg {
    background-image: url("https://raw.githubusercontent.com/giloushaker/nr-templates/refs/heads/main/assets/backgrounds/aos-header-highres.png");
    background-size: auto 100%;
    background-color: color-mix(in srgb, var(--ability-color, black) 85%, transparent);
    background-blend-mode: multiply;
    clip-path: var(--jagged-edges-header);
  }

  .card.bg {
    background-image: url("https://raw.githubusercontent.com/giloushaker/nr-templates/refs/heads/main/assets/backgrounds/aos-highres.png");
    background-repeat: no-repeat;
    background-size: cover;
    background-color: color-mix(in srgb, var(--primary-color) 7.5%, transparent);
    background-blend-mode: darken;
  }

  .card {
    border: 1px solid black;
    padding-bottom: 1px;
  }

  [catalogue*="Beasts of Chaos"i] {
    --primary-color: #2e2211;
  }

  [catalogue*="Blades of Khorne"i] {
    --primary-color: #901515;
  }

  [catalogue*="Bonesplitterz"i] {
    --primary-color: #375b4b;
  }

  [catalogue*="Cities of Sigmar"i] {
    --primary-color: #40061d;
  }

  [catalogue*="Daughters of Khaine"i] {
    --primary-color: #531e2f;
  }

  [catalogue*="Disciples of Tzeentch"i] {
    --primary-color: #007087;
  }

  [catalogue*="Flesh-eater Courts"i] {
    --primary-color: #480911;
  }

  [catalogue*="Fyreslayers"i] {
    --primary-color: #922b0e;
  }

  [catalogue*="Gloomspite Gitz"i] {
    --primary-color: #365b4b;
  }

  [catalogue*="Hedonites of Slaanesh"i] {
    --primary-color: #531540;
  }

  [catalogue*="Idoneth Deepkin"i] {
    --primary-color: #004543;
  }

  [catalogue*="Ironjawz"i] {
    --primary-color: #375b4b;
  }

  [catalogue*="Kruleboyz"i] {
    --primary-color: #375b4b;
  }

  [catalogue*="Orruk Warclans"i] {
    --primary-color: #375b4b;
  }

  [catalogue*="Kharadron Overlords"i] {
    --primary-color: #69473a;
  }

  [catalogue*="Lumineth Realm-lords"i] {
    --primary-color: #004c65;
  }

  [catalogue*="Maggotkin of Nurgle"i] {
    --primary-color: #48540b;
  }

  [catalogue*="Nighthaunt"i] {
    --primary-color: #315749;
  }

  [catalogue*="Ogor Mawtribes"i] {
    --primary-color: #434f4d;
  }

  [catalogue*="Ossiarch Bonereapers"i] {
    --primary-color: #355748;
  }

  [catalogue*="Seraphon"i] {
    --primary-color: #2a757d;
  }

  [catalogue*="Skaven"i] {
    --primary-color: #585036;
  }

  [catalogue*="Slaves to Darkness"i] {
    --primary-color: #2e0b08;
  }

  [catalogue*="Sons of Behemat"i] {
    --primary-color: #462f34;
  }

  [catalogue*="Soulblight Gravelords"i] {
    --primary-color: #460000;
  }

  [catalogue*="Stormcast Eternals"i] {
    --primary-color: #72702c;
  }

  [catalogue*="Sylvaneth"i] {
    --primary-color: #496646;
  }

  [catalogue*="Regiments of Renown"i] {
    --primary-color: #7b0000;
  }

  [color="Black"],
  [timing~="Start"i] {
    --ability-color: black;
  }

  [color="Brown"],
  [color="Yellow"],
  [timing~="Hero"i],
  [timing~="Rally"i] {
    --ability-color: #a88d2f;
  }

  [color="Gray"],
  [color="Grey"],
  [timing~="Movement"i],
  [timing*="Redeploy"i] {
    --ability-color: #808285;
  }

  [color="Orange"],
  [timing~="Charge"i] {
    --ability-color: #ca6722;
  }

  [color="Red"],
  [timing~="Combat"i],
  [timing~="Champion"i] {
    --ability-color: #8b0018;
  }

  [color="Purple"],
  [timing~="End"i],
  [timing~="Standard"i],
  [timing~="Trophy"i] {
    --ability-color: #5d367d;
  }

  [color="Blue"],
  [timing~="Shooting"i],
  [timing~="Guarded"i] {
    --ability-color: #00526d;
  }

  [color="Green"] {
    --ability-color: #365419;
  }
</style>`,Qd=`<template>
    <div id="template-root">
        <set name="ruleProfiles" value="special rule,rule,rules,command" />

        <script>
            globalCatName = "";
            globalArmyName = "";

            try {
                if (typeof roster !== 'undefined') {
                    // Attempt to grab the Roster custom name, fallback to file name
                    if (roster.customName) {
                        globalArmyName = roster.customName;
                    } else if (roster.name) {
                        globalArmyName = roster.name;
                    }

                    // The proven path from our Scanner Test to get 'Dogs of War'
                    if (roster.selector) {
                        if (roster.selector.root) {
                            if (roster.selector.root.book) {
                                globalCatName = roster.selector.root.book.name;
                            }
                        }
                    }
                }
            } catch (e) { }
        <\/script>

        <table class="master-print-table">
            <tbody>
                <tr>
                    <td>
                        <div class="roster-state-wrapper">
                            <div class="scribe-controls no-print">
                                <input type="checkbox" id="hide-rules-toggle" />
                                <label for="hide-rules-toggle">
                                    <strong>HIDE RULES GLOSSARY</strong>
                                    <br />
                                    <span class="control-subtext">(Check this box to instantly remove the Rules &amp; Profiles Glossary from the bottom of your Battle Forces before printing).</span>
                                </label>
                                <br /><br />
                                <input type="checkbox" id="pagebreak-rules-toggle" />
                                <label for="pagebreak-rules-toggle">
                                    <strong>RULES ON NEW PAGE</strong>
                                    <br />
                                    <span class="control-subtext">(Check this box to force the Rules &amp; Profiles Glossary onto its own separate page when printing).</span>
                                </label>
                            </div>

                            <div class="force-title-banner">
                                BATTLE FORCE: {{globalArmyName}}
                                <if field="globalCatName">({{globalCatName}})</if>
                            </div>

                            <div class="roster-page force-container">
                                <div class="document-header">
                                    <div class="header-row">
                                        <div class="header-field"><span class="label">PLAYER:</span><span class="line"></span></div>
                                        <div class="header-field">
                                            <span class="label">ARMY NAME:</span>
                                            <span class="line force-name-text">
                                                {{globalArmyName}}
                                            </span>
                                        </div>
                                    </div>
                                    <div class="header-row">
                                        <div class="header-field">
                                            <span class="label">GENERAL:</span>
                                            <span class="line force-name-text">
                                                <groupBy>
                                                    <units>
                                                        <by>
                                                            <if field="primary">{{primary}}</if>
                                                        </by>
                                                    </units>
                                                    <groups>
                                                        <items>
                                                            <set name="isGen" value="false" />
                                                            <entries recursive="true">
                                                                <if field="name" type="match" value="General" flags="i">
                                                                    <set name="isGen" value="true" />
                                                                </if>
                                                                <if field="categories">
                                                                    <categories>
                                                                        <if field="name" type="match" value="General" flags="i">
                                                                            <set name="isGen" value="true" />
                                                                        </if>
                                                                    </categories>
                                                                </if>
                                                            </entries>
                                                            <if field="isGen" type="equals" value="true">
                                                                <if field="customName">{{customName}} (</if>{{name}}<if field="customName">)</if>
                                                            </if>
                                                        </items>
                                                    </groups>
                                                </groupBy>
                                            </span>
                                        </div>
                                        <div class="header-field">
                                            <span class="label">TOTAL PTS:</span>
                                            <span class="line force-name-text">
                                                <costs>
                                                    <if field="name" type="match" value="pts" flags="i">{{value}}</if>
                                                </costs>
                                            </span>
                                        </div>
                                    </div>

                                    <if field="note">
                                        <div class="roster-note-block">
                                            <strong>ROSTER NOTES:</strong> <span type="markdown">{{note}}</span>
                                        </div>
                                    </if>
                                </div>

                                <groupBy>
                                    <units>
                                        <by>
                                            <if field="primary">{{primary}}</if>
                                            <if field="primary" type="not">General Rules</if>
                                        </by>
                                    </units>
                                    <groups>
                                        <if field="primary" type="not-match" value="^(Special list rules|Experimental rules|Campaign/Scenario rules)$" flags="i">
                                            <div class="category-block">
                                                <items max="1">
                                                    <h3 class="category-title">
                                                        <if field="primary">{{primary}}</if>
                                                        <if field="primary" type="not">General Rules</if>
                                                    </h3>
                                                </items>
                                                <items>
                                                    <if type="has-profile" recursive="true">
                                                        <div class="unit-card">
                                                            <table class="unit-table">
                                                                <tr class="unit-header-row">
                                                                    <th colspan="2" class="unit-header-name">UNIT: <if field="customName">{{customName}} ({{name}})</if>
                                                                        <if field="customName" type="not">{{name}}</if>
                                                                    </th>
                                                                    <th class="unit-header-size">SIZE: <span class="calc-size">
                                                                            <entries>
                                                                                <if field="type" type="equals" value="model">{{number}}{{amount}}</if>
                                                                            </entries>
                                                                        </span><span class="fallback-size">{{number}}{{amount}}</span></th>
                                                                    <th class="unit-header-pts">PTS: <costs>
                                                                            <if field="name" type="match" value="pts" flags="i">{{value}}</if>
                                                                        </costs>
                                                                    </th>
                                                                    <th class="unit-header-upgrades">UPGRADES / SELECTIONS</th>
                                                                    <th class="unit-header-rules">RULES</th>
                                                                </tr>
                                                                <tr class="unit-data-row">
                                                                    <td colspan="4" class="profile-cell">
                                                                        <profiles exclude="{{ruleProfiles}}" recursive="true" grouped="true" amount="false">
                                                                            <table class="profile-inner-table">
                                                                                <items max="1">
                                                                                    <tr>
                                                                                        <th class="profile-type">{{typeName}}</th>
                                                                                        <characteristics>
                                                                                            <if field="length" type="not-equals" value="1">
                                                                                                <th class="stat-heading">{{name}}</th>
                                                                                            </if>
                                                                                        </characteristics>
                                                                                    </tr>
                                                                                </items>
                                                                                <items>
                                                                                    <tr class="stat-row">
                                                                                        <characteristics>
                                                                                            <if field="length" type="equals" value="1">
                                                                                                <td class="name single-data" colspan="15"><span class="profile-name">{{item.name}}</span><span
                                                                                                        class="data" type="markdown">{{value}}</span></td>
                                                                                            </if>
                                                                                        </characteristics>
                                                                                        <else>
                                                                                            <td class="name">{{item.name}}</td>
                                                                                            <characteristics>
                                                                                                <td class="data" type="markdown">{{value}}</td>
                                                                                            </characteristics>
                                                                                        </else>
                                                                                    </tr>
                                                                                </items>
                                                                            </table>
                                                                        </profiles>
                                                                    </td>
                                                                    <td class="upgrades-cell">
                                                                        <costs>
                                                                            <if field="name" type="not-match" value="pts" flags="i">
                                                                                <div class="list-item"><strong>{{name}}:</strong> {{value}}</div>
                                                                            </if>
                                                                        </costs>
                                                                        <set name="parentUnitName" value="{{name}}" />
                                                                        <dedupe>
                                                                            <entries>
                                                                                <if field="type" type="equals" value="upgrade">
                                                                                    <if field="name" type="not-equals" value="{{parentUnitName}}">
                                                                                        <div class="list-item">
                                                                                            <if field="number" type="greater" value="1">{{number}}x </if>{{name}}
                                                                                        </div>
                                                                                    </if>
                                                                                </if>
                                                                            </entries>
                                                                        </dedupe>
                                                                    </td>
                                                                    <td class="rules-cell">
                                                                        <dedupe>
                                                                            <rules>
                                                                                <div class="list-item">{{name}}</div>
                                                                            </rules>
                                                                            <profiles include="{{ruleProfiles}}">
                                                                                <div class="list-item">{{name}}</div>
                                                                            </profiles>
                                                                        </dedupe>
                                                                    </td>
                                                                </tr>
                                                                <if field="note">
                                                                    <tr class="unit-note-row">
                                                                        <td colspan="6" class="unit-note-cell"><strong>NOTE:</strong> <span type="markdown">{{note}}</span></td>
                                                                    </tr>
                                                                </if>
                                                            </table>
                                                        </div>
                                                    </if>
                                                </items>
                                            </div>
                                        </if>
                                    </groups>
                                </groupBy>

                                <div class="global-rules-section">
                                    <h2 class="rules-summary-title">RULES AND ITEMS GLOSSARY</h2>
                                    <dedupe>
                                        <entries recursive="true">
                                            <rules>
                                                <div class="global-rule-item"><span class="rule-name">{{name}}:</span> <span class="rule-desc" type="markdown">{{description}}</span></div>
                                            </rules>
                                            <profiles include="{{ruleProfiles}}">
                                                <div class="global-rule-item"><span class="rule-name">{{name}}:</span>
                                                    <characteristics><span class="rule-desc" type="markdown">{{value}}</span></characteristics>
                                                </div>
                                            </profiles>
                                        </entries>
                                    </dedupe>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<style>
    @page {
        size: auto;
        margin: 12mm;
    }

    html,
    body {
        margin: 0;
        padding: 0;
        background-color: #ffffff;
        color: #000000;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 11px;
        line-height: 1.2;
    }

    * {
        box-sizing: border-box;
        print-color-adjust: exact !important;
        -webkit-print-color-adjust: exact !important;
    }

    .scribe-controls {
        background-color: #f5f5f5;
        border: 2px dashed #000000;
        margin: 20px auto;
        padding: 15px;
        max-width: 1000px;
        text-align: center;
    }

    .control-subtext {
        font-size: 11px;
        font-style: italic;
        color: #555;
    }

    /* FIX: Added the missing CSS logic for the pagebreak toggle right here */
    .roster-state-wrapper:has(#hide-rules-toggle:checked) .global-rules-section {
        display: none !important;
    }

    .roster-state-wrapper:has(#pagebreak-rules-toggle:checked) .global-rules-section {
        page-break-before: always !important;
        break-before: page !important;
    }

    @media print {
        .no-print {
            display: none !important;
        }
    }

    .master-print-table {
        width: 100%;
        border-collapse: collapse;
        border: none;
    }

    .master-print-table td {
        padding: 0;
        border: none;
    }

    .master-print-table tr {
        break-inside: auto;
    }

    tfoot {
        display: table-footer-group;
    }

    .footer-stamp {
        text-align: center;
        border-top: 1px solid #000000;
        padding-top: 5px;
        margin-top: 20px;
        color: #000000;
        font-size: 9px;
        text-transform: uppercase;
    }

    .category-block {
        display: none;
    }

    .category-block:has(.unit-card) {
        display: block;
    }

    .calc-size:not(:empty)+.fallback-size {
        display: none;
    }

    .force-title-banner {
        background-color: #000000;
        color: #ffffff;
        text-align: center;
        font-size: 16px;
        font-weight: bold;
        padding: 8px;
        margin-top: 30px;
        margin-bottom: 20px;
        border: 2px solid #000000;
        text-transform: uppercase;
        max-width: 1000px;
        margin-left: auto;
        margin-right: auto;
    }

    .force-container {
        margin-bottom: 60px;
        padding-bottom: 40px;
        border-bottom: none;
        page-break-after: always;
    }

    .roster-page {
        width: 100%;
        max-width: 1000px;
        margin: 0 auto;
    }

    .document-header {
        margin-top: 20px;
        margin-bottom: 25px;
        width: 100%;
    }

    .header-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 8px;
    }

    .header-field {
        display: flex;
        flex: 1;
        align-items: flex-end;
        margin-right: 20px;
    }

    .header-field .label {
        font-weight: bold;
        font-size: 12px;
        margin-right: 5px;
        white-space: nowrap;
    }

    .header-field .line {
        flex-grow: 1;
        border-bottom: 1px solid #000000;
        height: 1em;
        padding-left: 5px;
        font-style: italic;
        font-size: 13px;
    }

    .roster-note-block {
        margin-top: 15px;
        padding: 8px 10px;
        border: 1px solid #000000;
        background-color: #fcfcfc;
        font-size: 11px;
    }

    .category-title {
        font-size: 14px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #000000;
        color: #ffffff;
        padding: 4px 8px;
        margin-bottom: 12px;
        border: 1px solid #000000;
        page-break-after: avoid;
    }

    .unit-card {
        break-inside: avoid;
        page-break-inside: avoid;
        margin-bottom: 24px;
        width: 100%;
    }

    .unit-table {
        border-collapse: collapse;
        width: 100%;
        table-layout: auto;
        border: 2px solid #000000;
        background-color: #ffffff;
    }

    .unit-header-row th {
        background-color: #ffffff;
        color: #000000;
        font-size: 11px;
        font-weight: bold;
        text-transform: uppercase;
        border: 1px solid #000000;
        padding: 6px 8px;
        text-align: left;
    }

    .unit-header-name {
        width: 35%;
    }

    .unit-header-size {
        width: 10%;
        text-align: center;
    }

    .unit-header-pts {
        width: 10%;
        text-align: center;
    }

    .unit-header-upgrades {
        width: 7.0%;
    }

    .unit-header-rules {
        width: 7.0%;
    }

    .unit-data-row td {
        vertical-align: top;
        border: 1px solid #000000;
        padding: 0;
    }

    .unit-note-cell {
        border: 1px solid #000000;
        padding: 6px 8px;
        font-size: 10px;
        background-color: #fafafa;
        border-top: 1px dashed #000000;
    }

    .upgrades-cell,
    .rules-cell {
        padding: 6px;
        font-size: 9px;
    }

    .list-item {
        margin-bottom: 3px;
        padding-left: 8px;
        text-indent: -8px;
    }

    .list-item::before {
        content: "- ";
    }

    .profile-inner-table {
        border-collapse: collapse;
        width: 100%;
        border: none;
        table-layout: auto;
    }

    .profile-inner-table th,
    .profile-inner-table td {
        border: 1px solid #000000;
        padding: 3px 5px;
        text-align: center;
        word-wrap: normal;
    }

    .profile-inner-table th {
        font-weight: bold;
        text-transform: uppercase;
        font-size: 9px;
        background-color: #e6e6e6 !important;
        border-top: 1px solid #000000;
    }

    .profile-inner-table th.profile-type {
        text-align: left;
        width: 30%;
    }

    .profile-inner-table td.name {
        text-align: left;
        font-weight: bold;
    }

    .profile-inner-table td.single-data {
        text-align: left;
        font-weight: normal;
    }

    .profile-name {
        font-weight: bold;
    }

    .profile-name:has(+.data)::after {
        content: ": ";
    }

    .global-rules-section {
        margin-top: 20px;
        border-top: none;
        padding-top: 15px;
    }

    .rules-summary-title {
        font-size: 13px;
        font-weight: bold;
        text-transform: uppercase;
        margin-bottom: 12px;
    }

    .global-rule-item {
        margin-bottom: 10px;
        text-align: justify;
        font-size: 10px;
    }

    .rule-name {
        font-weight: bold;
        text-transform: uppercase;
    }

    ol,
    ul,
    menu {
        margin: 0;
        padding-left: 16px;
        margin-bottom: -18px;
    }
</style>`,Ud=`<template>
  <p style="padding: 10px" class="print-display-none">
    Inspired by <a href="https://nilsueter.github.io/fancyscribe/" target="_blank"><b>FancyScribe</b></a>
  </p>
  <setting id="expandRules" label="Expand Rules" type="checkbox" default="false" />
  <setting id="showUnitImages" label="Include Unit Images" type="checkbox" default="true" />
  <set name="ruleProfiles" value="special rule,rule,rules" />
  <set name="unitProfiles" value="model,unit,stats,vehicle,ship,profile,knight" />
  <set name="hideCharacteristics" value="troop type,unit size,unit type,access points,type" />
  <set name="dataProfiles" value="ranged weapons,ranged weapon,psychic weapon,melee weapons,melee weapon,weapons,magic weapons,magic weapon,weapon,spell,load" />
  <set
    name="abilityProfiles"
    value="ability,abilities,ability (passive),ability (activated),ability (spell),ability (command),ability (prayer),psychic power,wargear item,reaction"
  >
    <if field="settings.expandRules.state" type="equals" value="true">
      <append-attribute name="value" value="special rule,rule,rules" join="," />
    </if>
  </set>
  <set name="hideProfiles" value="base" />
  <set name="infoCharacteristics" value="abilities,notes,note,description,effect,details,longText" />
  <set name="inlineCharacteristics" value="tag,annotation,keywords,special rules,ability,number,special">
    <if field="system.name" type="equals" value="Horus Heresy (2022)">
      <append-attribute name="value" value="type" join="," />
    </if>
  </set>

  <units dedupe="true">
    <if type="has-profile" value="{{unitProfiles}}" recursive="true">
      <div class="avoid-page-break" style="margin-bottom: 52px" type="card" catalogue="{{catalogue}}">
        <div
          class="min-h-15rem"
          style="
            padding: 24px 0px;
            background: linear-gradient(90deg, rgb(20, 21, 25) 0%, rgb(48, 57, 62) 45%, rgb(73, 74, 79) 100%);
            color: rgb(255, 255, 255);
            position: relative;
          "
        >
          <div style="display: flex; gap: 5px">
            <!-- Header Section -->
            <div style="padding: 4px 16px; color: rgb(255, 255, 255); position: relative; margin-left: 1.3rem; flex: 1">
              <!--  Title Background Graphic -->
              <div style="position: absolute; left: 0px; top: 0px; width: 100%; display: flex">
                <div style="background-color: var(--primary-color-transparent); height: 80px; min-width: 33%"> </div>
                <div style="height: 79px; display: flex; flex-direction: column">
                  <div style="background-color: var(--primary-color-transparent); height: 40px"></div>
                  <svg height="40" width="100" viewBox="0 0 100 40" style="fill: var(--primary-color-transparent)">
                    <path d="m0 0h100c-32 0-68 40-100 40z"></path>
                  </svg>
                </div>
                <div style="flex: 10 1 0%; background-color: var(--primary-color-transparent); height: 40px"> </div>
              </div>

              <!--  Unit Name & Costs -->
              <div
                style="
                  font-family: ConduitITCStd;
                  font-size: 2.5em;
                  letter-spacing: 0.1px;
                  line-height: 1;
                  font-weight: 800;
                  text-transform: uppercase;
                  z-index: 1;
                  position: relative;
                  display: flex;
                  justify-content: space-between;
                  align-items: center;
                  margin-bottom: 2px;
                "
              >
                <if field="customName">
                  <span>{{customName}} <span style="color: darkgrey; margin-left: 10px">{{name}}</span></span>
                </if>
                <else>
                  <span>{{name}}</span>
                </else>
                <costs>
                  <span style="text-transform: initial; font-size: 1.2rem">
                    <span>{{value}}</span>
                    <span>{{name}}</span>
                  </span>
                </costs>
              </div>

              <!-- Models -->
              <div style="display: flex; flex-direction: column; gap: 6px; z-index: 1; position: relative">
                <groupBy>
                  <entries>
                    <if type="has-profile" value="{{unitProfiles}}">
                      <by>
                        <profiles include="{{unitProfiles}}" recursive="false">
                          <characteristics exclude="{{hideCharacteristics}}">{{name}}{{$text}} </characteristics>
                        </profiles>
                      </by>
                    </if>
                  </entries>

                  <groups>
                    <div style="display: flex; gap: 6px; z-index: 1; position: relative">
                      <!-- Model Stats -->
                      <items max="1">
                        <profiles include="{{unitProfiles}}" recursive="false">
                          <characteristics exclude="{{hideCharacteristics}}">
                            <div class="modelCharacteristic" style="display: flex; flex-direction: column; align-items: center">
                              <div style="font-size: 0.9em; font-weight: 800">{{name}}</div>
                              <div
                                style="
                                  color: var(--primary-color);
                                  padding: 2px;
                                  background: var(--primary-color);
                                  clip-path: polygon(12% 0px, 100% 0px, 100% 20%, 100% 88%, 88% 100%, 20% 100%, 0px 100%, 0px 12%);
                                "
                              >
                                <div
                                  style="
                                    min-width: 3rem;
                                    min-height: 3rem;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                    background: rgb(232, 237, 231);
                                    clip-path: polygon(10% 0px, 100% 0px, 100% 20%, 100% 90%, 90% 100%, 20% 100%, 0px 100%, 0px 10%);
                                    padding: 3px;
                                    font-size: 1.6em;
                                    font-weight: 800;
                                  "
                                >
                                  {{$text}}
                                </div>
                              </div>
                            </div>
                          </characteristics>
                        </profiles>
                      </items>

                      <div class="model" style="display: flex; gap: 1.2rem">
                        <items>
                          <!-- Model Name & Options -->
                          <div class="flex flex-wrap items-center gap-2 model-name-options" style="margin-top: 16px; text-shadow: rgb(0, 0, 0) 0px 0px 5px; display: inline-block">
                            <span style="white-space: nowrap">
                              <if field="amount" type="greater" value="1">
                                <span>{{amount}}x</span>
                              </if>
                              <if field="ungrouped.length" type="greater" value="1">
                                <span class="model-name">{{name}}</span>
                              </if>
                            </span>
                            <div style="font-size: 0.7em">
                              <div class="model-options"> {{options}}</div>
                            </div>
                          </div>
                        </items>
                      </div>
                    </div>
                  </groups>
                </groupBy>
              </div>
            </div>

            <!-- Unit Miniature Image -->
            <if field="settings.showUnitImages.state" type="equals" value="true">
              <if field="miniatureImageUrl">
                <div style="border: 3px solid var(--primary-color); border-radius: 8px; overflow: hidden; background: white; flex-shrink: 0; align-self: flex-start">
                  <img src="https://www.newrecruit.eu{{miniatureImageUrl}}" alt="{{name}}" style="width: 100px; height: 125px; object-fit: cover; display: block" />
                </div>
              </if>
            </if>
          </div>
        </div>
        <div class="border-b-2 border-t-0 border-var(--primary-color) sm:border-l-2 sm:border-r-2" style="display: flex; background-color: rgb(223, 224, 226)">
          <!-- Left Section -->
          <div class="pt-5" style="width: 65%; border-right: 2px solid var(--primary-color); position: relative; padding-bottom: 40px; display: flex; flex-direction: column">
            <!-- Data Profiles -->
            <profiles grouped="true" include="{{dataProfiles}}">
              <table cellspacing="0" class="weapons-table" style="width: 100%">
                <thead>
                  <items max="1">
                    <tr class="uppercase" style="background-color: var(--primary-color); color: rgb(255, 255, 255)">
                      <th style="max-width: 32px; min-width: 32px; width: 0%">
                        <div style="display: flex; width: 100%; justify-content: center">
                          <img class="profile-icon" typeName="{{typeName}}" style="max-width: 20px" src="" />
                        </div>
                      </th>
                      <th style="text-align: left" class="row-header">
                        <span>{{typeName}}</span>
                        <if field="group"><span style="font-weight: normal; text-transform: none">({{group}})</span> </if>
                      </th>

                      <characteristics exclude="{{inlineCharacteristics}},{{infoCharacteristics}}">
                        <th class="data-cell">{{name}}</th>
                      </characteristics>
                    </tr>
                  </items>
                </thead>
                <tbody>
                  <items>
                    <tr>
                      <td style="border-top: none; background-color: rgb(223, 224, 226)"></td>
                      <td style="text-align: left">
                        <div style="display: flex; align-items: baseline; flex-wrap: wrap; gap: 0px 4px; line-height: 1.05">
                          <span style="font-weight: bold">{{name}}</span>

                          <!-- Inlined after name Characteristics -->
                          <characteristics include="{{inlineCharacteristics}}" max="1">
                            <if type="not-match" value="^\\\\s*-\\\\s*$" field="$text">
                              <span if="$text" style="font-size: 0.8em; font-weight: 700; color: var(--primary-color); text-transform: uppercase; line-height: 1.5">
                                [<span type="markdown">{{$text}}</span>]
                              </span>
                            </if>
                          </characteristics>
                        </div>
                      </td>
                      <characteristics exclude="{{inlineCharacteristics}},{{infoCharacteristics}}">
                        <td class="align-middle" type="markdown">{{$text}}</td>
                      </characteristics>
                    </tr>

                    <!-- Full row spanning characteristic such as notes -->
                    <characteristics include="{{infoCharacteristics}}">
                      <if field="$text">
                        <if field="$text" type="not-match" value="^[-\\\\s]*$">
                          <tr class="noBorderTop">
                            <td style="border-top: none; background-color: rgb(223, 224, 226)"> </td>
                            <td colspan="7" class="row" style="text-align: left; font-size: 0.9em; padding-top: 0px; padding-bottom: 1px; line-height: 1.4" type="markdown"
                              >{{$text}}</td
                            >
                          </tr>
                        </if>
                      </if>
                    </characteristics>
                  </items>
                  <items max="1">
                    <tr class="emptyRow">
                      <td style="border-top: none"></td>
                      <td colspan="7"></td>
                    </tr>
                  </items>
                </tbody>
              </table>
            </profiles>

            <!-- Remaining Misc profiles -->
            <profiles grouped="true" exclude="{{unitProfiles}},{{ruleProfiles}},{{dataProfiles}},{{abilityProfiles}},{{hideProfiles}}">
              <table cellspacing="0" style="width: 100%" class="removable">
                <thead>
                  <items max="1">
                    <tr class="uppercase" style="background-color: var(--primary-color); color: rgb(255, 255, 255)">
                      <th style="width: 32px; min-width: 32px" />
                      <th colspan="7" class="row" style="text-align: left">{{typeName}}</th>
                    </tr>
                  </items>
                </thead>
                <tbody>
                  <items>
                    <tr style="border-top: 1px dotted #9e9fa1" class="removable">
                      <td class="w-2em"></td>
                      <td colspan="7" style="font-size: 1em; line-height: 1.4; text-align: left; padding-top: 4px; padding-bottom: 4px">
                        <span style="font-weight: 700">{{name}}</span>:
                        <characteristics>
                          <if field="$text">
                            <if field="length" type="greater" value="1">
                              <div style="margin-left: 4px"
                                ><span style="font-weight: bold; font-size: 0.8em">{{name}}</span>:
                                <span type="markdown">{{$text}}</span>
                              </div>
                            </if>
                            <if field="length" type="atmost" value="1">
                              <span type="markdown">{{$text}}</span>
                            </if>
                          </if>
                        </characteristics>
                      </td>
                    </tr>
                  </items>
                </tbody>
              </table>
            </profiles>

            <!-- Keywords / Categories -->
            <div
              style="
                position: absolute;
                right: -2px;
                bottom: -16px;
                padding: 0px 42px 0px 8px;
                display: flex;
                align-items: center;
                background-color: rgb(188, 188, 190);
                border: 2px solid var(--primary-color);
                width: calc(100% - 0.9rem);
                background-size: contain;
                min-height: 54px;
                gap: 3px;
              "
            >
              <span style="font-size: 1.1em">KEYWORDS:</span>
              <div>
                <secondaries>
                  <if field="name" type="not-match" value="faction: .*" flags="i">
                    <if field="length" type="atleast" value="5">
                      <span class="split rule" style="font-size: 0.9em; font-weight: 800; display: inline-block">{{name}}</span>
                    </if>
                    <if field="length" type="less" value="5">
                      <span class="split rule" style="font-size: 1em; font-weight: 800; display: inline-block">{{name}}</span>
                    </if>
                  </if>
                </secondaries>
              </div>
            </div>
          </div>

          <!-- Right Section -->
          <div
            class="relative w-full flex-1 p-1 pb-50pxpt-5 print:p-20px sm:p-2 sm:pb-50px sm:pt-5 sm:print:p-20px sm:print:pb-50px md:p-20px md:pb-50px md:pt-5 md:print:p-20px md:print:pb-50px"
          >
            <div
              style="
                font-size: 1.1em;
                padding: 1px 6px;
                background-color: var(--primary-color);
                color: rgb(255, 255, 255);
                font-weight: 600;
                min-height: 27px;
                display: flex;
                align-items: center;
              "
            >
              ABILITIES
            </div>

            <!-- Rules -->
            <div class="rules-block" style="padding: 5px 2px; gap: 3px; border-bottom: 1px dotted rgb(158, 159, 161); line-height: 1.3; display: flex; flex-wrap: wrap">
              <span style="font-size: 0.8em">RULES: </span>
              <profiles include-rules="true" exclude-entries-with-profile="{{dataProfiles}}" exclude="{{abilityProfiles}}" include="{{ruleProfiles}}">
                <span class="split rule" style="white-space: nowrap; font-size: 0.8em; font-weight: 700">{{name}}</span>
              </profiles>
            </div>

            <!-- Ability Profiles -->
            <div class="hide-if-empty" style="display: flex; flex-direction: column; gap: 8px; padding: 4px 2px; border-bottom: 1px dotted rgb(158, 159, 161)">
              <profiles include-rules="true" include="{{abilityProfiles}}" exclude-entries-with-profile="{{dataProfiles}}">
                <div class="removable" style="font-size: 0.8em; line-height: 1.4">
                  <span class="rule-name" style="font-weight: 700">{{name}}</span>
                  <characteristics>
                    <if field="$text">
                      <if field="length" type="greater" value="1">
                        <div class="removable" style="margin-left: 4px"
                          ><span style="font-weight: bold; font-size: 0.8em">{{name}}</span>:
                          <span type="markdown">{{$text}}</span>
                        </div>
                      </if>
                      <if field="length" type="atmost" value="1">
                        <span class="removable" type="markdown">{{$text}}</span>
                      </if>
                    </if>
                  </characteristics>
                </div>
              </profiles>
            </div>

            <!-- Placeholder to prevent text being under keywords -->
            <div style="margin-bottom: 50px" />

            <!-- Faction Keywords/Categories -->
            <div class="keywords">
              <span style="font-size: 0.9em; line-height: 1.3">FACTION KEYWORDS:</span>
              <secondaries>
                <if field="name" type="match" value="faction: .*" flags="i">
                  <script>
                    cleanedName = String(secondary.name ?? "").match(/faction: (.*)/i)[1];
                  <\/script>
                  <span class="split keyword" style="font-size: 0.9em; font-weight: 600; white-space: nowrap">{{cleanedName}}</span>
                </if>
              </secondaries>
            </div>

            <!-- Faction Icon-->
            <div
              style="
                position: absolute;
                left: -28px;
                bottom: -16px;
                width: 54px;
                height: 54px;
                transform: rotate(-45deg);
                border: 2px solid var(--primary-color);
                overflow: hidden;
                display: flex;
                align-items: center;
                justify-content: center;
              "
            >
              <div style="background: center center rgb(188, 188, 190); min-height: 75px; min-width: 76px; transform: rotate(45deg)"> </div>
            </div>
          </div>
        </div>
      </div>
    </if>
  </units>

  <!-- Rules -->
  <div type="card">
    <div class="rules-list">
      <forces>
        <if type="has-rule">
          <div class="force removable"
            ><span class="force-name">{{name}}</span> <span class="force-catalogue">({{catalogue}})</span>
            <rules recursive="false">
              <div class="rule nested removable">
                <span class="rule-name">{{name}}</span>
                <span class="rule-desc" type="markdown">{{description}}</span>
              </div>
            </rules>
          </div>
        </if>
      </forces>
      <profiles include-rules="true" include="{{ruleProfiles}}">
        <div class="rule removable">
          <span class="rule-name">{{name}}</span>
          <characteristics>
            <span class="rule-desc" type="markdown">{{value}}</span>
          </characteristics>
        </div>
      </profiles>
    </div>
  </div>
</template>
<style>
  @import url("https://cdn.jsdelivr.net/npm/notosans-fontface@1.3.0/css/notosans-fontface.min.css");

  html {
    --primary-color: #206173;
    --primary-color-transparent: #20617360;
  }

  html {
    line-height: 1.5;
    -webkit-text-size-adjust: 100%;
    -moz-tab-size: 4;
    -o-tab-size: 4;
    tab-size: 4;
    font-feature-settings: normal;
    font-variation-settings: normal;

    @media screen and (min-width: 1400px) {
      column-count: 2;
      column-gap: 10px;
    }

    @media screen and (min-width: 1950px) {
      column-count: 3;
      column-gap: 10px;
    }

    @media screen and (min-width: 2600px) {
      column-count: 4;
      column-gap: 10px;
    }
  }

  @media print {
    body {
      margin: 0;
      line-height: inherit;
    }
  }

  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    font-size: inherit;
    font-weight: inherit;
  }

  b,
  strong {
    font-weight: bolder;
  }

  small {
    font-size: 80%;
  }

  table {
    text-indent: 0;
    border-color: inherit;
    border-collapse: collapse;
  }

  blockquote,
  dl,
  dd,
  h1,
  h2,
  h3,
  h4,
  h5,
  h6,
  hr,
  figure,
  p,
  pre {
    margin: 0;
  }

  ol,
  ul,
  menu {
    margin: 0;
    padding-left: 18px;
    margin-bottom: -18px;
  }

  :disabled {
    cursor: default;
  }

  img,
  svg,
  video,
  canvas,
  audio,
  iframe,
  embed,
  object {
    display: block;
    vertical-align: middle;
  }

  img,
  video {
    max-width: 100%;
    height: auto;
  }

  [hidden] {
    display: none;
  }

  *,
  :before,
  :after {
    box-sizing: border-box;
    border-width: 0;
    border-style: solid;
    border-color: #e5e7eb;
  }

  :root {
    font-family: "Noto Sans", sans-serif, Inter, system-ui, Avenir, Helvetica, Arial, sans-serif;

    font-size: 14px;
    color-scheme: light dark;
    color: #111113;
    background-color: #fff;
    text-rendering: optimizeLegibility;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-text-size-adjust: 100%;
    --size-20: 20px;
    --size-24: 24px;
    --size-32: 32px;
  }

  @font-face {
    font-family: ConduitITCStd;
    src: url("https://nilsueter.github.io/fancyscribe/fonts/ConduitITCStd ExtraBold.woff2") format("woff2");
    font-weight: 800;
  }

  @font-face {
    font-family: ConduitITCStd;
    src: url("https://nilsueter.github.io/fancyscribe/fonts/ConduitITCStd Bold.woff2") format("woff2");
    font-weight: 700;
  }

  * {
    box-sizing: border-box;
    print-color-adjust: exact;
    -webkit-print-color-adjust: exact;
  }

  body {
    margin: 0;
  }

  h1 {
    font-size: 3.2em;
    line-height: 1.1;
  }

  a {
    font-weight: 500;
    color: #646cff;
    text-decoration: inherit;
  }

  a:hover {
    color: #535bf2;
  }

  .weapons-table th {
    font-size: 1.1em;
    padding: 2px 0.8rem;
    height: 27px;
    font-weight: 600;
  }

  .weapons-table td {
    padding: 1px 0.8rem;
    text-align: center;
  }

  .weapons-table td:nth-child(2),
  .weapons-table th:nth-child(2) {
    padding-left: 0 !important;
  }

  .weapons-table tr:not(:first-child) {
    border-top: 1px dotted #9e9fa1;
  }

  .data-cell {
    padding: 2px 0.8rem !important;
  }

  .noBorderTop td {
    border-top: none;
  }

  .emptyRow {
    height: 22.5px;
  }

  .avoid-page-break {
    position: relative;
    page-break-inside: avoid;
    -moz-column-break-inside: avoid;
    break-inside: avoid;
  }

  .page-break:not(.print-display-none) {
    page-break-after: page;
    -moz-column-break-after: page;
    break-after: page;
  }

  @media print {
    .print-display-none,
    .print-display-none * {
      display: none !important;
    }

    #root {
      min-width: 1000px;
    }

    .body {
      padding: 0;
      display: block;
      max-width: none;
    }
  }

  @media screen and (max-width: 800px) {
    :root {
      font-size: 11px;
      --size-20: 8px;
      --size-24: 12px;
      --size-32: 16px;
    }
  }

  @media screen and (max-width: 640px) {
    :root {
      font-size: 9px;
      line-height: 1.3;
      --size-20: 8px;
      --size-24: 12px;
      --size-32: 16px;
    }

    .body {
      padding-left: 0;
      padding-right: 0;
    }

    .weapons-table th {
      font-size: 0.9em;
      padding: 2px 0.2rem;
    }

    .weapons-table td {
      font-size: 0.95em;
      padding: 1px 0.2rem;
    }
  }

  .visible {
    visibility: visible;
  }

  .absolute {
    position: absolute;
  }

  .relative {
    position: relative;
  }

  .right--4px {
    right: -4px;
  }

  .right-1px {
    right: 1px;
  }

  .top--4px {
    top: -4px;
  }

  .top-2px {
    top: 2px;
  }

  .flex {
    display: flex;
  }

  .table {
    display: table;
  }

  .contents {
    display: contents;
  }

  .hidden {
    display: none;
  }

  .min-h-15rem {
    min-height: 15rem;
  }

  .w-2em {
    width: 2em;
  }

  .data-cell {
    min-width: 7%;
    padding: 5px 5px;
  }

  .max-w-400px {
    max-width: 400px;
  }

  .max-w-95vw {
    max-width: 95vw;
  }

  .flex-1 {
    flex: 1 1 0%;
  }

  .transform {
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x))
      scaleY(var(--tw-scale-y));
  }

  .flex-wrap {
    flex-wrap: wrap;
  }

  .items-center {
    align-items: center;
  }

  .justify-center {
    justify-content: center;
  }

  .gap-1 {
    gap: 0.25rem;
  }

  .gap-2 {
    gap: 0.5rem;
  }

  .whitespace-nowrap {
    white-space: nowrap;
  }

  .rounded-full {
    border-radius: 9999px;
  }

  .rounded-sm {
    border-radius: 0.125rem;
  }

  .border {
    border-width: 1px;
  }

  .border-0 {
    border-width: 0px;
  }

  .border-b-2 {
    border-bottom-width: 2px;
  }

  .border-t-0 {
    border-top-width: 0px;
  }

  .border-var\\\\(--primary-color\\\\) {
    border-color: var(--primary-color);
  }

  .border-gray-400 {
    --tw-border-opacity: 1;
    border-color: rgb(156 163 175 / var(--tw-border-opacity));
  }

  .p-1 {
    padding: 0.25rem;
  }

  .p-2px {
    padding: 2px;
  }

  .pb-4 {
    padding-bottom: 1rem;
  }

  .pb-50px {
    padding-bottom: 50px;
  }

  .pt-5 {
    padding-top: 1.25rem;
  }

  .align-middle {
    vertical-align: middle;
  }

  .text-sm {
    font-size: 0.875rem;
    line-height: 1.25rem;
  }

  .uppercase {
    text-transform: uppercase;
  }

  @media print {
    .print\\\\:p-20px {
      padding: 20px;
    }
  }

  @media (min-width: 640px) {
    .sm\\\\:border-l-2 {
      border-left-width: 2px;
    }

    .sm\\\\:border-r-2 {
      border-right-width: 2px;
    }

    .sm\\\\:p-2 {
      padding: 0.5rem;
    }

    .sm\\\\:pb-50px {
      padding-bottom: 50px;
    }

    .sm\\\\:pt-5 {
      padding-top: 1.25rem;
    }

    @media print {
      .sm\\\\:print\\\\:p-20px {
        padding: 20px;
      }

      .sm\\\\:print\\\\:pb-50px {
        padding-bottom: 50px;
      }
    }
  }

  @media (min-width: 768px) {
    .md\\\\:p-20px {
      padding: 20px;
    }

    .md\\\\:pb-50px {
      padding-bottom: 50px;
    }

    .md\\\\:pt-5 {
      padding-top: 1.25rem;
    }

    @media print {
      .md\\\\:print\\\\:p-20px {
        padding: 20px;
      }

      .md\\\\:print\\\\:pb-50px {
        padding-bottom: 50px;
      }
    }
  }

  .split::after {
    content: ",";
    font-family: inherit;
  }

  .split:last-of-type::after {
    content: "";
  }

  .hide-if-empty:not(:has(div, span)) {
    display: none !important;
  }

  @media print {
    html {
      zoom: 0.7;
    }
  }

  .row-header {
    width: 65%;
  }

  .rules-block:not(:has(.rule)) {
    display: none !important;
  }

  .rules-list {
    padding: 8px;
    background-color: rgb(233, 234, 236);
    border: 2px solid gray;
    margin-bottom: 32px;

    > .rule:not(:last-child) {
      margin-bottom: 10px;
    }
  }

  .rule-name {
    white-space: nowrap;
    font-weight: 700;
    display: block;
  }

  .force-name {
    white-space: nowrap;
    font-weight: 800;
  }

  .force-catalogue {
    color: gray;
    font-weight: 500;
  }

  .nested {
    margin-left: 5px;
  }

  .model-name-options:not(:has(.model-name)) {
    padding-top: 1.2em;
  }

  .keywords {
    position: absolute;
    left: 0px;
    bottom: -16px;
    padding: 0px 4px 0px 42px;
    display: flex;
    justify-content: center;
    flex-direction: column;
    color: rgb(255, 255, 255);
    border-left: none;
    width: calc(100% - 0.9rem);
    min-height: 54px;
    background: url("data:image/bmp;base64,Qk22egAAAAAAADYAAAAoAAAAoAAAADEAAAABACAAAAAAAIB6AAAAAAAAAAAAAAAAAAAAAAAADgwC/w0LAP8LCQD/CggA/wsJAP8MCgD/DgwC/w8NAv8KCAD/CAYA/woIAP8ODAH/Dw0D/wsJAP8KCAD/DAoA/wgGAP8JBwD/DAoA/w8NAv8RDwT/Dw0C/woIAP8GBAD/DQsA/w8NAv8QDgP/DgwB/wwKAP8LCQD/DgwB/xEQAv8QEAD/Dw8A/xIRA/8ZGAr/GRcM/xEPBP8IBgD/BQMA/wUDAP8IBgD/DAoA/w4MAv8MCgD/CwkA/w0LAP8PDQL/CggA/wsJAP8LCQD/CwkA/woIAP8LCQD/DQsB/xAOA/8IBgD/CwkA/w8NAv8UEwX/FRMI/xUUBv8TEQb/EhED/xQUBP8WFgb/GBgI/xoaCv8ZGQn/FxcH/xQTBf8SEQP/CwoA/w0MAP8QDgP/ExEG/xUTCP8VEwj/FBII/xMRBv8UEgf/ExIE/xMSBP8TEgT/EhAF/xIQBf8SEAX/EQ8E/woIAP8JBwD/CAYA/wgGAP8IBgD/CAYA/wkHAP8KCAD/EQ8F/w0LAf8LCQD/DQsB/w4MAv8MCgD/DAoA/w0LAf8RDwX/DgwC/wsJAP8JBwD/CQcA/woIAP8KCAD/CQcA/wsJAP8NCwH/Dw0C/xAOA/8QDgP/EQ8E/xMRBv8VEwj/EhED/xIRA/8SEQP/EhED/xMSBP8TEgT/ExMD/xQUBP8VEwj/FRMI/xQSB/8TEQb/EhAF/xEPBP8QDgP/EA4D/w4MAf8ODAH/DQsA/w0LAP8NCwD/DAoA/wwKAP8MCgD/Dw0D/w8NA/8QDgP/EQ8E/xIQBf8TEQb/FBIH/xQSB/8MCwD/DQwA/w4NAP8PDgD/EA8B/w8OAP8PDwD/Dw8A/xMQCP8TEQf/Eg8H/xEPBf8RDgb/EQ8F/xMQCP8TEQf/DAkB/w0LAf8QDQX/FBII/xYTC/8WFAr/FRIK/xYUCv8RDwX/EA4D/w8NAv8QDgP/EhAF/xQSB/8WFAn/FhQJ/xIQBf8VEwj/FxUK/xYUCf8TEQb/ExEG/xUTCP8YFgv/GxoM/xkZCf8ZGAr/HRwO/x8dEv8aGA3/EA4E/wgGAP8LCQD/EA4E/xYUCv8XFQv/FRMJ/xIQBv8TEQf/FRMJ/w4LA/8PDAT/EA0F/xAOBP8QDQX/EhAG/xUSCv8XFQv/GRcN/xoYDf8bGQ//HBoP/xsZDv8ZFwz/FxUK/xYUCf8dHA7/Hh4O/yAgEP8hIRH/ISER/x8fD/8dHA7/GxoM/xcWCP8ZGAr/GhgN/xsZDv8aGA3/GRcM/xkXDf8ZFwz/GhgN/xoZC/8aGQv/GRgK/xkXDP8YFgv/GBYL/xgWC/8UEgj/FBII/xMRB/8TEQf/ExEH/xMRB/8UEgj/FBII/xEPBf8PDQP/EA4E/xQSCP8XFQv/FBII/xMRB/8TEQf/GhgO/xcVC/8UEgj/ExEH/xMRB/8TEQf/EhAG/xEPBf8RDwX/FRMJ/xcVC/8XFQr/FRMI/xUTCP8YFgv/GxkO/xYUCf8WFQf/FhUH/xcWCP8XFgj/GBcJ/xgXCf8YFwn/Hx0S/x8dEv8fHRL/HhwR/x0bEP8bGQ7/GhgN/xkXDP8XFQr/FxUK/xYUCf8VEwj/FRMI/xQSB/8UEgf/ExEG/xAOBP8RDwX/EhAG/xMRBv8VEwj/FhQJ/xcVCv8YFgv/FhQJ/xYVB/8YFwn/GRgK/xoZC/8aGQv/GRgK/xkYCv8QDAf/EA0F/xAMB/8QDQX/EAwH/xANBf8RDQj/Eg8H/wwIA/8PDAT/EQ0I/xEOBv8SDgn/Eg8H/xENCP8PDAT/EhAG/xIQBv8SEAb/EQ8F/xEPBf8RDwX/EQ8F/xIQBv8TEQf/FhQK/xgWDP8YFgz/FhQK/xUTCf8XFQv/GhgN/x0cDv8bGgz/GRcM/xkXDP8bGQ//GhgO/xIPB/8KBwD/DwwE/xMQCP8YFQ3/GBUN/xYTC/8TEQf/EhAG/xIQBv8MCQH/DgoF/w8LBv8PDAT/EAwH/xEOBv8UEAv/FxQM/yAdFf8eHBL/GxgQ/xgWDP8WFAr/FRMJ/xUTCf8WFAn/HBsN/xwcDP8dHA7/Hh0P/x4dD/8cGw3/GxoM/xoZC/8aGA3/GhgN/xkXDP8XFQr/FRMI/xYUCf8aGA3/HhwR/xcVCv8XFQr/FxUK/xYUCf8WFAr/FhQK/xUTCf8VEwn/EhAG/xMRB/8TEAj/ExAI/xMQCP8TEAj/ExAI/xIPB/8PDQP/DgwC/xMRB/8bGQ//HhwS/xwaEP8ZFw3/GBYM/xgWDP8WFAr/FBII/xMRB/8TEQf/ExEH/xIQBv8RDwX/EQ4G/xQSCP8WFAr/FRMJ/xEPBf8QDgT/EhAG/xUTCP8XFQr/FxUK/xgWC/8YFgv/GBYL/xkXDP8ZFwz/GRcM/xwaD/8dGxD/HRsQ/x0bEP8cGg//GhgN/xgWC/8XFQr/FRMI/xUTCP8UEgf/ExEG/xIQBf8RDwT/EQ8E/xAOA/8NCwH/DQsB/w4MAv8QDgT/EQ8F/xMRB/8UEgj/FRMI/xcVCv8YFgv/GRcM/xoYDf8bGQ7/HBoP/xwaD/8bGQ7/Eg4J/xIOCf8TDwr/Ew8K/xQQC/8VEQz/FhIN/xYSDf8WEg3/GBQP/xgUD/8UEAv/Eg4J/xENCP8OCgX/CQUA/xUSCv8aGA7/Hx0T/yAeFP8bGQ//FBII/w0LAf8KCAD/EA4E/xQSCP8XFQv/FxUL/xUTCf8UEgj/FhQK/xgWDP8fHRL/IB8R/x8dEv8cGg//HRsR/x4cEv8ZFg7/Eg8H/xANBf8QDQX/EQ4G/xIPB/8SDwf/EA0F/w4LA/8MCQH/Eg4J/xMPCv8UEAv/FBAL/xURDP8WEg3/GRUQ/xsXEv8ZFg7/FxQM/xMQCP8QDQX/Dw0D/xAOBP8TEQf/FRMI/x4dD/8eHg7/Hx4Q/x8eEP8eHQ//Hh0P/xwbDf8cGw3/GxkO/xsZDv8bGQ7/GBYL/xcVCv8aGA3/IR8U/ygmG/8aGA3/GRcM/xkXDP8ZFwz/GBYM/xgWDP8YFgz/GBYM/xIQBv8SEAb/ExAI/xQRCf8UEQn/ExAI/xIPB/8SDwf/Dw0D/w8NA/8UEgj/HBoQ/yAeFP8dGxH/GxkP/xoYDv8YFgz/FhQK/xUTCf8VEwn/FxUL/xcVC/8VEwn/FBII/xYTC/8XFAz/FxQM/xYUCv8UEgj/ExEH/xMRB/8UEgj/FxUL/xgWC/8YFgv/GBYL/xkXDP8ZFwz/GRcM/xoYDf8bGQ7/HBoP/x0bEP8eHBH/HhwR/xwaD/8bGQ7/GRcM/xcVCv8XFQr/FhQJ/xUTCP8UEgf/EhAF/xIQBf8RDwX/Eg8H/xMQCP8UEQn/FRMJ/xYUCv8XFQv/GBYM/xgWDP8SEAb/ExEG/xQSB/8WFAn/FxUK/xgWC/8YFgv/GBYL/wwHBP8NCAX/DwoH/xEMCf8TDgv/FA8M/xUQDf8VEA3/FRAN/xoVEv8ZFBH/FA8M/xINCv8TDgv/DwoH/wkFAP8PDAT/FhML/x4bE/8gHRX/GxgQ/xMQCP8MCQH/CAUA/woHAP8OCwP/Eg8H/xIPB/8RDgb/EA0F/xEOBv8TEQf/FxUK/x0bEP8fHRP/HRsR/xsYEP8cGRH/FxMO/xAMB/8UEAv/EQ0I/w4KBf8QDAf/FBAL/xYTC/8TEAj/DwwE/xENCP8TDwr/Ew8K/xMPCv8TDwr/FBAL/xcTDv8ZFRD/FxQM/xYTC/8UEQn/ExAI/xIPB/8TEAj/FRMJ/xYUCf8aGQv/GhkL/xoZC/8aGQv/GhgN/xkXDP8YFgv/GBYL/xcVCv8ZFwz/GhgN/xcVCv8VEwj/FhQJ/xwaD/8iIBX/FxUL/xcVC/8WFAr/FhQK/xUTCf8VEwn/FRIK/xUSCv8XFAz/GBUN/xkWDv8aFw//GhYR/xkVEP8YFA//FxQM/w4MAv8LCQD/DAoA/xAOBP8TEQf/EhAG/xEPBf8SEAb/FBII/xMRB/8TEQf/FBII/xYUCv8WFAr/FRMJ/xQSCP8SDwf/EQ4G/xANBf8RDgb/Eg8H/xMQCP8SDwf/EQ8F/xEPBf8RDwX/EhAG/xIQBv8SEAb/ExEH/xMRBv8TEQb/FhQJ/xgWC/8aGA3/HBoP/x0bEP8cGg//GhgN/xkXDP8XFQr/FhQJ/xUTCP8UEgf/EhAF/xEPBP8QDgP/EA4E/xEOBv8RDgb/Eg8H/xIPB/8TEAj/ExAI/xQRCf8UEgj/EhAG/xMRB/8VEwn/FxUL/xgWDP8ZFw3/GRcM/xkXDP8KBQL/DAcE/w4JBv8QCwj/Ew4L/xQPDP8VEA3/FRAN/xMOC/8ZFBH/GxYT/xcSD/8XEg//GxYT/xkUEf8TDwr/CwcC/xEOBv8YFQ3/GxgQ/xgVDf8VEgr/ExAI/xQRCf8QDQX/FBEJ/xgVDf8ZFg7/GBUN/xcUDP8YFQ3/GhcP/xAOBP8bGQ7/IR8V/x8dE/8cGRH/HBkR/xYSDf8OCgX/FBAL/w4KBf8KBgH/DAgD/xQQC/8YFA//FhML/xEOBv8SDgn/Ew8K/xQQC/8UEAv/Ew8K/xQQC/8WEg3/GBUN/xcUDP8WEwv/FhML/xUTCf8UEQn/ExEH/xEPBf8RDwT/GRcM/xkYCv8ZFwz/GBYL/xgWC/8YFgv/FxUK/xcVCv8YFgv/GxkO/x0bEP8aGA3/FBIH/xIQBf8UEgf/GBYL/xYUCv8WFAr/FhQK/xUTCf8VEwn/FRMJ/xQRCf8UEQn/Eg8H/xMQCP8UEQn/FRIK/xURDP8UEAv/Ew8K/xIPB/8XFAz/EQ8F/w0LAf8ODAL/Dw0D/w8NA/8RDwX/FBII/xQSCP8UEgj/FBII/xYUCv8YFgz/GRcN/xgWDP8XFQv/EAwH/w4KBf8NCgL/DwwE/xMQCP8WEwv/FBEJ/xIPB/8VEwn/FRMJ/xUTCf8VEwn/FhQK/xYUCv8XFQr/FxUK/xcVCv8ZFwz/HBoP/x8dEv8gHhP/Hx0S/x4cEf8cGg//GhgN/xoYDf8ZFwz/FxUK/xYUCf8UEgf/ExEG/xMRB/8QDQX/EAwH/xANBf8QDQX/EA0F/xANBf8QDQX/EA0F/xAOBP8SEAb/ExEH/xUTCf8XFQv/GBYM/xgWC/8YFgv/DwsG/w8LBv8QDAf/EAwH/xENCP8SDgn/Ew8K/xMPCv8SDgn/GhYR/xsXEv8UEAv/Eg4J/xcTDv8UEAv/CwcC/wwIA/8LBwL/DQkE/xMPCv8ZFRD/GxcS/xYSDf8RDQj/EQ0I/xIOCf8TDwr/Ew8K/xMPCv8TDwr/Eg4J/xEOBv8WFAr/GBYM/xsZD/8eHBL/HhsT/xkVEP8SDgn/DAgD/woFAv8RDAn/DAcE/wYBAP8OCgX/FBAL/xIOCf8RDQj/DwwE/xQRCf8ZFg7/GxgQ/xkWDv8XFAz/GBUN/xkXDf8TEQf/FBII/xQSCP8VEwj/GBYM/xsZDv8YFgv/EQ8E/x4cEf8bGQ7/GRcN/xoYDf8ZFwz/FhQJ/xYUCf8ZFwz/HBoP/xwaD/8cGg//GxkO/xgWC/8VEwj/EhAF/xAOA/8UEgj/FhQK/xkXDf8aGA7/GRcN/xkXDf8aFw//GxgQ/xcUDP8YFQ3/GRYO/xkWDv8ZFRD/FxMO/xURDP8UEQn/EQ4G/xEPBf8RDwX/EQ8F/xEPBf8RDwX/EQ8F/xEPBf8bGQ//GRcN/xMRB/8ODAL/EA4E/xYUCv8ZFw3/GBYM/xQQC/8TDwr/Eg4J/xENCP8QDAf/EAwH/xANBf8QDQX/Eg8H/xUSCv8YFgz/GBYM/xYUCv8UEgj/ExEH/xMRB/8aGA3/GRcM/xgWC/8XFQr/GRcM/xwaD/8fHRL/IR8U/xwaD/8cGg//GxkO/xsZDv8bGQ7/GhgN/xoYDf8aGA7/FBEJ/xMPCv8RDQj/DwsG/w0JBP8NCQT/EA0F/xMQCP8OCwP/EA0F/xQSCP8XFQv/GBYM/xgWDP8XFQv/FhQK/w8LBv8PCwb/EAwH/xAMB/8RDQj/Eg4J/xMPCv8TDwr/EQ0I/xgUD/8ZFRD/Ew8K/xIOCf8XEw7/FREM/wwIA/8NCQT/DAgD/w0JBP8SDgn/GBQP/xkVEP8VEQz/EAwH/xAMB/8QDAf/EQ0I/xIOCf8TDwr/FREM/xcTDv8YFQ3/ExEH/xUTCf8ZFw3/HBoQ/x0aEv8ZFRD/Ew8K/w4KBf8MBwT/Eg0K/w4JBv8IAwD/DwsG/xQQC/8RDQj/EQ0I/w8MBP8SDwf/FRIK/xgVDf8YFQ3/GBYM/xgWDP8ZFw3/FxUL/xcVCv8WFAn/FRMI/xgWC/8bGQ7/GBYL/xMRBv8WFAr/FRMJ/xYUCv8YFgz/FhQJ/xMRBv8TEQb/FhQJ/xoYDf8aGA3/GxkO/xsZDv8bGQ7/GRcM/xgWC/8WFAn/FRMJ/xcVC/8ZFw3/GhgO/xkXDf8YFgz/GBUN/xkWDv8XFAz/FxQM/xgVDf8ZFg7/GRUQ/xgUD/8WEg3/FRIK/xUTCf8VEwn/FRMJ/xQSCP8UEgj/ExEH/xMRB/8SEAb/FRMJ/xcVC/8WFAr/EhAG/xIQBv8VEwn/FxUL/xUTCf8WEg3/FhIN/xURDP8UEAv/FBAL/xMPCv8TEAj/FBEJ/xQRCf8VEgr/FxUL/xcVC/8VEwn/FBII/xQSCP8VEwn/GBYL/xcVCv8WFAn/FRMI/xcVCv8aGA3/HRsQ/x8dEv8bGQ7/GxkO/xoYDf8aGA3/GRcM/xkXDP8YFgv/GBYM/xYTC/8WEg3/FhIN/xURDP8TDwr/Eg4J/xQRCf8WEwv/EQ4G/xMQCP8WFAr/GRcN/xoYDv8aGA7/GRcN/xgWDP8PDAT/DwwE/xANBf8QDQX/EQ4G/xIPB/8TEAj/ExAI/w8MBP8WEwv/FxQM/xMQCP8TEAj/FxQM/xUSCv8PDAT/DgoF/w4KBf8OCgX/Eg4J/xYSDf8XEw7/Ew8K/w4KBf8TDwr/Eg4J/xIOCf8SDgn/Ew8K/xURDP8XEw7/GRYO/xAOBP8SEAX/FhQK/xoYDv8cGRH/GhcP/xURDP8RDQj/EAsI/xUQDf8QDAf/DAgD/xENCP8UEAv/EAwH/xENCP8RDgb/EA4E/xEPBf8TEQf/FhQK/xkXDf8ZFw3/GRcM/xsZDv8bGQ7/GRcM/xUUBv8WFQf/GRgK/xgXCf8VEwj/ExEH/xUSCv8aGA7/HhwS/xwaEP8XFQv/GBYM/xwaEP8YFgv/GRcM/xoYDf8cGg//HRsQ/x0bEP8dGxD/HRsQ/xcVCv8ZFwz/GxkO/xoYDf8ZFw3/FxUL/xcVC/8YFgz/FhQK/xcVC/8YFQ3/GRYO/xkWDv8YFQ3/GBUN/xcUDP8aGA7/GRcN/xgWDP8XFQv/FhQK/xUTCf8UEgj/FBII/w4MAv8VEwn/GRcN/xcVC/8UEgj/FBII/xQSCP8SEAb/FxMO/xYSDf8WEg3/FhIN/xUSCv8VEgr/FRIK/xUSCv8WEwv/FhML/xUTCf8VEwn/FBII/xUTCf8WFAr/FxUL/xUTCP8VEwj/FBIH/xQSB/8VEwj/FxUK/xoYDf8bGQ7/GxkO/xsZDv8aGA3/GRcM/xgWC/8XFQr/FhQJ/xYUCv8SDwf/Ew8K/xMPCv8TDwr/EQ4G/xANBf8RDgb/ExAI/xIPB/8UEQn/FhQK/xkXDf8aGA7/GhgO/xkXDf8YFgz/DwwE/w8MBP8QDQX/EA0F/xEOBv8SDwf/ExAI/xMQCP8QDQX/FBEJ/xYTC/8VEgr/FRIK/xgVDf8XFAz/ExAI/xAMB/8PCwb/EAwH/xIOCf8UEAv/FBAL/xENCP8OCgX/FhIN/xURDP8VEQz/FBAL/xMPCv8SDgn/EQ0I/xEOBv8QDgT/EhAF/xUTCf8ZFw3/HBkR/xsYEP8YFA//FhIN/xQPDP8XEg//Eg4J/w8LBv8UEAv/FBAL/xAMB/8RDgb/ExEH/xEPBf8PDQP/EhAG/xcVC/8bGQ//GxkO/xkXDP8dGxD/HRsQ/xoZC/8VFAb/FBMF/xcWCP8XFgj/FRMI/w8NA/8UEQn/GxkP/yEfFf8fHRP/GxkP/xsZD/8fHRP/GBYL/xkXDP8aGA3/GxkO/xwaD/8dGxD/HhwR/x4cEf8bGQ7/HBoP/x0bEP8dGxD/GhgO/xgWDP8YFgz/GBYM/xYUCv8WFAr/FxQM/xgVDf8ZFg7/GRYO/xkWDv8ZFg7/HBoQ/xsZD/8aGA7/GBYM/xcVC/8VEwn/FBII/xQSCP8ODAL/FhQK/xsZD/8ZFw3/FBII/xMRB/8UEgj/FBII/xQRCf8UEAv/FBAL/xURDP8VEgr/FBEJ/xMQCP8TEAj/GBUN/xYTC/8UEgj/ExEH/xQSCP8WFAr/FxUL/xgWDP8UEgf/FBIH/xQSB/8UEgf/FRMI/xYUCf8YFgv/GRcM/xwaD/8cGg//GxkO/xoYDf8YFgv/FxUK/xYUCf8WFAr/Eg8H/xIOCf8RDQj/DwsG/w4LA/8OCwP/EQ4G/xMQCP8RDgb/Eg8H/xQSCP8WFAr/FxUL/xcVC/8WFAr/FhQK/w8LBv8PCwb/EAwH/xAMB/8RDQj/Eg4J/xMPCv8TDwr/EQ0I/xQQC/8XEw7/FxMO/xgUD/8ZFRD/GBQP/xYSDf8RDgb/EQ4G/xEOBv8TEAj/ExAI/xMQCP8RDgb/DwwE/xEOBv8SDwf/ExAI/xQRCf8TEAj/EQ4G/w8MBP8NCgL/FBII/xQSB/8WFAr/GRcN/xwZEf8dGhL/GxcS/xkVEP8WEg3/FxMO/xMPCv8SDgn/FxQM/xQRCf8PDAT/Eg8H/xYUCv8TEQf/EQ8F/xMRB/8YFgz/HBoQ/xwaD/8aGA3/HBoP/x0bEP8aGA3/FRMI/xMSBP8UEwX/FRQG/xQSB/8IBgD/DAkB/xQRCf8cGRH/HBkR/xgVDf8XFQv/GhgO/xoYDv8aGA7/GhgN/xoYDf8aGA3/GhgN/xsaDP8bGgz/Hh0P/x8eEP8gHxH/Hx4Q/xwaD/8aGA3/GRcM/xkXDP8XFQv/FxUL/xcVC/8YFgz/GBYM/xkXDf8aGA7/GxkP/xsZD/8aGA7/GRcN/xcVC/8WFAr/FRMJ/xMRB/8TEQf/EhAG/xgWDP8bGQ//FxUL/xIQBv8TEQf/FxUL/xgWDP8TEAj/FBEJ/xUSCv8WEwv/FhML/xUSCv8UEgj/ExEH/xgWDP8WFAr/ExEH/xMRB/8VEwj/GBYL/xkXDP8YFgv/FRMI/xUTCP8VEwj/FRMI/xYUCf8XFQr/GBYL/xgWC/8dGxD/HRsQ/xwaD/8bGQ7/GhgN/xkXDP8YFgv/GBYM/xsYEP8ZFg7/FhML/xIPB/8QDQX/EQ4G/xUTCf8ZFw3/EhAG/xMRB/8UEgj/FRMJ/xYUCf8WFAn/FhQJ/xYUCf8PCwb/DwsG/xAMB/8QDAf/EQ0I/xIOCf8TDwr/Ew8K/xMPCv8UEAv/FhIN/xgUD/8ZFRD/GBQP/xcTDv8WEg3/EQ4G/xIPB/8TEAj/ExAI/xMQCP8TEAj/Eg8H/xIPB/8KBwD/DAkB/w4LA/8RDgb/ExAI/xQRCf8UEQn/FBII/xgWDP8XFQr/GBYM/xkXDf8bGBD/HBkR/xoWEf8ZFRD/FhIN/xYSDf8TDwr/FBAL/xkWDv8UEQn/DwwE/xQRCf8VEwn/FBII/xQSCP8WFAr/GRcN/xoYDv8aGA3/GRcM/xkXDP8cGg//GxkO/xYUCf8TEgT/FBMF/xUUBv8UEgf/CgcA/wwJAf8RDgb/GhcP/x0aEv8bGBD/GRcN/xkXDf8bGQ//GhgO/xkXDP8YFgv/GBYL/xgWC/8ZGAr/GRgK/x4dD/8fHhD/IB8R/yAfEf8dGxD/GxkO/xoYDf8bGQ7/GRcN/xkXDf8YFgz/GBYM/xgWDP8ZFw3/GhgO/xsZD/8YFgz/GBYM/xcVC/8WFAr/FRMJ/xQSCP8TEQf/ExEH/xUTCf8YFgz/GBYM/xMRB/8QDgT/ExEH/xcVC/8ZFw3/FBEJ/xUSCv8XFAz/GRYO/xkWDv8YFQ3/FxUL/xYUCv8YFgz/FRMJ/xIQBv8UEgj/GBYL/xoYDf8ZFwz/FxUK/xUTCP8VEwj/FhQJ/xYUCf8XFQr/FxUK/xcVCv8XFQr/HBoP/xwaD/8bGQ7/GxkO/xsZDv8bGQ7/GhgN/xoYDf8bGBD/GRYO/xYTC/8SDwf/DwwE/w8MBP8SEAb/FBII/xYUCv8WFAr/FxUL/xcVC/8XFQr/GBYL/xgWC/8YFgv/DwsG/w8LBv8QDAf/EAwH/xENCP8SDgn/Ew8K/xMPCv8TDwr/Eg4J/xQQC/8XEw7/FxMO/xURDP8TDwr/FBAL/xEOBv8SDwf/FBEJ/xQRCf8UEQn/ExAI/xQRCf8VEgr/DQoC/w0KAv8MCQH/DQoC/xANBf8UEQn/GBUN/xsZD/8bGQ//GhgN/xgWC/8YFgv/GRcN/xkXDf8YFQ3/FhML/xURDP8VEQz/Eg4J/xURDP8bGBD/FBEJ/w8MBP8VEgr/Eg8H/xUSCv8YFQ3/GRYO/xgWDP8WFAr/FhQK/xYUCv8XFQv/HBoQ/x4cEf8aGA3/FhQJ/xYUCf8WFAn/FRMI/xANBf8NCQT/EA0F/xkWDv8fHBT/HxwU/xwaEP8aGA7/GxkP/xoYDv8YFgv/GBYL/xgWC/8ZFwz/GhkL/xsaDP8cGw3/HRwO/x8eEP8eHQ//HBsN/xoZC/8aGA3/GhgN/xsZDv8aGA3/GRcM/xgWC/8XFQv/GBYM/xkXDf8aGA7/FhQK/xYUCv8WFAr/FRMJ/xUTCf8UEgj/FBII/xQSCP8VEwn/FhQK/xQSCP8QDgT/EA4E/xQSCP8WFAr/FRMJ/xIPB/8UEQn/FhML/xgVDf8ZFw3/GBYM/xYUCv8VEwn/FhQK/xQSCP8SEAX/FRMI/xoYDf8cGg//GRcM/xYUCf8UEgf/FRMI/xUTCP8WFAn/FhQJ/xYUCf8WFAn/FhQJ/xkXDP8ZFwz/GRcM/xoYDf8aGA3/GxkO/xsZDv8bGQ7/FhML/xcUDP8XFAz/FBEJ/xAOBP8NCwH/CwkA/wsJAP8XFQv/FxUL/xcVCv8XFQr/FxUK/xcVCv8YFgv/GBYL/w8LBv8PCwb/EAwH/xAMB/8RDQj/Eg4J/xMPCv8TDwr/Eg4J/xENCP8SDgn/FhIN/xYTC/8SDwf/EA0F/xIPB/8RDgb/ExAI/xUSCv8VEgr/FBEJ/xQRCf8WEwv/GBUN/xYTC/8TEAj/DQoC/woHAP8MCQH/EQ4G/xgVDf8dGxH/HRsR/xsZDv8YFgz/FxUL/xcVC/8WFAr/FRIK/xQRCf8UEAv/Ew8K/xENCP8WEg3/HBkR/xUSCv8PDAT/FhML/xAOBP8VEwn/GRcN/xoYDv8WFAr/ExEH/xMRB/8UEgj/FhML/xwaEP8fHRP/HBoP/xkXDP8YFgv/GBYL/xYUCf8OCwP/CQUA/wgFAP8SDwf/GxgQ/xwZEf8XFQv/FBII/xkXDf8ZFw3/GBYL/xgWC/8YFgv/GhgN/xwbDf8eHQ//GRgK/xsaDP8dHA7/HBsN/xsaDP8ZGAr/GRcM/xoYDf8dGxD/HBoP/xoYDf8YFgv/FxUL/xgWDP8YFgz/GRcN/xYUCv8WFAr/FhQK/xUTCf8VEwn/FRMJ/xUTCf8VEwn/EhAG/xMRB/8RDwX/Dw0D/xAOBP8UEgj/ExEH/xANBf8PDAT/EQ4G/xQRCf8WEwv/FhQK/xUTCf8UEgj/EhAG/xUTCf8TEQf/ExEG/xYUCf8cGg//HRsQ/xkXDP8UEgf/ExEG/xQSB/8VEwn/FRMI/xYUCv8VEwj/FRMI/xQSB/8WFAn/FxUK/xcVCv8YFgv/GRcM/xoYDf8bGQ7/GxkO/xcVC/8bGQ//HhwS/x0bEf8YFgz/EhAG/wwKAP8JBwD/FRMJ/xUTCf8UEgj/FBII/xQSCP8VEwn/FRMJ/xYUCv8WEg3/FhIN/xURDP8VEQz/FA8M/xMOC/8TDgv/Ew4L/xMPCv8TDwr/ExAI/xoXD/8dGxH/ExEH/xEPBf8dGxH/Eg8H/xQQC/8VEgr/ExAI/xEOBv8QDQX/ExAI/xYTC/8ZFw3/EhAG/xAOBP8TEQf/FBII/xMRB/8XFQv/Hx0T/xkXDf8VEwn/FRIK/xoXD/8dGhL/GxgQ/xcUDP8WEwv/FBEJ/xUSCv8WEwv/FRIK/xMQCP8RDgb/EQ4G/xIQBv8TEQb/FxUK/xoYDf8ZFw3/FBII/w8NA/8OCwP/DgsD/xENCP8dGhL/IR8V/xoYDv8XFQr/GxkO/xoZC/8TEQb/EA0F/w4LA/8SDwf/ExAI/xIQBv8cGhD/JCIY/yEfFf8bGQ//GxkP/xsZDv8bGQ7/GhgN/xgWC/8XFQr/FhQJ/xgWC/8aGA3/HRsQ/x8dEv8gHhP/Hx0S/x0bEP8cGg//GxkO/xsZDv8aGA3/GRcM/xgWC/8XFQr/FhQJ/xYUCf8XFQr/FxUK/xQSB/8PDQL/EhAF/xkXDP8YFgz/EQ8F/xQSCP8RDwX/DwwE/xANBf8QDQX/EA0F/xUSCv8cGRH/EQ4G/w8MBP8MCQH/DgsD/xYUCv8dGxH/GhgO/xIQBv8GBAD/EA4E/xQSB/8RDwT/FRMI/x4cEf8fHRL/FxUK/xgWDP8XFQv/FhML/xUTCf8UEQn/FBII/xQSCP8UEgj/FxUL/xcVC/8XFQr/GBYL/xgWC/8YFgv/GRcM/xkXDP8YFwn/GBgI/xcWCP8XFgj/GhgN/xoYDf8SEAb/CAYA/w4LA/8PDAT/Eg8H/xMQCP8UEQn/FBEJ/xMQCP8SDwf/FREM/xURDP8UEAv/FBAL/xMOC/8TDgv/Eg0K/xINCv8RDQj/Eg4J/xIPB/8ZFg7/HBoQ/xMRBv8PDQL/GRcN/xIPB/8UEAv/FRIK/xMQCP8RDgb/EA0F/xMQCP8WEwv/GxkP/xYUCv8TEQf/FRMJ/xQSCP8QDgT/EA4D/xQSB/8aFw//FxQM/xcUDP8bGBD/GxgQ/xcUDP8UEQn/FBEJ/xQRCf8VEgr/FhML/xUSCv8TEAj/EQ4G/xEOBv8SEAb/EhAF/xYVB/8aGA3/GRcM/xUTCf8QDgT/DQoC/wwIA/8SDgn/GxgQ/x4cEv8YFgz/GBYL/x0bEP8dHA7/FxUK/xoYDv8VEgr/FBEJ/xIPB/8QDgT/GBYM/x4cEv8ZFw3/GhgO/xoYDv8aGA3/GhgN/xkXDP8YFgv/FxUK/xcVCv8aGA3/GxkO/x4cEf8fHRL/IB4T/x4cEf8cGg//GxkO/xsZDv8bGQ7/GhgN/xkXDP8YFgv/FxUK/xcVCv8WFAn/GBcJ/xoZC/8XFQr/EhAF/xMRBv8ZFwz/GRcN/xQSCP8TEQf/EA4E/w8MBP8QDQX/EA0F/w8MBP8TDwr/GRUQ/xcUDP8WEwv/Eg8H/xEOBv8WFAr/GxkP/xkXDf8UEgj/FRMJ/xsZD/8bGQ7/FBIH/xQSB/8aGA3/GRcM/xIQBf8YFQ3/FxQM/xYTC/8VEgr/FBEJ/xQRCf8UEgj/FBII/xYUCv8WFAr/FxUK/xcVCv8YFgv/GRcM/xkXDP8ZGAr/GxsL/xsbCf8ZGQn/GBgI/xoYDf8bGQ7/FBII/wwKAP8NCgL/DwwE/xAMB/8SDgn/Ew8K/xMPCv8SDgn/Eg8H/xQQC/8TDwr/Ew8K/xMPCv8SDgn/Eg4J/xINCv8SDQr/EAwH/xENCP8SDwf/FxQM/xwaEP8SEAb/DAoA/xQSCP8SDwf/FBAL/xUSCv8TEAj/EQ4G/xANBf8TEAj/FhML/xkXDf8WFAr/FRMJ/xcVC/8VEwn/Dw0D/w0LAP8PDQL/GRYO/xgVDf8aFw//HBkR/xkWDv8TEAj/Eg8H/xQRCf8VEgr/FhML/xYTC/8VEgr/ExAI/xIPB/8SDwf/ExEH/xEPBP8VFAb/GhgN/xsZDv8XFQv/EQ8F/wwJAf8JBgD/FBEJ/xkWDv8aGA7/FxUL/xgWC/8fHRL/IB8R/xsZDv8hHxX/GRYO/xQRCf8QDQX/DgwC/xcVC/8dGxH/GBYM/xkXDf8ZFw3/GRcM/xkXDP8ZFwz/GRcM/xkXDP8ZFwz/GxkO/xwaD/8eHBH/Hx0S/x4cEf8dGxD/GxkO/xoYDf8bGQ7/GxkO/xoYDf8aGA3/GRcM/xgWC/8XFQr/FxUK/xgXCf8cGw3/GxkO/xcVCv8VEwj/GBYL/xkXDf8YFgz/EhAG/xAOBP8QDQX/EQ4G/w8MBP8NCgL/DgsD/xMQCP8aFw//GxgQ/xoXD/8WEwv/FRMJ/xgWDP8XFQv/FRMJ/xUTCf8ZFw3/GRcM/xQSB/8WFAn/HhwR/yAeE/8dGxD/GBUN/xcUDP8WEwv/FRIK/xQSCP8UEgj/FBII/xQSCP8VEwn/FRMJ/xYUCf8XFQr/GBYL/xkXDP8aGA3/GhkL/x0dDf8dHQv/GhoK/xgYCP8aGA3/GxkO/xcVC/8QDgT/DQoC/w4LA/8QDAf/EQ0I/xIPB/8SDwf/Eg8H/xIPB/8TDwr/Ew8K/xMPCv8TDwr/Ew8K/xMPCv8TDgv/Ew4L/w8LBv8SDgn/Eg8H/xYTC/8bGQ//FBII/w0LAP8RDwX/Eg8H/xQQC/8VEgr/ExAI/xEOBv8QDQX/ExAI/xYTC/8YFgz/FxUL/xYUCv8VEwn/FRMJ/xMRB/8TEQb/FBIH/xUSCv8WEwv/GRYO/xsYEP8XFAz/Eg8H/xIPB/8WEwv/FhML/xcUDP8WEwv/FRIK/xMQCP8SDwf/ExAI/xQSCP8SEAX/FRQG/xoYDf8cGg//GRcN/xIQBv8LCAD/BwQA/xgVDf8aFw//GRcN/xYUCv8YFgv/HhwR/x8eEP8bGQ7/IB4U/xcUDP8RDgb/DgsD/w8NA/8bGQ//IyEX/x8dE/8ZFw3/GRcN/xgWC/8YFgv/GRcM/xkXDP8aGA3/GhgN/x0bEP8dGxD/HhwR/x4cEf8dGxD/HBoP/xoYDf8ZFwz/GxkO/xsZDv8aGA3/GhgN/xkXDP8ZFwz/GBYL/xgWC/8YFwn/HBsN/x0bEP8aGA3/FhQJ/xYUCf8YFgz/GRcN/xUTCf8TEQf/ExAI/xMQCP8PDAT/CgcA/wkGAP8MCQH/FBEJ/xkWDv8cGRH/GRYO/xYUCv8VEwn/FRMJ/xMRB/8QDgT/ExEH/xQSB/8SEAX/FxUK/yEfFP8oJhv/KCYb/xgVDf8XFAz/FhML/xUSCv8UEgj/FBII/xQSCP8UEgj/FBII/xQSCP8VEwj/FhQJ/xgWC/8ZFwz/GhgN/xoZC/8dHQ3/HR0L/xsbC/8XFgj/GBYL/xoYDf8YFgz/ExEH/w8MBP8QDQX/EQ0I/xIOCf8TEAj/ExAI/xQRCf8UEQn/ExAI/xMQCP8TDwr/Ew8K/xQQC/8UEAv/FBAL/xQQC/8QDAf/Ew8K/xEOBv8UEQn/GxkP/xcVC/8PDQL/EQ8F/xIPB/8UEAv/FRIK/xMQCP8RDgb/EA0F/xMQCP8WEwv/HhwS/xwaEP8ZFw3/FRMJ/xMRB/8VEwn/GBYL/xgWC/8QDQX/Eg8H/xYTC/8ZFg7/FxQM/xIPB/8UEQn/GBUN/xcUDP8XFAz/FxQM/xQRCf8SDwf/Eg8H/xMQCP8VEwn/FBIH/xcVCv8aGA3/HBoP/xoYDv8UEgj/DAkB/wYDAP8aFw//GxgQ/xsZD/8YFgz/GBYL/xoYDf8bGQ7/GhgN/x8dE/8XFAz/Eg8H/w4LA/8PDQP/GxkP/yYkGv8jIRf/GxkP/xoYDv8ZFwz/GBYL/xkXDP8aGA3/GxkO/xwaD/8dGxD/HRsQ/x0bEP8dGxD/HBoP/xsZDv8aGA3/GRcM/xsZDv8bGQ7/GhgN/xoYDf8aGA3/GhgN/xkXDP8ZFwz/GBYL/xoYDf8cGg//GxkO/xcVCv8UEgf/FRMI/xgWC/8aGA7/GBYM/xYUCv8VEwn/EA4E/wkHAP8HBAD/CQYA/wkGAP8TEAj/GhcP/xoXD/8XFQv/FRMJ/xMRB/8QDgT/GBYM/xcVC/8VEwj/ExEG/xUTCP8aGA3/Hx0S/yEfFP8YFQ3/FxQM/xYUCv8VEwn/FBII/xQSCP8UEgj/FBII/xQSB/8UEgf/FRMI/xYUCf8XFQr/GBYL/xkXDP8ZGAr/GhoK/xsbC/8aGQv/FxYI/xYUCf8YFgv/FxUL/xMRB/8SDwf/Eg8H/xMQCP8TEAj/FBEJ/xUSCv8WEwv/FxQM/xIPB/8SDwf/Eg4J/xIOCf8TDwr/Ew8K/xMPCv8UEAv/EAwH/xMPCv8PDAT/EQ4G/xkXDf8YFgz/EhAG/xMRB/8SDwf/FBAL/xUSCv8TEAj/EQ4G/xANBf8TEAj/FhML/yUjGf8kIhj/HhwS/xYUCv8TEQf/FhQK/xgWC/8XFQr/DgsD/w8MBP8SDwf/FxQM/xcUDP8UEQn/FBEJ/xcUDP8YFQ3/GBUN/xcUDP8UEQn/Eg8H/xIPB/8UEQn/FhQK/xgWDP8ZFwz/GhgN/xwaD/8bGQ//FRMJ/w0KAv8HBAD/GBUN/xsYEP8cGhD/GxkP/xcVCv8VEwj/FxUK/xoYDf8gHRX/GhcP/xYTC/8RDgb/DAoA/xUTCf8gHhT/Hx0T/x4cEv8cGhD/GxkO/xkXDP8ZFwz/GhgN/xwaD/8dGxD/HBoP/xwaD/8cGg//HBoP/xsZDv8bGQ7/GxkO/xsZDv8aGA3/GhgN/xoYDf8aGA3/GhgN/xoYDf8aGA3/GhgN/xoYDf8YFgv/GRcM/xsZDv8YFgv/ExEG/xMRBv8WFAn/HRsR/xoYDv8YFgz/FhQK/xEPBf8MCgD/DAkB/w8MBP8GAwD/DwwE/xgVDf8ZFg7/FxUL/xYUCv8TEQf/EA4E/xoYDv8YFgz/FRMI/xMRBv8TEQb/FhQJ/xkXDP8cGg//GBYM/xcUDP8WFAr/FRMJ/xQSCP8UEgj/FBII/xQSCP8VEwj/FRMI/xYUCf8WFAn/FhQJ/xcVCv8XFQr/FxYI/xYWBv8ZGQn/GhkL/xcWCP8WFAn/FxUK/xYUCv8SEAb/FBEJ/xQRCf8UEQn/FBEJ/xUSCv8WEwv/GBUN/xkWDv8PDAT/DwwE/xANBf8QDQX/EQ0I/xENCP8SDgn/Eg4J/w4KBf8RDQj/DAkB/wsIAP8VEgr/GBYM/xQSCP8UEgj/Eg8H/xQQC/8VEgr/ExAI/xEOBv8QDQX/ExAI/xYTC/8iIBb/JCIY/yAeFP8YFgz/FhQK/xkXDf8ZFwz/FhQJ/xEOBv8PDAT/EA0F/xUSCv8XFAz/FBEJ/xIPB/8TEAj/GRYO/xgVDf8XFAz/FBEJ/xIPB/8SDwf/FBEJ/xcVC/8cGhD/GxkO/xoYDv8bGQ//GhgO/xYUCv8PDQP/CQcA/xEPBf8XFQv/HRsR/x4cEv8XFQv/EhAG/xUTCP8cGg//HRoS/xoXD/8ZFg7/EQ4G/wgGAP8ODAL/GRcN/xoYDv8hHxX/Hx0T/x0bEP8aGA3/GhgN/xsZDv8cGg//HRsQ/xsZDv8bGQ7/GhgN/xoYDf8bGQ7/GxkO/xwaD/8cGg//GhgN/xoYDf8aGA3/GxkO/xsZDv8bGQ7/GxkO/xsZDv8dGxD/GBYL/xcVCv8bGQ7/GxkO/xUTCP8SEAX/FBIH/xwaD/8ZFwz/FxUK/xYUCf8UEgj/EhAG/xUTCf8aGA7/DQoC/xMQCP8XFAz/FxQM/xYUCv8YFgz/FhQK/xQSCP8WFAr/FBII/xMRBv8UEgf/FRMI/xYUCf8aGA3/HRsQ/xgWDP8XFQv/FhQK/xUTCf8UEgj/FBII/xQSB/8UEgf/FxUK/xcVCv8XFQr/FhQJ/xYVB/8VFAb/FRQG/xUUBv8UFAT/GRkJ/xsaDP8ZGAr/GBYL/xcVCv8VEwn/EhAG/xQRCf8UEQn/ExAI/xMQCP8UEQn/FhML/xcVC/8ZFw3/DAkB/w0KAv8NCgL/DgsD/w4KBf8PCwb/EAwH/xAMB/8NCQT/DwsG/wkGAP8HBAD/Eg8H/xgVDf8VEwn/FBEJ/xIOCf8UEAv/FRIK/xMQCP8RDgb/EA0F/xMQCP8WEwv/GRcN/x4cEv8fHRP/GhgO/xkXDf8eHBL/HRsQ/xgWC/8UEQn/EA0F/w8MBP8UEQn/FxQM/xQRCf8QDQX/DwwE/xkWDv8ZFg7/FxQM/xQRCf8SDwf/Eg8H/xUSCv8XFAz/Hx0T/x0bEP8bGQ//GhgO/xoYDv8XFQv/EA4E/wsJAP8LCQD/ExEH/x0bEf8fHRP/FxUL/xEPBf8WFAn/Hx0T/xYTC/8WEwv/GBUN/xANBf8FAwD/CwkA/xcVC/8aGA7/IyEX/yEfFf8eHBH/GxkO/xoYDf8bGQ7/HBoP/x0bEP8aGA3/GhgN/xoYDf8aGA3/GxkO/xwaD/8dGxD/HhwR/xoYDf8aGA3/GhgN/xsZDv8bGQ7/GxkO/xsZDv8bGQ7/Hx0S/xgWC/8WFAn/HBoP/x4cEf8XFQr/ExEG/xMRBv8ZFwz/FhQJ/xUTCP8WFAn/FhQJ/xcVCv8dGxH/IyEX/xYTC/8YFQ3/GBUN/xUSCv8WFAr/GRcN/xkXDf8XFQv/GBYM/xUTCf8UEgf/FhQJ/xYUCf8VEwj/FxUK/xoYDf8YFgz/FxUL/xYUCv8VEwn/FBII/xQSCP8UEgf/FBIH/xgWC/8YFgv/FxUK/xYUCf8VFAb/FBMF/xQTBf8TEgT/EhIC/xkZCf8dHA7/GxoM/xkXDP8YFgv/FhQK/xIQBv8UEQn/ExAI/xIPB/8SDwf/ExAI/xQSCP8XFQv/GBYM/xoYDv8VEwn/DQoC/wgFAP8LCAD/EQ4G/xAMB/8MCAP/EQ0I/xQQC/8TDwr/EQ0I/xUSCv8bGBD/GRYO/xEOBv8WEg3/GRUQ/xYTC/8QDQX/DwwE/xQRCf8SDwf/DAkB/w8NA/8XFQv/GhgO/xsZD/8fHRP/GhgO/xQSB/8XFQr/GhcP/xIPB/8PDAT/FBEJ/xgVDf8VEgr/FRIK/xkWDv8TEAj/FhML/xgVDf8YFQ3/FRIK/xUSCv8XFAz/GhcP/xsZD/8bGQ//HBoQ/xsZD/8ZFw3/FxUL/xQSB/8TEQb/HBoP/xkXDP8ZFw3/GxkP/xsZD/8YFgz/GBYM/xoYDv8WEwv/FxQM/xUSCv8QDQX/CggA/wsJAP8RDwX/GBYM/yEfFf8kIhj/JiQZ/yMhFv8dGxD/GhgN/xwaD/8fHRL/IB4T/x8dEv8eHBH/HRsQ/xwaD/8bGQ7/GhgN/xoYDf8eHBH/HRsQ/xsZDv8aGA3/GRcM/xgWC/8YFgv/GBYL/xsZDv8aGA3/GhgN/xsZDv8bGQ7/GRcM/xYUCf8TEQb/EhAF/xUTCP8YFgv/FhQJ/xMRBv8UEwX/GRcM/x8dEv8UEgj/DwwE/xMQCP8YFQ3/FxUL/xsZD/8eHBL/GBYM/x4cEv8cGhD/GhgN/xkXDP8ZFwz/GBYL/xYUCf8UEgf/GhgO/xkXDf8XFQv/FhQK/xYUCf8XFQr/GBYL/xkXDP8ZFwz/GBYL/xgXCf8ZGAr/GhkL/xkYCv8WFQf/ExIE/xcWCP8YFwn/GhgN/xoYDf8ZFw3/FxUL/xQRCf8SDwf/ExAI/xQRCf8WEwv/FhML/xYUCv8WFAr/GBYM/xkXDP8aGA7/FhQK/w8MBP8KBwD/DAkB/xIPB/8SDgn/DQkE/xIOCf8TDwr/Eg4J/xAMB/8TEAj/GhcP/xkWDv8TEAj/FREM/xcTDv8UEQn/DwwE/xANBf8VEgr/FRIK/xANBf8PDQP/FxUL/xgWDP8ZFw3/HBoQ/xkXDf8UEgf/GBYL/xoXD/8SDwf/DQoC/xEOBv8UEQn/FBEJ/xUSCv8ZFg7/ExAI/xUSCv8YFQ3/FxQM/xUSCv8VEgr/FxQM/xoXD/8YFgz/GRcN/xoYDv8bGQ//GxkP/xoYDv8YFgv/FxUK/x4cEf8aGA3/GRcN/xoYDv8bGQ//GRcN/xcVC/8YFgz/GBUN/xkWDv8XFAz/Eg8H/wwKAP8LCQD/Dw0D/xQSCP8dGxH/IR8V/yQiF/8iIBX/HRsQ/xoYDf8bGQ7/HhwR/x4cEf8eHBH/HRsQ/x0bEP8cGg//GxkO/xsZDv8bGQ7/HRsQ/xwaD/8bGQ7/GhgN/xkXDP8YFgv/GBYL/xgWC/8aGA3/GhgN/xkXDP8aGA3/GxkO/xoYDf8XFQr/FRMI/xMRBv8XFQr/GxkO/xsZDv8ZGAr/GRgK/x4dD/8iIBX/FxUL/xEOBv8TEAj/FBEJ/xEPBf8WFAr/HRsR/xsZD/8eHBL/HBoQ/xoYDf8ZFwz/GRcM/xgWC/8WFAn/FBIH/xkXDf8YFgz/FxUL/xYUCv8XFQr/GBYL/xkXDP8bGQ7/GBYL/xgWC/8YFwn/GRgK/xoZC/8ZGAr/FxYI/xUUBv8VFAb/FxYI/xkXDP8aGA3/GRcN/xcVC/8VEgr/ExAI/xMQCP8UEQn/FhML/xYUCv8WFAr/FhQK/xgWC/8ZFwz/GhgN/xcVCv8RDwX/DAoA/w4LA/8TEAj/Ew8K/xAMB/8SDgn/Eg4J/xAMB/8OCgX/EQ0I/xcTDv8ZFg7/FxQM/xURDP8VEQz/Eg8H/w4LA/8QDQX/FRIK/xYTC/8UEQn/EQ8F/xcVC/8WFAr/FhQK/xoYDv8YFgz/FRMI/xoYDf8aFw//Eg8H/w4LA/8PDAT/ExAI/xMQCP8VEgr/GBUN/xIPB/8UEQn/FhML/xYTC/8VEgr/FRIK/xcUDP8ZFg7/FhML/xcUDP8ZFw3/GxkP/xwaD/8dGxD/HRsQ/x0bEP8gHhP/HBoP/xkXDP8ZFwz/GxkP/xoYDv8XFAz/FBEJ/xkWDv8bGBD/GhcP/xYTC/8QDgT/DQsB/w4MAv8RDwX/FxUL/xwaEP8gHhP/IR8U/x4cEf8bGQ7/GxkO/xwaD/8cGg//HBoP/xwaD/8cGg//HBoP/xwaD/8bGQ7/GxkO/xwaD/8bGQ7/GxkO/xoYDf8ZFwz/GRcM/xgWC/8YFgv/GRcM/xkXDP8YFgv/GRcM/xsZDv8aGA3/GRcM/xcVCv8TEgT/FxYI/x0cDv8eHQ//HRwO/x0cDv8fHw//ISAS/xoYDv8VEgr/FBEJ/xIPB/8LCQD/EA4E/xsZD/8dGxH/HRsR/xsZD/8aGA3/GRcM/xkXDP8YFgv/FxUK/xUTCP8XFQr/FxUK/xYUCf8XFQr/GBYL/xoYDf8bGQ7/HBoP/xgXCf8XFgj/FxYI/xkYCv8aGQv/GxoM/xkZCf8XFgj/FBMF/xUTCP8XFQr/GBYL/xkXDf8YFgz/FhML/xUSCv8TEAj/FBEJ/xYUCv8WFAr/FhQK/xYUCf8YFgv/GRcM/xoYDf8YFgv/FBII/w8NA/8QDQX/FBEJ/xURDP8SDgn/Ew8K/xENCP8OCgX/DAgD/w8LBv8UEAv/GRYO/xsYEP8YFA//FhIN/xIPB/8PDAT/EA0F/xMQCP8VEgr/FRIK/xMRB/8YFgz/FhQK/xQSCP8ZFw3/GBYM/xcVCv8dGxD/GBUN/xQRCf8RDgb/Eg8H/xUSCv8WEwv/FRIK/xQRCf8RDgb/Eg8H/xMQCP8UEQn/FBEJ/xUSCv8WEwv/FxQM/xgVDf8YFQ3/GhgO/xsZD/8cGg//HRsQ/x4cEf8eHBH/IR8U/x8dEv8aGA3/GBYL/xoYDv8bGQ//FhML/xEOBv8ZFg7/GxgQ/xwZEf8ZFg7/FRMJ/xIQBv8SEAb/EhAG/xMRB/8XFQv/HRsQ/x8dEv8eHBH/HBoP/xoYDf8aGA3/GxkO/xsZDv8bGQ7/GxkO/xwaD/8cGg//HBoP/xwaD/8bGQ7/GxkO/xsZDv8bGQ7/GhgN/xkXDP8YFgv/GBYL/xkXDP8YFgv/FxUK/xkXDP8aGA3/GxkO/xoYDf8YFgv/ExIE/xgXCf8dHA7/Hx4Q/x4dD/8bGgz/GhoK/xoZC/8bGQ//FxQM/xgVDf8VEgr/CwkA/w4MAv8ZFw3/HRsR/xwaEP8bGQ//GRcM/xkXDP8ZFwz/GRcM/xcVCv8WFAn/FRMI/xYUCf8XFQr/GBYL/xoYDf8cGg//HRsQ/x4cEf8YFwn/FxYI/xcWCP8ZGAr/GxoM/xwbDf8bGwv/GhoK/xIQBf8UEgf/FRMI/xcVCv8YFgz/GBYM/xgVDf8XFAz/ExAI/xQRCf8WFAr/FhQK/xYUCf8WFAn/GBYL/xkXDP8ZFwz/GRcM/xYUCv8RDwX/Eg8H/xUSCv8WEg3/FBAL/xQPDP8RDAn/DgoF/wwIA/8NCQT/EQ0I/xcTDv8cGBP/HBgT/xcTDv8TEAj/Eg8H/xIPB/8SDwf/Eg8H/xMQCP8UEgj/GRcN/xYUCv8VEwn/GRcN/xkXDf8ZFwz/IB4T/xYTC/8WEwv/FRIK/xYTC/8ZFg7/GhcP/xYTC/8SDwf/EQ4G/xANBf8RDgb/ExAI/xUSCv8WEwv/FxQM/xcUDP8cGRH/HBkR/xsZD/8bGQ//GxkO/xwaD/8cGw3/HBsN/yAfEf8gHxH/HRsQ/xgWC/8YFgz/GhgO/xcUDP8QDQX/GBUN/xoXD/8bGBD/GxgQ/xoYDv8YFgz/FxUL/xcVC/8RDwX/FRMJ/xoYDf8dGxD/HhwR/x0bEP8bGQ7/GhgN/xsZDv8bGQ7/HBoP/xwaD/8cGg//HBoP/x0bEP8dGxD/GhgN/xsZDv8cGg//HBoP/xwaD/8bGQ7/GhgN/xkXDP8aGA7/GBYM/xcVCv8YFgv/GRcM/xsZDv8aGQv/GRgK/xcWCP8aGQv/Hh4O/yAgEP8eHg7/GxsL/xcXB/8VFAb/GhgO/xkWDv8dGhL/GhcP/xEPBf8RDwX/GBYM/xkXDf8cGhD/GhgO/xkXDP8ZFwz/GRcM/xkXDP8YFgv/FhQJ/xUTCP8WFAn/FxUK/xkXDP8cGg//HRsQ/x4dD/8fHhD/GhkL/xkYCv8YFwn/GRgK/xsbC/8cHAz/HBwM/xsbC/8SEAX/ExEG/xQSCP8WFAr/FxUL/xgWDP8YFQ3/GBUN/xMQCP8UEQn/FhQK/xYUCv8WFAn/FhQJ/xgXCf8ZGAr/FxUK/xkXDP8XFQv/ExEH/xIPB/8VEgr/FxMO/xYSDf8UDwz/EAsI/w4KBf8OCgX/DQkE/w0JBP8TDwr/GhYR/xwYE/8XEw7/FBEJ/xUSCv8VEgr/EQ4G/xANBf8RDgb/EhAG/xgWDP8WFAr/FRMJ/xkXDf8ZFw3/GRcM/x8dEv8XFAz/GBUN/xcUDP8WEwv/GRYO/xsYEP8XFAz/EQ4G/xMQCP8SDwf/Eg8H/xQRCf8XFAz/GRYO/xkWDv8YFQ3/HhsT/x4bE/8cGhD/GxkP/xoYDf8aGA3/GhkL/xsaDP8dHA7/ISAS/yAeE/8ZFwz/FhQK/xkXDf8XFAz/Eg8H/xkWDv8ZFg7/GhcP/xoXD/8bGQ//GxkP/xoYDv8ZFw3/FBII/xYUCv8ZFwz/HBoP/x4cEf8eHBH/HBoP/xsZDv8dGxD/HRsQ/x0bEP8dGxD/HRsQ/x0bEP8dGxD/HRsQ/xoYDf8bGQ7/HRsQ/x4cEf8eHBH/HRsQ/xsZDv8aGA3/GxkP/xkXDf8YFgv/FxUK/xkXDP8aGA3/GRgK/xkYCv8aGQv/HBsN/x4eDv8gIBD/Hx8P/xwcDP8YGAj/FRQG/xoYDv8YFQ3/HRoS/x4bE/8VEwn/FRMJ/xgWDP8WFAr/GxkP/xoYDv8YFgv/GRcM/xkXDP8aGA3/GBYL/xcVCv8VEwj/FhQJ/xkXDP8bGQ7/HRsQ/x4cEf8fHhD/Hx4Q/xwbDf8aGQv/GRgK/xkYCv8bGwv/HBwM/xwcDP8cHAz/ExEG/xMRBv8UEgj/FRMJ/xYUCv8XFQv/GBUN/xgVDf8TEAj/FBEJ/xYUCv8WFAr/FhQJ/xYUCf8YFwn/GRgK/xYUCf8ZFwz/GBYL/xQSCP8TEAj/FRIK/xcTDv8WEg3/FA8M/xALCP8PCgf/EAsI/w4KBf8LBwL/DwsG/xgUD/8ZFRD/FBAL/xMQCP8YFQ3/GBUN/xMQCP8QDQX/Eg8H/w4MAv8VEwn/FBII/xQSCP8YFgz/GBYM/xcVCv8cGg//GhcP/xoXD/8WEwv/EQ4G/xMQCP8ZFg7/GRYO/xMQCP8XFAz/FRIK/xUSCv8XFAz/HBkR/x4bE/8eGxP/HBkR/x4aFf8dGhL/GxkP/xoYDv8ZFwz/GhgN/xsaDP8bGgz/GBcJ/yIhE/8jIRb/GRcM/xQSCP8XFQv/GBUN/xQQC/8aFw//GRYO/xgVDf8XFAz/GBYM/xgWDP8XFQv/FhQK/xgWDP8YFgz/GRcM/xsZDv8dGxD/HhwR/x4cEf8cGg//IB4T/yAeE/8fHRL/HhwR/x4cEf8dGxD/HRsQ/xwaD/8aGA3/HBoP/x4cEf8gHhP/IB4T/x8dEv8dGxD/GxkO/x0bEf8bGQ//GBYL/xcVCv8YFgv/GRcM/xgXCf8YFwn/GBcJ/xgXCf8aGgr/HBwM/x4eDv8dHQ3/GhoI/xgYCP8aGA7/FxQM/xoXD/8cGRH/FhQK/xYUCv8YFgz/ExEH/xsZD/8ZFw3/GBYL/xgWC/8aGA3/GhgN/xkXDP8XFQr/FhQJ/xgWC/8aGA3/HBoP/x4cEf8eHBH/Hh0P/x4dD/8fHhD/HRwO/xoaCv8ZGQn/GhoK/xwcDP8cHAz/GxsL/xQSB/8UEgf/FBII/xQSCP8VEgr/FhML/xcUDP8XFAz/ExAI/xQRCf8WFAr/FhQK/xYUCf8WFAn/GBcJ/xkYCv8VEwj/GBYL/xgWC/8UEgf/ExEH/xUSCv8XFAz/FxMO/xQQC/8RDAn/EAsI/xINCv8OCgX/CQUA/w0JBP8WEg3/FREM/xENCP8SDwf/GRYO/xsYEP8VEgr/EQ4G/xMQCP8LCQD/EhAG/xIQBv8TEQf/FxUL/xYUCv8UEgf/GhgN/x0bEf8bGQ//FBEJ/wsIAP8NCgL/FxQM/xkWDv8VEgr/GhcP/xgVDf8XFAz/GhgO/x8cFP8iHxf/IR4W/x8cFP8cGRH/GxgQ/xoYDv8ZFwz/GRcM/xoYDf8cGw3/HRwO/xYVB/8iIRP/JSMY/xoYDf8SEAX/FhQK/xkWDv8XFAz/HBkR/xoYDv8WEwv/FRMJ/xUTCf8VEwn/FBII/xMRB/8bGQ//GRcN/xkXDP8aGA3/HRsQ/x8dEv8eHBH/HRsQ/yIgFf8hHxT/IB4T/x8dEv8eHBH/HRsQ/xwaD/8cGg//GxkO/x0bEP8fHRL/IR8U/yEfFP8gHhP/HhwR/xwaD/8fHRP/HBoQ/xkXDP8XFQr/FxUK/xgWC/8YFwn/FxYI/xIRA/8SEQP/ExIE/xYWBv8aGQv/GxsL/xoaCv8YFwn/GxkP/xUSCv8WEwv/GBUN/xUTCf8XFQv/GBYM/xMRB/8aGA7/GRcN/xgWC/8YFgv/GhgN/xoYDf8ZFwz/GBYL/xcVCv8ZFwz/GxkO/x0bEP8eHBH/HhwR/x4dD/8dHA7/IB8R/x4dD/8bGwv/GhoK/xoaCv8bGwv/GxsL/xsaDP8VEwj/FRMI/xQSCP8UEgj/FBII/xUSCv8WEwv/FxQM/xMQCP8UEQn/FhQK/xYUCv8WFAr/FhQJ/xgWC/8ZGAr/GxkO/xkYCv8YFgv/GhgN/xoYDf8XFQv/FhQK/xgVDf8TEAj/DgoF/wsHAv8MCAP/DQkE/wsHAv8KBQL/CwYD/xMPCv8UEAv/FhML/xgVDf8YFQ3/FhML/xEOBv8NCgL/EhAG/xEPBf8RDwX/FBII/xgWDP8cGhD/HRsQ/xwaD/8eHBH/HBoP/xkXDf8VEwn/Eg8H/xIPB/8UEQn/FxQM/xwaEP8XFQv/FRMJ/xkXDP8fHRP/IR8V/yIgFv8kIhj/GxkO/xsZDv8bGQ7/HRwO/x8eEP8eHQ//HBsN/xkYCv8cGw3/GxoM/yAfEf8kIxX/IB8R/xYUCf8UEgf/GhgN/xoYDf8VEwj/FhQK/xsZDv8aGA3/ExEG/xAOA/8UEgf/FBIH/xUTCP8YFgv/GhgN/x0bEP8fHRL/IB4T/yAeE/8dGxH/HhwS/x8dE/8fHRP/HhwS/x0bEf8bGQ7/GRcM/xwaD/8dGxD/Hx4Q/yEgEv8hIBL/ISAS/yAfEf8fHhD/FRMI/xgWC/8cGg//HBoP/xoYDf8XFQr/FhQJ/xUTCP8UEgf/FRMI/xYUCf8VFAb/FBIH/xQTBf8WFQf/GBYL/xMRB/8UEgj/FRMJ/xcVC/8YFgz/GRcN/xkXDf8ZFw3/FhQK/xoYDv8ZFw3/FBII/xMRB/8XFQv/FhQK/xAOA/8ZFwz/GxoM/x0cDv8eHQ//HBsN/xsaDP8aGQv/GhkL/xsaDP8bGgz/GxoM/x0cDv8fHhD/Hx4Q/x4dD/8cGw3/FhQJ/xYUCf8XFQr/FxUK/xgWC/8ZFw3/GRcN/xkXDf8ZFw3/GBYM/xYTC/8UEQn/FBEJ/xUTCf8WFAr/FxUL/x4cEf8bGgz/GxkO/xwaD/8aGA3/FhQJ/xUTCf8WFAr/Eg8H/w4LA/8LBwL/DAgD/wwIA/8MCAP/DwoH/xQPDP8SDgn/Ew8K/xQRCf8XFAz/GRYO/xgVDf8VEgr/Eg8H/xEPBf8UEgj/FxUL/xoYDv8cGhD/HRsR/xwaD/8cGg//HBsN/xsaDP8YFgz/FBII/xEOBv8RDgb/ExAI/xYTC/8dGxH/GBYM/xYUCf8aGA3/HhwR/x0bEP8dGxH/HRsQ/xwaD/8cGw3/HBsN/x0cDv8eHQ//HRwO/xsaDP8ZGAr/GBcJ/xcWCP8bGgz/ISAS/x8eEP8ZGAr/FxYI/xoZC/8bGQ7/FhQJ/xYUCf8bGQ7/GRcM/xIQBf8QDgP/ExEG/xgWC/8YFgv/GhgN/xsZDv8cGg//HBoP/xwaD/8cGg//Hx0T/yAeFP8gHhT/IR8V/yAeFP8fHRP/HRsQ/xwaD/8cGg//HRsQ/x8eEP8gHxH/IB8R/yAfEf8fHhD/Hh0P/xoYDf8bGQ7/HBoP/xwaD/8cGg//GxkO/xoYDf8ZFwz/FhQJ/xcVCv8XFQr/FhQJ/xQSB/8UEgf/FhQJ/xgWC/8WFAr/FhQK/xcVC/8YFgz/GRcN/xkXDf8ZFw3/GRcN/xUTCf8ZFw3/GBYM/xIQBv8QDgT/ExEH/xUTCf8SEAb/GBYL/xsaDP8eHQ//Hh0P/xwbDf8ZGAr/GBcJ/xcWCP8bGgz/GhkL/xsaDP8cGw3/Hh0P/x8eEP8dHA7/HBsN/xQSB/8UEgf/FRMI/xUTCP8WFAn/FhQJ/xcVC/8XFQv/FxUL/xYUCv8VEgr/FBEJ/xMQCP8UEQn/FRIK/xUTCf8gHhP/HRwO/xwaD/8dGxD/GxkO/xYUCf8TEQf/FRMJ/xUSCv8SDwf/EAwH/w4KBf8LBwL/CwcC/xALCP8YExD/Eg4J/xIOCf8SDwf/FRIK/xgVDf8ZFg7/GBUN/xcUDP8QDgT/FRMJ/xsZD/8dGxH/HBoQ/xoYDv8ZFwz/GhgN/xoZC/8aGQv/GBYM/xQSCP8RDgb/EQ4G/xIPB/8UEQn/HBoQ/xkXDf8YFgv/HBoP/x0bEP8aGA3/FxUL/xcVCv8eHBH/HRwO/xwbDf8dHA7/HRwO/x0cDv8aGQv/GBcJ/xUUBv8UEwX/FhUH/xwbDf8fHhD/HBsN/xoZC/8aGQv/HBoP/xcVCv8XFQr/GhgN/xkXDP8RDwT/Dw0C/xMRBv8cGg//GxkO/xsZDv8bGQ7/GhgN/xoYDf8ZFwz/GRcM/x4cEv8fHRP/Hx0T/yAeFP8fHRP/HhwS/x0bEP8cGg//HhwR/x4cEf8fHhD/Hx4Q/x8eEP8eHQ//HRwO/xwbDf8dGxD/GhgN/xgWC/8ZFwz/HBoP/x4cEf8dGxD/GxkO/xkXDP8aGA3/GRcM/xgWC/8VEwj/FRMI/xYUCf8YFgv/GBYM/xgWDP8YFgz/GRcN/xkXDf8ZFw3/GRcN/xkXDf8VEwn/GhgO/xoYDv8UEgj/EA4E/xIQBv8VEwn/FhQK/xYUCf8ZFwz/HRsQ/x4cEf8cGg//GBYL/xYVB/8UEwX/GxoM/xoZC/8aGgr/HBwM/x4eDv8eHg7/HBwM/xsaDP8VEwj/FRMI/xUTCP8VEwj/FhQJ/xYUCf8WFAr/FxUL/xYUCv8VEwn/FBII/xMRB/8TEAj/ExAI/xQRCf8UEgj/HBoP/xoZC/8aGA3/HBoP/xsZDv8WFAn/ExEH/xQSCP8ZFg7/GBUN/xgUD/8VEQz/DgoF/wkFAP8MBwT/Ew4L/xIOCf8RDQj/EQ4G/xMQCP8VEgr/FxQM/xcUDP8WEwv/Dw0D/xQSCP8aGA7/GhgO/xYUCv8UEgj/FhQJ/xkXDP8aGQv/GhkL/xkXDf8XFQv/FBEJ/xIPB/8SDwf/ExAI/xkXDf8YFgz/GhgN/x4cEf8eHBH/GhgN/xYUCv8VEwj/Hx0S/x0cDv8cGw3/HBsN/x0cDv8cGw3/GhkL/xgXCf8YFwn/FhUH/xYVB/8bGgz/Hx4Q/x8eEP8bGgz/GBcJ/x0bEP8YFgv/FxUK/xoYDf8YFgv/EQ8E/w8NAv8TEQb/HBoP/xsZDv8aGA3/GhgN/xkXDP8ZFwz/GRcM/xkXDP8bGQ//GxkP/xwaEP8cGhD/GxkP/xsZD/8bGQ7/GhgN/x8dEv8fHRL/Hh0P/x4dD/8dHA7/HBsN/xwbDf8bGgz/HhwR/xgWC/8TEQb/FBIH/xkXDP8cGg//HBoP/xoYDf8cGg//HBoP/xsZDv8ZFwz/FxUK/xYUCf8XFQr/GBYL/xkXDf8ZFw3/GBYM/xcVC/8XFQv/FxUL/xcVC/8XFQv/FRMJ/xkXDf8cGhD/GRcN/xUTCf8UEgj/FhQK/xcVC/8RDwX/FRMI/xoYDv8dGxD/HBoP/xkXDP8WFAn/FRQG/xsaDP8bGgz/GxsL/xwcDP8dHQ3/HR0N/xwcDP8aGgr/GBcJ/xgWC/8YFgv/GBYL/xkXDP8ZFwz/GRcN/xkXDf8XFQv/FhQK/xYUCv8VEwn/FRIK/xQRCf8UEQn/FBII/xYUCf8UEwX/FhQJ/xoYDf8aGA3/FhQJ/xQSCP8VEwn/FRIK/xcUDP8aFhH/GhYR/xMPCv8LBwL/CwYD/w8KB/8SDgn/EQ0I/xANBf8RDgb/ExAI/xQRCf8TEAj/Eg8H/xMRB/8WFAr/GBYM/xUTCf8RDwX/EQ8F/xYUCf8bGQ7/GhkL/xsaDP8cGhD/GhgO/xcUDP8UEQn/FBEJ/xQRCf8VEwn/FhQK/xoYDf8gHhP/IB4T/xsZDv8YFgz/GRcM/x8dEv8dHA7/GxoM/xsaDP8cGw3/HBsN/xsaDP8aGQv/HRwO/xwbDf8bGgz/HBsN/x8eEP8fHhD/HBsN/xcWCP8dGxD/GBYL/xYUCf8ZFwz/FxUK/xEPBP8QDgP/FBIH/xkXDP8ZFwz/GBYL/xgWC/8ZFwz/GhgN/xwaD/8dGxD/GhgO/xoYDv8aGA7/GhgO/xoYDv8aGA7/GxkO/xsZDv8fHRL/Hx0S/x4dD/8dHA7/HRwO/xwbDf8cGw3/HBsN/yAeE/8aGA3/FBIH/xQSB/8YFgv/HBoP/xwaD/8aGA3/HBoP/x0bEP8cGg//GhgN/xcVCv8WFAn/FxUK/xkXDP8YFgz/FxUL/xYUCv8VEwn/FBII/xUTCf8WFAr/FhQK/xEPBf8VEwn/GRcN/xsZD/8ZFw3/FBII/xMRB/8UEgj/DQsB/xIQBv8XFAz/GhgO/xsZD/8aGA3/GRcM/xkXDP8cGw3/HBsN/xsbC/8cHAz/Hh4M/x0dC/8cHAr/GhoK/xkYCv8ZFwz/GRcM/xkXDP8ZFwz/GRcM/xkXDP8ZFwz/GBYM/xgWDP8YFgz/FxUL/xcVC/8WFAr/FhML/xUTCf8SEAX/ERAC/xQSB/8ZFwz/GhgN/xYUCf8UEgj/FRMJ/w4LA/8QDQX/FhIN/xoWEf8XEw7/EQ0I/w8KB/8RDAn/EAwH/xAMB/8QDQX/EQ4G/xIPB/8SDwf/EQ4G/w8MBP8YFgz/GBYM/xcVC/8VEwn/ExEH/xQSCP8aGA3/Hx0S/xoZC/8bGgz/HRsR/xwaEP8ZFg7/FhML/xQRCf8TEAj/EhAG/xQSCP8ZFwz/Hx0S/x8dEv8bGQ7/GhgO/xwaD/8eHBH/HBsN/xoZC/8aGQv/HBsN/x0cDv8dHA7/HBsN/yEgEv8iIRP/ISAS/x4dD/8dHA7/Hx4Q/xwbDf8XFgj/HBoP/xYUCf8VEwj/GBYL/xcVCv8RDwT/EQ8E/xcVCv8XFQr/FxUK/xYUCf8WFAn/GBYL/xsZDv8dGxD/Hx0S/xwaEP8cGhD/GxkP/xsZD/8bGQ//HBoQ/x0bEP8eHBH/IB4T/x8dEv8eHQ//HRwO/x0cDv8dHA7/Hh0P/x4dD/8iIBX/HhwR/xoYDf8YFgv/GxkO/x0bEP8dGxD/HBoP/xwaD/8cGg//HBoP/xoYDf8YFgv/FxUK/xkXDP8aGA3/FxUL/xYUCv8UEgj/ExEH/xMRB/8UEgj/FhQK/xcVC/8RDwX/EA4E/xMRB/8YFgz/GBYM/xMRB/8QDgT/EA4E/w4LA/8SDwf/FhML/xgVDf8ZFg7/GRcN/xoYDv8bGQ7/Hh0P/x0cDv8dHQ3/HR0N/x4eDP8eHgz/HBwK/xoaCP8YFwn/GBYL/xcVCv8XFQr/FxUK/xYUCf8WFAn/FhQJ/xgWDP8YFgz/GRcN/xkXDf8ZFw3/GBYM/xcUDP8WFAr/ExEG/xMSBP8WFAn/GhgN/xoYDf8WFAn/ExEH/xMRB/8OCwP/DgsD/xENCP8WEg3/FxMO/xIOCf8QCwj/EQwJ/wwIA/8NCQT/DwwE/xMQCP8VEgr/FRIK/xMQCP8QDQX/FxUL/xYUCv8VEwn/FRMJ/xUTCf8YFgz/GhgN/xwaD/8YFwn/GhkL/x0bEf8cGhD/GRYO/xYTC/8TEAj/Eg8H/xIQBv8UEgj/GBYL/x0bEP8bGQ7/GBYL/xgWDP8cGg//HBoP/xsaDP8ZGAr/GRgK/xwbDf8eHQ//Hx4Q/x8eEP8fHhD/JCMV/yQjFf8eHQ//GxoM/x0cDv8dHA7/GRgK/xsZDv8VEwj/ExEG/xcVCv8XFQr/EhAF/xMRBv8ZFwz/GBYL/xcVCv8WFAn/FhQJ/xcVCv8aGA3/HRsQ/x8dEv8cGhD/GxkP/xoYDv8aGA7/GhgO/xwaEP8dGxD/HhwR/x8dEv8fHRL/Hh0P/x0cDv8dHA7/Hh0P/yAfEf8hIBL/IiAV/yAeE/8eHBH/HBoP/xoYDf8aGA3/GxkO/xsZDv8aGA3/GhgN/xsZDv8ZFwz/GBYL/xgWC/8aGA3/GxkO/xYUCv8VEwn/FBII/xMRB/8TEQf/FhQK/xgWDP8aGA7/GRcN/xEPBf8ODAL/ExEH/xcVC/8VEwn/ExEH/xQRCf8UEAv/FREM/xcTDv8XFAz/FhML/xcVC/8ZFw3/GxkO/yAfEf8fHhD/Hh4O/x8fD/8fHw3/HyAM/x0eCv8bGwn/GRgK/xgXCf8YFwn/FxYI/xcVCv8WFAn/FhQJ/xYUCf8XFQr/FxUK/xgWDP8ZFw3/GBYM/xcVC/8WFAr/FRMJ/xcWCP8WFQf/GBYL/xwaD/8bGQ7/FRMI/xEPBf8RDwX/FRIK/xEOBv8QDAf/Ew8K/xQQC/8QDAf/DQgF/w0IBf8JBQD/CwcC/w8MBP8UEQn/GBUN/xgVDf8WEwv/ExAI/xIQBv8RDwX/EQ8F/xMRB/8WFAr/GBYM/xcVCv8WFAn/FhUH/xkYCv8cGhD/HBoQ/xkWDv8VEgr/EQ4G/xANBf8SEAb/FBII/xgWC/8bGQ7/GBYL/xQSB/8WFAr/GhgN/xsZDv8aGQv/GBcJ/xkYCv8cGw3/Hh0P/yAfEf8gHxH/GxoM/yMiFP8lJBb/Hh0P/xoZC/8dHA7/Hh0P/xsaDP8aGA3/FBIH/xMRBv8XFQr/FxUK/xMRBv8VEwj/GxkO/xoYDf8YFgv/FxUK/xYUCf8WFAn/GRcM/xsZDv8dGxD/GRcN/xgWDP8XFQv/FxUL/xcVC/8ZFw3/GxkO/xwaD/8fHRL/HhwR/x0cDv8dHA7/Hh0P/yAfEf8iIRP/IyIU/x4cEf8fHRL/HhwR/xsZDv8YFgv/FhQJ/xYUCf8YFgv/GRcM/xkXDP8aGA3/GRcM/xgWC/8YFgv/GhgN/xwaD/8XFQv/FRMJ/xQSCP8TEQf/FRMJ/xcVC/8aGA7/HBoQ/yIgFv8VEwn/DgwC/xIQBv8ZFw3/GRcN/xkXDf8bGBD/GRUQ/xkUEf8YFA//FhIN/xQRCf8UEQn/FxUL/xkXDP8hHxT/IB8R/x8fD/8fHw//ICAO/x8gDP8dHgr/GxsJ/xsbC/8bGgz/GxoM/xoZC/8ZFwz/GRcM/xgWC/8YFgv/FRMI/xYUCf8XFQv/GBYM/xgWDP8WFAr/FBII/xMRB/8UEwX/FhUH/xgWC/8ZFwz/GBYL/xYUCf8TEQf/EhAG/xANBf8QDQX/FREM/xQQC/8PCwb/FxMO/xkUEf8LBgP/EQ0I/w4KBf8PDAT/ExAI/xUSCv8TEAj/Eg8H/xMQCP8UEgj/EhAG/xIQBv8WFAr/FxUL/xYUCv8WFAn/GRcM/xkYCv8aGQv/GRcN/xgWDP8VEgr/ExAI/xMQCP8TEAj/ExEH/xQSCP8XFQr/GxkO/x4cEf8eHBH/GxkP/xkXDP8dGxD/GRgK/x0cDv8eHQ//GhkL/x4dD/8mJRf/JSQW/yAfEf8fHhD/HRwO/xwbDf8cGw3/HRwO/x8eEP8gHxH/GBYL/xwaD/8ZFwz/FxUK/xsZDv8ZFwz/FRMI/xkXDP8gHhP/GhgN/xoYDf8ZFwz/EhAF/xUTCP8cGg//GxkO/xoYDv8ZFw3/GBYM/xgWDP8YFgz/GhgO/xwaD/8dGxD/HhwR/x8dEv8dHA7/GxoM/xwbDf8gHxH/Hx4Q/xwbDf8gHhP/HhwR/xsZDv8bGQ7/GxkO/xsZDv8aGA3/GBYL/xsZDv8ZFwz/FxUK/xUTCP8UEgf/FRMI/xYUCf8XFQr/FRMJ/xUTCf8VEwn/FxUL/xkXDf8YFgz/FhQK/xMRB/8VEwn/FhQK/xQSCP8TEQf/FRMJ/xkXDf8ZFw3/FhML/xQQC/8VEA3/Ew4L/xURDP8XFAz/DwwE/w8NA/8cGg//HhwR/yIhE/8hIRH/Hh4O/yAgDv8lJRP/IyQQ/xwcCv8TEwP/FhUH/xkYCv8YFwn/FhUH/xUUBv8YFgv/GxkO/xsZDv8bGQ7/GhgN/xsZDv8aGA7/GBYM/xUTCf8SEAb/FRQG/xYVB/8YFgv/GhgN/xoYDf8YFgv/FhQK/xQSCP8PDAT/DAkB/xENCP8TDwr/EAwH/xURDP8YExD/DwoH/xENCP8OCgX/DgsD/xIPB/8UEQn/ExAI/xIPB/8TEAj/FBII/xIQBv8TEQf/FhQK/xcVC/8VEwn/FhQJ/xkXDP8XFgj/GBcJ/xgWDP8XFQv/FBEJ/xMQCP8TEAj/FBEJ/xMRB/8TEQf/FRMI/xgWC/8aGA3/GxkO/xoYDv8YFgv/HRsQ/xoZC/8eHQ//IB8R/xsaDP8eHQ//JCMV/yIhE/8eHQ//HRwO/xwbDf8bGgz/GxoM/xwbDf8dHA7/Hh0P/xoYDf8dGxD/GBYL/xUTCP8ZFwz/FxUK/xUTCP8ZFwz/HBoP/xcVCv8XFQr/FxUK/xIQBf8VEwj/GhgN/xgWC/8ZFw3/GBYM/xcVC/8WFAr/FxUL/xgWDP8ZFwz/GhgN/x8dEv8gHhP/Hh0P/xoZC/8cGw3/IB8R/yAfEf8dHA7/HhwR/x0bEP8cGg//HBoP/x0bEP8cGg//GhgN/xgWC/8cGg//HBoP/xoYDf8ZFwz/GBYL/xgWC/8YFgv/GBYL/xQSCP8UEgj/FRMJ/xcVC/8ZFw3/GRcN/xcVC/8VEwn/DQsB/xAOBP8RDwX/EQ8F/xMRB/8XFQv/GRcN/xkWDv8UEAv/FRAN/xINCv8UEAv/FxQM/xEOBv8QDgT/GhgO/x8dEv8jIhT/IyIU/x8fD/8eHg7/ISEP/yAgDv8bGwn/GBgI/xoZC/8dHA7/HBsN/xkYCv8XFgj/GBYL/xoYDf8bGQ7/GhgN/xoYDf8aGA3/GhgO/xgWDP8VEwn/EhAG/xQTBf8WFQf/GBYL/xoYDf8aGA3/GhgN/xkXDf8YFgz/EA0F/woHAP8NCQT/Eg4J/xENCP8SDgn/FRAN/xMOC/8SDgn/DgoF/w4LA/8SDwf/FBEJ/xMQCP8SDwf/FBEJ/xUTCf8SEAb/ExEH/xYUCv8XFQv/FRMJ/xYUCf8YFgv/FhUH/xcWCP8XFQv/FhQK/xQRCf8TEAj/FBEJ/xUSCv8WFAr/FRMJ/xUTCP8XFQr/GhgN/xsZDv8bGQ//GhgN/xwaD/8aGQv/Hx4Q/yIhE/8cGw3/HRwO/yEgEv8eHQ//HBsN/xwbDf8bGgz/GhkL/xoZC/8bGgz/HBsN/xwbDf8cGg//HhwR/xgWC/8UEgf/FxUK/xYUCf8UEgf/GhgN/xsZDv8VEwj/FhQJ/xgWC/8WFAn/GRcM/xwaD/8XFQr/GRcN/xgWDP8XFQv/FhQK/xYUCv8WFAr/FxUK/xcVCv8gHhP/IR8U/x4dD/8aGQv/GxoM/x8eEP8hIBL/IB8R/x0bEP8dGxD/HhwR/x4cEf8eHBH/HBoP/xoYDf8YFgv/GxkO/xsZDv8bGQ7/GxkO/xoYDf8ZFwz/GBYL/xcVCv8TEQf/ExEH/xQSCP8WFAr/GBYM/xkXDf8YFgz/FxUL/xMRB/8VEwn/FxUL/xUTCf8RDwX/EA4E/xEPBf8TEAj/FhIN/xURDP8RDQj/Eg4J/xgVDf8VEgr/EhAG/xkXDf8eHBH/IyIU/yQjFf8fHw//GxsL/xsbC/8cHAz/GxsL/xsbC/8eHg7/ISAS/yEgEv8eHQ//GxoM/xkYCv8ZGAr/GhgN/xoYDf8ZFwz/GhgN/xoYDf8YFgv/FRMI/xIQBf8TEgT/FBMF/xYUCf8YFgv/GRcM/xoYDf8aGA7/GhgO/xYTC/8OCwP/DQkE/xMPCv8TDwr/DwsG/xALCP8UDwz/Ew8K/w8LBv8PDAT/Eg8H/xQRCf8TEAj/ExAI/xUSCv8VEwn/ExEH/xMRB/8WFAr/FxUL/xUTCf8VEwj/GBYL/xYVB/8XFgj/GBYM/xcVC/8WEwv/FRIK/xYTC/8XFAz/HBoQ/xoYDv8ZFwz/GRcM/xwaD/8eHBH/Hx0T/x4cEf8cGg//GxoM/yEgEv8jIhT/HRwO/x0cDv8fHhD/GxoM/xoZC/8aGQv/GhkL/xoZC/8aGQv/GhkL/xoZC/8aGQv/HhwR/x8dEv8XFQr/EhAF/xUTCP8VEwj/FBIH/xoYDf8cGg//FxUK/xkXDP8cGg//GxkO/x4cEf8gHhP/GhgN/xoYDv8ZFw3/GRcN/xgWDP8XFQv/FhQK/xYUCf8WFAn/IB4T/yIgFf8fHhD/GhkL/xoZC/8eHQ//ISAS/yEgEv8bGQ7/HRsQ/yAeE/8gHhP/Hx0S/x0bEP8bGQ7/GhgN/xcVCv8YFgv/GhgN/xoYDf8ZFwz/FxUK/xUTCP8TEQb/ExEH/xIQBv8TEQf/FRMJ/xgWDP8aGA7/GRcN/xkXDf8ZFw3/GxkP/x0bEf8aGA7/ExEH/w0LAf8NCwH/EhAG/xcUDP8XEw7/EQ0I/xIOCf8aFw//GhcP/xYUCv8ZFw3/GRcM/x0bEP8fHRL/HBsN/xYVB/8VFQX/GRgK/xwcDP8aGgr/HR0N/yEgEv8jIhT/IiET/x8eEP8cGw3/GhkL/xkXDP8ZFwz/GRcM/xkXDP8aGA3/GBYL/xUTCP8SEAX/ERAC/xIRA/8UEgf/FhQJ/xgWC/8ZFwz/GRcN/xoYDv8eGxP/FhML/xAMB/8TDwr/FBAL/w4KBf8NCAX/Ew4L/xURDP8QDAf/DwwE/xIPB/8UEQn/FBEJ/xQRCf8XFAz/FhQK/xMRB/8UEgj/FhQK/xcVC/8UEgj/FRMI/xcVCv8XFgj/GBcJ/xkXDf8YFgz/FxQM/xYTC/8XFAz/GBUN/x0bEf8bGQ//GhgN/xoYDf8cGg//HhwR/x4cEv8eHBH/HRsQ/xsaDP8hIBL/IyIU/xwbDf8cGw3/Hh0P/xoZC/8aGQv/GhkL/xoZC/8aGQv/GhkL/xoZC/8aGQv/GhkL/xwaD/8eHBH/FhQJ/xEPBP8VEwj/FRMI/xQSB/8aGA3/HBoP/xcVCv8aGA3/HRsQ/xoYDf8dGxD/Hx0S/xsZDv8bGQ//GxkP/xsZD/8bGQ//GhgO/xkXDf8YFgv/GBYL/x4cEf8hHxT/IB8R/xsaDP8ZGAr/HRwO/yAfEf8hIBL/GxkO/x4cEf8hHxT/IR8U/x8dEv8dGxD/HBoP/x0bEP8YFgv/GRcM/xoYDf8bGQ7/GhgN/xgWC/8VEwj/FBIH/xMRB/8TEQf/EhAG/xQSCP8XFQv/GRcN/xoYDv8ZFw3/FBII/xYUCv8ZFw3/GxkP/xUTCf8ODAL/Dw0D/xYUCv8XFAz/GRYO/xMQCP8SDwf/GxgQ/x0aEv8ZFw3/GhgO/xMRB/8VEwj/GBYL/xcVCv8TEQb/EhED/xcVCv8dHA7/FxcH/xkZCf8dHQ3/ISER/yMiFP8iIRP/Hx4Q/xwbDf8YFwn/GBcJ/xgWC/8ZFwz/GhgN/xgWC/8VEwj/ExEG/xIRA/8SEQP/ExEG/xUTCP8WFAn/GBYL/xkXDf8ZFw3/IR4W/x0aEv8UEAv/EAwH/xIOCf8PCwb/DAcE/xINCv8UEAv/DwsG/w0KAv8QDQX/Eg8H/xIPB/8TEAj/FhML/xYUCv8UEgj/FBII/xYUCv8XFQv/FBII/xQSB/8XFQr/GBcJ/xkYCv8aGA7/GRcN/xcUDP8WEwv/FhML/xcUDP8ZFw3/GBYM/xgWC/8ZFwz/GhgN/xsZDv8bGQ//GhgN/x0bEP8bGgz/Hx4Q/yEgEv8bGgz/GxoM/x4dD/8bGgz/GhkL/xsaDP8cGw3/HBsN/xwbDf8cGw3/GxoM/xoZC/8ZFwz/GxkO/xYUCf8SEAX/FhQJ/xYUCf8VEwj/GhgN/xkXDP8WFAn/GRcM/xoYDf8UEgf/FhQJ/xwaD/8aGA3/GxkP/xwaEP8dGxH/HRsR/x0bEf8cGhD/GxkO/xoYDf8bGQ7/Hx0S/yEgEv8dHA7/GhkL/xsaDP8eHQ//Hx4Q/x0bEP8fHRL/IR8U/yAeE/8dGxD/HBoP/x4cEf8hHxT/HBoP/xwaD/8cGg//HBoP/xsZDv8aGA3/GRcM/xgWC/8VEwn/FBII/xMRB/8UEgj/FhQK/xgWDP8ZFw3/GRcN/xcVC/8UEgj/FhQK/xkXDf8UEgj/CggA/wkHAP8PDQP/ExAI/xkWDv8VEgr/EQ4G/xgVDf8cGRH/GRcN/xoYDv8RDwX/EA4E/xEPBP8TEQb/EhAF/xEPBP8VEwj/HBoP/xcWCP8XFwf/GhoK/x4eDv8hIBL/IiET/yAfEf8dHA7/FxYI/xcWCP8XFQr/GBYL/xkXDP8YFgv/FRMI/xMRBv8UEwX/FBMF/xUTCP8VEwj/FhQJ/xgWC/8ZFw3/GhgO/x0aEv8fHBT/FBAL/wsHAv8PCwb/EAwH/w4JBv8RDAn/EQ0I/wwIA/8KBwD/DAkB/w4LA/8PDAT/EA0F/xMQCP8XFQv/FBII/xQSCP8XFQv/FhQK/xQSCP8UEgf/FhQJ/xgXCf8YFwn/GRcN/xcVC/8VEgr/ExAI/xMQCP8UEQn/FxUL/xcVC/8YFgv/GhgN/xwaD/8bGQ7/GRcN/xcVCv8eHBH/GhkL/x4dD/8fHhD/GRgK/xsaDP8gHxH/HRwO/xsaDP8cGw3/HRwO/x4dD/8eHQ//HRwO/xwbDf8bGgz/FRMI/xkXDP8VEwj/ExEG/xgWC/8XFQr/FRMI/xoYDf8ZFwz/FxUK/xwaD/8ZFwz/EA4D/xEPBP8aGA3/HBoP/xoYDv8bGQ//HBoQ/x4cEv8eHBL/HRsR/xwaD/8bGQ7/FxUK/x4cEf8iIRP/Hh0P/xoZC/8bGgz/HBsN/xwbDf8eHBH/IR8U/yEfFP8fHRL/GxkO/xsZDv8gHhP/JSMY/x4cEf8dGxD/HBoP/xsZDv8aGA3/GhgN/xoYDf8aGA3/FxUL/xUTCf8TEQf/ExEH/xUTCf8XFQv/GBYM/xgWDP8dGxH/FhQK/xUTCf8aGA7/FRMJ/wkHAP8FAwD/CAYA/w4MAv8XFQv/FRMJ/w8NA/8UEgj/GBYM/xcVC/8aGA7/FhQK/xAOBP8PDQP/EhAG/xMRB/8RDwX/FBII/xoYDf8bGgz/GRkJ/xkZCf8cHAz/ICAQ/yEhEf8fHhD/HRwO/xYVB/8WFQf/FxUK/xgWC/8ZFwz/GBYL/xYUCf8TEQb/FxUK/xYUCf8WFAn/FxUK/xcVCv8ZFwz/GhgO/xsZD/8ZFg7/HxwU/xQRCf8HBAD/DQkE/xIOCf8QDAf/EQ0I/w8LBv8KBgH/BwQA/wkGAP8LCAD/DAkB/w4LA/8RDgb/FxUL/xUTCf8UEgj/FxUL/xYUCv8UEgj/ExEH/xYUCf8XFgj/GBcJ/xcVCv8VEwn/ExEH/xEPBf8QDgT/EQ8F/xkXDf8ZFwz/GxkO/x0bEP8fHRL/HhwR/xoYDf8XFQr/HhwR/xoZC/8dHA7/HRwO/xgXCf8bGgz/ISAS/x8eEP8cGw3/HRwO/x8eEP8gHxH/IB8R/x8eEP8dHA7/HBsN/xIQBf8XFQr/FRMI/xQSB/8ZFwz/GBYL/xYUCf8aGA3/GxkO/xsZDv8gHhP/GxkO/w8NAv8PDQL/GxkO/yAeE/8YFgz/GRcN/xsZD/8dGxH/HhwS/x4cEv8dGxD/HBoP/xQSB/8cGg//IiAV/x8eEP8bGQ7/GhkL/xsZDv8bGQ7/IB4T/yEfFP8hHxT/HhwR/xoYDf8aGA3/IR8U/yclGv8dGxD/GxkO/xkXDP8XFQr/FhQJ/xcVCv8YFgv/GRcM/xkXDf8WFAr/FBII/xMRB/8VEwn/FxUL/xcVC/8XFQv/GhgO/xIQBv8SEAb/GhgO/xoYDv8RDwX/DAoA/w8NA/8JBwD/FRMJ/xQSCP8NCwH/EA4E/xQSCP8VEwn/GBYM/xsZD/8TEQf/Dw0D/xMRB/8UEgj/EQ8F/xIQBv8XFQr/Hx4Q/xwcDP8aGgr/GxsL/x8fD/8gIBD/Hh0P/xwbDf8WFQf/FhUH/xYUCf8YFgv/GRcM/xgWC/8WFAn/ExEG/xgWC/8YFgz/GBYM/xgWDP8YFgz/GBYM/xgWDP8YFgz/GRcN/xUTCf8PDQP/DAoA/wwJAf8NCgL/DgsD/w4LA/8PDAT/DwwE/w8MBP8PDAT/DwwE/w8MBP8PDAT/DwwE/xMQCP8TEAj/ExAI/xMQCP8TEAj/ExAI/xMQCP8TEQf/FRMI/xUUBv8VFAb/FRMI/xUTCP8VEwj/FRMI/xUTCP8aGA3/GhkL/xoZC/8aGQv/GhkL/xoZC/8aGQv/GhgN/yIeE/8iHhP/Ix8U/yMfFP8jHxT/JCAV/yQgFf8kIBX/HhoP/x4aD/8eGg//HhoP/x4aD/8eGg//HhoP/x4aD/8WFQf/FhUH/xYVB/8WFQf/FhUH/xYVB/8WFQf/FhUH/xgXCf8YFwn/GBcJ/xkYCv8ZGAr/GhkL/xoZC/8aGA3/HhkQ/x0YD/8dGA//HBcO/xsWDf8aFQz/GhUM/xkUC/8gGxL/IBsS/yAbEv8gHBH/IBsS/yAcEf8gGxL/IBsS/yAbEv8gGxL/IBsS/yEcE/8hHBP/Ih0U/yIdFP8iHRT/HxoR/x4ZEP8dGA//GxYN/xgTCv8WEQj/FRAH/xQPBv8YFgz/GBYM/xgWDP8YFgz/GBYM/xgWDP8YFgz/GBYM/xQSCP8UEgj/FBII/xQSCP8UEgj/FBII/xQSCP8UEgj/EQ8F/xEPBf8RDwX/EQ8F/xEPBf8RDwX/EQ8F/xEPBf8RDwX/EQ8F/xEPBf8RDwX/EQ8F/xEPBf8RDwX/EQ8E/x4dD/8eHQ//Hh0P/x4dD/8eHQ//Hh0P/x4dD/8eHQ//GhkL/xoZC/8aGQv/GhkL/xoZC/8aGQv/GhkL/xoZC/8XFQv/FxUL/xcVC/8XFQv/FxUL/xcVC/8XFQv/FxUL/xoYDv8WFAr/EQ8F/w8NA/8PDQP/EA4E/xEPBf8SEAb/DgsD/w4LA/8OCwP/DgsD/w4LA/8OCwP/DgsD/w4LA/8UEQn/FBEJ/xQRCf8UEQn/FBEJ/xQRCf8UEQn/FBII/xYUCf8WFQf/FhUH/xYVB/8WFQf/FhUH/xYVB/8WFQf/GRgK/xkYCv8ZGAr/GRgK/xkYCv8ZGAr/GRgK/xkYCv8UEAX/FBAF/xQQBf8VEQb/FREG/xYSB/8WEgf/FhIH/yEdEv8hHRL/IR0S/yEdEv8hHRL/IR0S/yEdEv8fHhD/FxYI/xcWCP8XFgj/FxYI/xcWCP8XFgj/FxYI/xcWCP8YFwn/GBcJ/xgXCf8YFwn/GRgK/xkYCv8aGQv/GhkL/yAcEf8gHBH/HxsQ/x8bEP8eGg//HRkO/xwYDf8cGA3/Eg4D/xIOA/8SDgP/Eg4D/xIOA/8SDgP/Eg4D/xIOA/8eGg//HhoP/x8bEP8fGxD/HxsQ/yAcEf8gHBH/IBwR/yMfFP8iHhP/IR0S/x8bEP8eGg//HBgN/xsXDP8YFgv/GBYL/xgWC/8YFgv/GBYL/xgWC/8YFgv/GBYL/xgWC/8WFAn/FhQJ/xYUCf8WFAn/FhQJ/xYUCf8WFAn/FhQJ/xAOBP8QDgT/EA4E/xAOBP8QDgT/EA4E/xAOBP8QDgT/EA4E/xAOBP8QDgT/EA4E/xAOBP8QDgT/EA4E/xAOBP8cGg//HBsN/xwbDf8cGw3/HBsN/xwbDf8cGw3/HBsN/xcWCP8XFgj/FxYI/xcWCP8XFgj/FxYI/xcWCP8WFgj/EA8F/xAOBv8QDgb/EA4G/xAOBv8QDgb/EA4G/xAOBv8UEgr/EQ8H/w0LA/8LCQH/DAoC/w4MBP8PDQX/Dw0F/woIAP8KCAD/CggA/woIAP8KCAD/CggA/woIAP8KCAD/DgwE/w4MBP8ODAT/DgwE/w4MBP8ODAT/DgwE/w4NA/8REQP/ERIC/xESAv8REgL/ERIC/xESAv8REgL/ERIC/xESAv8REgL/ERIC/xESAv8REgL/ERIC/xESAv8REgL/IyIU/yMiFP8jIhT/JCMV/yQjFf8lJBb/JSQW/yUkFv8YFwn/GBcJ/xgXCf8YFwn/GBcJ/xgXCf8YFwn/GBcJ/xIRA/8REgL/ERIC/xESAv8REgL/ERIC/xESAv8REgL/EBEB/xARAf8REgL/ERIC/xESAv8SEwP/EhMD/xITA/8YFwn/FxYI/xcWCP8WFQf/FRQG/xQTBf8UEwX/FBMF/yIhE/8iIRP/IiET/yIhE/8iIRP/IiET/yIhE/8iIRP/FBMF/xQTBf8UEwX/FRQG/xUUBv8VFAb/FhUH/xYVB/8bGgz/GhkL/xoZC/8ZGAr/GBcJ/xcWCP8WFQf/FhUH/xMSBP8SEgT/EhIE/xISBP8SEgT/EhIE/xISBP8SEgT/ERED/xERA/8REQP/ERED/xERA/8REQP/ERED/xERA/8LCgD/CwkB/wsJAf8LCQH/CwkB/wsJAf8LCQH/CwkB/wsJAf8LCQH/CwkB/wsJAf8LCQH/CwkB/wsJAf8LCgD/ExMH/xMTB/8TEwf/ExMH/xMTB/8TEwf/ExMH/xMTB/8PDwP/Dw8D/w8PA/8PDwP/Dw8D/w8PA/8PDwP/Dw8B/w==")
      0% 0% / contain;
  }

  .keywords:not(:has(.keyword)) > * {
    display: none;
  }
</style>
<style>
  html {
    --primary-color: #1f787f;
    --primary-color-transparent: #1f787f60;
  }

  [catalogue*="Adeptus Astartes" i] {
    --primary-color: #536766;
    --primary-color-transparent: #53676660;
  }

  [catalogue*="Blood Angels" i] {
    --primary-color: #761119;
    --primary-color-transparent: #76111960;
  }

  [catalogue*="Space Wolves" i] {
    --primary-color: #3e646f;
    --primary-color-transparent: #3e646f60;
  }

  [catalogue*="Imperial Fists" i] {
    --primary-color: #b87d00;
    --primary-color-transparent: #b87d0060;
  }

  [catalogue*="Raven Guard" i] {
    --primary-color: #2b2b2b;
    --primary-color-transparent: #2b2b2b60;
  }

  [catalogue*="Salamanders" i] {
    --primary-color: #1b623f;
    --primary-color-transparent: #1b623f60;
  }

  [catalogue*="White Scars" i] {
    --primary-color: #783028;
    --primary-color-transparent: #78302860;
  }

  [catalogue*="Dark Angels" i] {
    --primary-color: #014419;
    --primary-color-transparent: #01441960;
  }

  [catalogue*="Black Templars" i] {
    --primary-color: #002f42;
    --primary-color-transparent: #002f4260;
  }

  [catalogue*="Deathwatch" i] {
    --primary-color: #44494d;
    --primary-color-transparent: #44494d60;
  }

  [catalogue*="Adeptus Custodes" i] {
    --primary-color: #765c41;
    --primary-color-transparent: #765c4160;
  }

  [catalogue*="Adeptus Mechanicus" i] {
    --primary-color: #a03332;
    --primary-color-transparent: #a0333260;
  }

  [catalogue*="Adepta Sororitas" i] {
    --primary-color: #5e0a00;
    --primary-color-transparent: #5e0a0060;
  }

  [catalogue*="Astra Militarum" i] {
    --primary-color: #375441;
    --primary-color-transparent: #37544160;
  }

  [catalogue*="Grey Knights" i] {
    --primary-color: #4a6672;
    --primary-color-transparent: #4a667260;
  }

  [catalogue*="Imperial Knights" i] {
    --primary-color: #03495e;
    --primary-color-transparent: #03495e60;
  }

  [catalogue*="Daemons" i] {
    --primary-color: #383c46;
    --primary-color-transparent: #383c4660;
  }

  [catalogue*="Chaos Space Marines" i] {
    --primary-color: #1d3138;
    --primary-color-transparent: #1d313860;
  }

  [catalogue*="World Eaters" i] {
    --primary-color: #883531;
    --primary-color-transparent: #88353160;
  }

  [catalogue*="Death Guard" i] {
    --primary-color: #576011;
    --primary-color-transparent: #57601160;
  }

  [catalogue*="Chaos Knights" i] {
    --primary-color: #513627;
    --primary-color-transparent: #51362760;
  }

  [catalogue*="Thousand Sons" i] {
    --primary-color: #015d68;
    --primary-color-transparent: #015d6860;
  }

  [catalogue*="Necrons" i] {
    --primary-color: #005c2f;
    --primary-color-transparent: #005c2f60;
  }

  [catalogue*="Orks" i] {
    --primary-color: #4b6621;
    --primary-color-transparent: #4b662160;
  }

  [catalogue*="Tyranids" i] {
    --primary-color: #44264c;
    --primary-color-transparent: #44264c60;
  }

  [catalogue*="Genestealer Cults" i] {
    --primary-color: #44264c;
    --primary-color-transparent: #44264c60;
  }

  [catalogue*="Craftworlds" i] {
    --primary-color: #1f787f;
    --primary-color-transparent: #1f787f60;
  }

  [catalogue*="Harlequins" i] {
    --primary-color: #6f322f;
    --primary-color-transparent: #6f322f60;
  }

  [catalogue*="Leagues of Votann" i] {
    --primary-color: #7d4c08;
    --primary-color-transparent: #7d4c0860;
  }

  [catalogue*="T'au Empire" i] {
    --primary-color: #206173;
    --primary-color-transparent: #20617360;
  }

  .profile-icon[typeName*="melee" i],
  .profile-icon[typeName*="weapon" i] {
    content: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAASCAYAAAC0EpUuAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAH0SURBVDhPvVN/b9JQFH1o/I/MxG/A1+AzGhN/xrglE4i4odtwxmQF5hSyRQPKzDInaGxDCBmtdB2s7aNQjpdHQ1KhBf3Dk7y+9+695/S9k3fZf8Vq5jm85QwePUviycZGYH4uyrUaTAAnDXmG+DCxDt3huKK8dHi4WDixswOLim0amnkl5vLZqY+oqG30Kd4xbXCa5bYaLLxdKODSdUVhU7+YEG0Lj5MJH6lUKcOmOtNxYZgcvYGLnjuaL9zQdRLh0HomDO5AaZ/j/trq3OL9Ugl614Q1GAlxnfexncv5a8+5TT45wsfxCQc0DMsKvFahWMTQqxuPlnEprFrLZATn2uQTYRRj12ndaLZYsXTELMti5shF6uULn3j12xni8Tir/5BZ9fiEdS3Obt1cEblIJCLmKTTbFn/0tgITfzvT2Oab18LzL/XaNPZKyotTJrNZHzcQ98jTytdTdEdD7Fc+QtY1FD4cLUdehF8Djgty8d3xp6UEhaeLMPbqBjkei8W8SDhCRd9Xq5A7HRTyb1mUlKPRFTbuJC/998jkJKhOH1v5vE+k/L2O3r8Ibx0coENdk9zdnUtWDAPNkHc8gyw9bI0ENyUplPRZUdDiHHdTqXDxO9Tn6nCI9N7eUqf4SSdWqUG8bTAepNPLX4tw++n6H/WM/Qb5yZZZuC/34QAAAABJRU5ErkJggg==");
  }

  .profile-icon[typeName*="ranged" i],
  .profile-icon[typeName*="spell" i],
  .profile-icon[typeName*="psychic" i] {
    content: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAYAAACpF6WWAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAJJSURBVDhPtVRbTxpBGB3Qxmd+RmvShMe+81L6C0z60r70F/S1iZWHXmy4SDSAhSKNBBpCtVqboiataWJTY0ShrQpyaUK3IJcuC6vuwunsZDUlRFlsepLZ2Zk558y3s9985H9Ap/bn4qHTCaPRSAwGA8nmMuT2zVs9NT0xHX6FsiRDBJDMZaBOXw42z3PEUwfg6g3w7TY4vo56S0bt5BhLax/6N595PYffNLKC0MDHrTg+xeMs0rmVGNYT2+w9xXEYtVq1mU/4Z9Cgongm2yH4Xiicjd2hWdQpJ1up9DZ96nKDa4pIZvNd5LFJZ8ecxeFgmyfy3dwObOzto3x00nt3FZFYjEU87nZ3a0btdozZHUhzRaxtbmk2VZAplbCZSsHinOjUbdBJ5fCV9jnxlW2gLl0IXyQCgWoqssz6lwtvmE6vPCRJUjpyLLfJ9eGrxGQysfFFcAWDMJvNRJJlMjQwQLUyqVQqbI2ZiqJIdnb3yNCgniS+7ZIbw9d63pp7IyO6QCBAeJ4nh7Ua4YU60V8ZVFf/wnY2h3y5qvlMbV4v+1H+aPR8jZJSCml9J6nJuNpq0RRs9uZGV1bZbZpdWOwge0Khs/GDZ0+QKZdRo9d3fNqjKQASXHzLEjtdOoTjhR/ecBicIMDqcWF+dZl+TQtKKj2emtJmeIro+2UUGyIOfpVYqh3RlisVUahVWbV6REuiSu0foaV3zLQqSUj/LMBis13e7BRWnw8/6rTsUeMv+3uaDDVV8clwCDpqJzQb5P6du/9e+fsHIX8AQcajpvRRPZkAAAAASUVORK5CYII=");
  }
</style>
`,$d=`<template>
  <setting id="includeModels" label="Models" type="checkbox" default="true" />
  <set name="ruleProfiles" value="special rule,rule,rules,command"/>

  <div class="section cards">
    <units dedupe="true">
      <if type="has-profile" recursive="true">
      <div class="unit card-wrapper" type="card">
        <table class="section card movable">
          <tr class="section card-header">
            <td>
              <span class="costs">
                <costs>
                  <span class="cost">
                    <span>{{ value }}</span>
                    <span>{{ cost.name }}</span>
                  </span>
                </costs>
              </span>
              <if field="customName">
                <span class="custom-name">{{customName}}</span>
              </if>
              <span class="name">{{name}}</span>
              <if field="dupeCount" type=">" value="1">
                <span class="count">{{dupeCount}}</span>
              </if>
            </td>
          </tr>
          <tr if="settings.includeModels.state">
            <td>
              <table class="section card-models group">
                <models max="1">
                  <tr class="header model profile">
                    <td class="section cell nowrap header">
                      <span class="header name">Models</span>
                    </td>
                    <td class="section cell header">
                      <span class="header options">Options</span>
                    </td>
                  </tr>
                </models>
                <models dedupe="true">
                  <tr class="model profile">
                    <td class="section cell nowrap">
                      <span class="count">{{dupeCount}}</span>x
                      <span class="name">{{name}}</span>
                    </td>
                    <td class="section cell">
                      <span class="options"><options constants="true"/></span>
                    </td>
                  </tr>
                </models>
              </table>
            </td>
          </tr>
          <entries max="1" self="false">
          <if field="type" type="equals" value="unit">
          <tr class="section card-units card-row group">
            <td>
              <span class="header secondary cell">
                <span class="header name">Units</span>
              </span>
              <div class="secondaries cell">
              <unit.entries self="false">
              <if field="type" type="equals" value="unit">
                <span class="name">{{ amount }}x {{ name}}</span>
              </if>
              </unit.entries>
              </div>
            </td>
          </tr>
          </if>
          </entries>
          <tr class="section profile-row profiles group">
            <td>
              <profiles grouped="true" exclude="{{ruleProfiles}}">
                <table class="profile-group group removable">
                  <items max="1">
                    <tr class="header profile">
                      <td class="header name cell">
                        <span>{{typeName}}</span>
                        <if field="group">
                          ({{group}})
                        </if>
                      </td>
                      <characteristics>
                        <td class="header characteristic small cell data">
                          <span class="header value">{{name}}</span>
                        </td>
                      </characteristics>
                    </tr>
                  </items>
                  <items>
                    <tr class="section profile row removable">
                      <td class="name cell">{{name}}</td>
                      <characteristics>
                        <td class="characteristic small cell data">
                          <span type="markdown">{{value}}</span>
                        </td>
                      </characteristics>
                    </tr>
                  </items>
                </table>
              </profiles>
            </td>
          </tr>
          <tr class="section card-rules card-row">
            <td>
              <profiles include-rules="true" grouped="true" include="{{ruleProfiles}}">
              <div class="profiles profile-row profiles group">
                <span class="header secondary cell">
                  <items max="1">
                  <span class="name nowrap">{{typeName}}</span>
                  </items>
                </span>
                <span class="secondaries cell">
                  <items><span class="name">{{name}}</span></items>
                </span>
              </div>
              </profiles>
            </td>
          </tr>
          <tr class="section card-keywords card-row group">
            <td>
              <span class="header secondary cell">
                <span class="header name">Categories</span>
              </span>
              <div class="secondaries cell">
                <secondaries>
                  <span class="secondary"><span class="name">{{name}}</span></span>
                </secondaries>
              </div>
            </td>
          </tr>
        </table>
      </div>
    </if>
    </units>
     <!-- Rules -->
    <if type="has-rule" recursive="true">
      <or type="has-profile" recursive="true" value="{{ruleProfiles}}" />
    <div type="card">
      <div class="rules">
        <forces>
          <if type="has-rule">
            <div class="force removable"><span class="force-name">{{name}}</span> <span class="force-catalogue">({{catalogue}})</span>
              <rules recursive="false">
              <div class="rule nested removable">
              <span class="rule-name">{{name}}</span>
              <span class="rule-desc" type="markdown">{{description}}</span>
              </div>
              </rules>
            </div>
          </if>
        </forces>
        <rules skip-forces="true">
          <div class="rule removable">
            <span class="rule-name">{{name}}</span>
            <span class="rule-desc" type="markdown">{{description}}</span>
          </div>
        </rules>
        <profiles include="{{ruleProfiles}}">
          <div class="rule removable">
            <span class="rule-name">{{name}}</span>
            <characteristics>
              <span class="rule-desc" type="markdown">{{value}}</span>
            </characteristics>
          </div>
        </profiles>
      </div>
    </div>
    </if>
  </div>
</template>
<style>
@charset "UTF-8";

table,
.table {
  border-collapse: collapse;
}

@font-face {
  font-family: "Tahoma";
  src: url("/Tahoma.ttf") format(truetype);
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: "Tahoma";
  src: url("https://www.newrecruit.eu/TahomaBold.ttf") format(truetype);
  font-weight: bold;
  font-style: normal;
  font-variant: normal;
}

html {
  font-family: "Tahoma";
  background-color: white;
  scrollbar-width: thin;
  scrollbar-color: rgba(0, 0, 0, 0.3) rgba(0, 0, 0, 0);
  color: rgb(70, 70, 70);
}

.card .cost,
.table .cost {
  margin-left: 6px;
}

.card .cost-value-0,
.table .cost-value-0 {
  display: none;
}

.cost-type {
  margin-left: 1px;
}

.roster-header {
  text-align: center;
  margin-left: auto;
  margin-right: auto;
}

a {
  text-decoration: none;
  color: unset;
}

.force-catalogue {
  color: gray;
}

.forces .force {
  margin-bottom: 20px;
  -moz-column-break-inside: avoid;
  break-inside: avoid;
  -webkit-print-color-adjust: exact;
  print-color-adjust: exact;
}

@media not print {
  .forces .force {
    margin-left: auto;
    margin-right: auto;
  }
}

.forces .custom-name {
  font-weight: bold;
}

.options+.profile-group {
  margin-top: 10px;
}

.options-profiles-group-header,
.unit-categories-header {
  font-weight: bold;
  content: ": ";
}

.options-profiles-group-header::after,
.unit-categories-header::after {
  content: ": ";
}

.options-profiles-name:not(:last-child)::after {
  content: ", ";
  white-space: break-spaces;
}

.unit-category-name:not(:last-child)::after {
  content: ", ";
  white-space: break-spaces;
}

.options-profiles-name,
.unit-category-name {
  display: inline-block;
}

.section:empty {
  display: none;
}

.section.table .costs {
  margin-left: 4px;
}

.section.table .cell:not(.header) {
  text-align: left;
  vertical-align: middle;
  padding: 5px;
  border: 1px solid lightgrey;
}

.section.table> :nth-child(even) {
  background-color: rgba(51, 40, 40, 0.05);
}

.section.table .header.cell {
  border-bottom: 2px solid black;
  padding-right: 8px;
  text-transform: uppercase;
  font-weight: bold;
  font-family: "Constantia";
}

.section.roster-header .costs {
  margin-left: 4px;
}

.section.roster-header .force {
  display: table;
}

.section.config .costs {
  margin-left: 4px;
}

.section.config .unit::before {
  content: "• ";
}

.section.config .unit .name::after {
  content: ": ";
}

.header.cell {
  background-color: rgba(0, 0, 0, 0.1);
}

.unit {
  width: min(1000px, 100%);
}

.t9aprofile {
  margin-left: 10px;
}

.card:before {
  content: "";
  position: absolute;
  inset: 0;
  background: lightslategray;
  clip-path: polygon(0 12px, 12px 0, calc(100% - 12px) 0, 100% 12px, 100% calc(100% - 12px), calc(100% - 12px) 100%, 12px 100%, 0 calc(100% - 12px), 0 12px, 2px 12.83px, 2px calc(100% - 12px - 0.83px), 12.83px calc(100% - 2px), calc(100% - 12px - 0.83px) calc(100% - 2px), calc(100% - 2px) calc(100% - 12px - 0.83px), calc(100% - 2px) 12.83px, calc(100% - 12px - 0.83px) 2px, 12.83px 2px, 2px 12.83px);
}

.card {
  clip-path: polygon(0 12px, 12px 0, calc(100% - 12px) 0, 100% 12px, 100% calc(100% - 12px), calc(100% - 12px) 100%, 12px 100%, 0 calc(100% - 12px));
  border-bottom: 2px solid lightslategray;
  width: 100%;
}

.card-wrapper {
  position: relative;
  margin-left: auto;
  margin-right: auto;
  font-size: small;
  -webkit-print-color-adjust: exact;
  print-color-adjust: exact;
  -moz-column-break-inside: avoid;
  break-inside: avoid;
  margin-top: 10px;
  border-collapse: collapse;
  display: table;
}

.profile>.cell {
  padding: 2px;
  padding-left: 5px;
  padding-right: 5px;
}

.profile>.cell:not(.header) {
  border-left: 1px solid #e5e5e5;
  border-right: 1px solid #e5e5e5;
  border-bottom: 1px solid #e5e5e5;
  border-top: none;
  /* white-space: break-spaces; */
}

.profile.header * .cell {
  white-space: nowrap;
  border-left: none;
  border-right: none;
  border-top: 1px solid slategray;
  border-bottom: none;
  /* border-bottom: 1px solid slategray; */
}

.profiles> :first-child {
  border-top: none;
}

.profiles> :first-child>.row {
  border-top: none;
}

.profiles> :first-child>.row>.cell {
  border-top: none;
}

.row {
  page-break-inside: avoid;
}

.card-row {
  text-align: left;
}

.card-row .card-models .options::before {
  content: ": (";
}

.card-row .card-models .options::after {
  content: ")";
}

.card-row .card-models .models {
  padding-bottom: 5px;
}

.card-row .header.cell {
  padding: 5px;
  padding-left: 10px;
  background-color: rgba(0, 0, 0, 0.1);
  height: 100%;
}

.card-row .cell {
  display: table-cell;
}

.card-row .cell:not(.header) {
  border-left: 1px solid lightslategray;
  vertical-align: middle;
}

.card-row .cell:not(.header)>span:not(:last-child)::after {
  content: ",";
}

.card-row .cell:not(.header)>* {
  margin-left: 5px;
  display: inline-block;
}

.card-header {
  padding: 3px;
  background-color: slategray;
  position: relative;
  text-align: center;
}

.card-header .count {
  color: white;
  position: absolute;
  right: 15px;
  font-family: "Georgia";
}

.card-header .count::before {
  content: "x";
}

.card-header .name {
  color: white;
  text-align: center;
  text-transform: uppercase;
  font-family: Arial;
}

.card-header .custom-name {
  color: white;
  font-weight: bold;
  text-align: center;
  text-transform: uppercase;
  font-family: Arial;
}

.card-header .costs {
  color: white;
  position: absolute;
  text-transform: uppercase;
  left: 15px;
}

.card-header .costs .cost-type {
  margin-left: 3px;
}

.profile .name {
  white-space: nowrap;
}

.group {
  width: 100%;
  border-top: 1px solid slategray;
}

.roster-rules {
  margin-top: 20px;
}

.section.roster-rules .rule-name,
.section.unit-rules .rule-name {
  margin-top: 5px;
  font-weight: bold;
}

.section.roster-rules .rule-text,
.section.unit-rules .rule-text {
  white-space: pre-wrap;
  white-space-collapse: preserve-breaks;
  text-wrap: wrap;
}

.section.roster-rules .force-name,
.section.unit-rules .force-name {
  font-size: 24px;
}

.section.unit-rules .header {
  font-size: 24px;
  font-weight: bold;
}

.section.roster-rules .roster-rules-header {
  font-size: 24px;
  font-weight: bold;
}

.section.roster-rules .force {
  margin-top: 10px;
}

.nowrap {
  white-space: nowrap;
}

.rule-definitions,
.rule-definition {
  page-break-inside: avoid;
  margin-top: 10px;
}

.page-break-avoid {
  page-break-inside: avoid;
}

.on-next-page {
  page-break-before: always;
}

td {
  padding: 0;
}

.data {
  font-size: calc(var(--fontSize, 16px) - 2px) !important;
}

.data ul {
  margin: 0;
  padding: 0;
  margin-left: 16px;
  list-style-position: outside;
  margin-bottom: -16px;
}

.data li {
  margin-top: -16px;
}

.data li:before {
  content: "";
  margin-left: -0.4rem;
}

.data p {
  margin: 0;
  padding: 0;
  display: inline;
}

.data del {
  margin: 0;
  padding: 0;
  display: inline;
}

.note {
  color: gray;
  white-space: pre-wrap;
}

.data * td {
  border: 1px solid gray;
  padding: 2px;
}

.data * th {
  font-weight: bold;
}

.rules-block:not(:has(.rule)) {
  display: none !important;
}
.rules {
    padding: 8px;
    // background-color: rgb(233, 234, 236);
    border: 2px solid gray;
    margin-bottom: 32px;
}
.rule:not(:last-child), .force:not(:last-child)  {
  margin-bottom: 10px;
}
.rule-name {
  white-space: nowrap; 
  font-weight: 700;
  display: block;
}
.rule-name:not(:last-child)::after {
  content: ": ";
}
.rule-desc {
}
.force-name {
  white-space: nowrap; font-weight: 800;
}
.force-catalogue {
  color: gray; font-weight: 500;
}
.nested {
  margin-left: 5px
}
</style>
`,Rd=`<template>
  <setting id="includeModels" label="Models" type="checkbox" default="true" />
  <set name="ruleProfiles" value="special rule,rule,rules" />

  <div class="section cards">
    <units dedupe="true">
      <if type="has-profile" recursive="true">
        <div class="unit card-wrapper" type="card">
          <table class="section card movable">
            <tr class="section card-header">
              <td>
                <span class="costs">
                  <costs>
                    <span class="cost">
                      <span>{{ value }}</span>
                      <span>{{ cost.name }}</span>
                    </span>
                  </costs>
                </span>
                <if field="customName">
                  <span class="custom-name">{{customName}}</span>
                </if>
                <span class="name">{{name}}</span>
                <if field="dupeCount" type=">" value="1">
                  <span class="count">{{dupeCount}}</span>
                </if>
              </td>
            </tr>
            <tr if="settings.includeModels.state">
              <td>
                <table class="section card-models group">
                  <models max="1">
                    <tr class="header model profile">
                      <td class="section cell nowrap header">
                        <span class="header name">Models</span>
                      </td>
                      <td class="section cell header">
                        <span class="header options">Options</span>
                      </td>
                    </tr>
                  </models>
                  <models dedupe="true">
                    <tr class="model profile">
                      <td class="section cell nowrap">
                        <span class="count">{{dupeCount}}</span>x
                        <span class="name">{{name}}</span>
                      </td>
                      <td class="section cell">
                        <span class="options">
                          <options constants="true" />
                        </span>
                      </td>
                    </tr>
                  </models>
                </table>
              </td>
            </tr>
            <entries max="1" self="false">
              <if field="type" type="equals" value="unit">
                <tr class="section card-units card-row group">
                  <td>
                    <span class="header secondary cell">
                      <span class="header name">Units</span>
                    </span>
                    <div class="secondaries cell">
                      <unit.entries self="false">
                        <if field="type" type="equals" value="unit">
                          <span class="name">{{ amount }}x {{ name}}</span>
                        </if>
                      </unit.entries>
                    </div>
                  </td>
                </tr>
              </if>
            </entries>
            <tr class="section profile-row profiles group">
              <td>
                <profiles grouped="true" exclude="{{ruleProfiles}}">
                  <table class="profile-group group removable">
                    <items max="1">
                      <tr class="header profile">
                        <td class="header name cell">
                          <span>{{typeName}}</span>
                          <if field="group">
                            ({{group}})
                          </if>
                        </td>
                        <characteristics>
                          <td class="header characteristic small cell data">
                            <span class="header value">{{name}}</span>
                          </td>
                        </characteristics>
                      </tr>
                    </items>
                    <items>
                      <tr class="section profile row removable">
                        <td class="name cell">{{name}}</td>
                        <characteristics>
                          <td class="characteristic small cell data">
                            <span type="markdown">{{value}}</span>
                          </td>
                        </characteristics>
                      </tr>
                    </items>
                  </table>
                </profiles>
              </td>
            </tr>
            <tr class="section card-rules card-row">
              <td>
                <profiles include-rules="true" grouped="true" include="{{ruleProfiles}}">
                  <div class="profiles profile-row profiles group">
                    <span class="header secondary cell">
                      <items max="1">
                        <span class="name nowrap">{{typeName}}</span>
                      </items>
                    </span>
                    <span class="secondaries cell">
                      <items><span class="name">{{name}}</span></items>
                    </span>
                  </div>
                </profiles>
              </td>
            </tr>
            <tr class="section card-keywords card-row group">
              <td>
                <span class="header secondary cell">
                  <span class="header name">Categories</span>
                </span>
                <div class="secondaries cell">
                  <secondaries>
                    <span class="secondary"><span class="name">{{name}}</span></span>
                  </secondaries>
                </div>
              </td>
            </tr>
          </table>
        </div>
      </if>
    </units>
    <!-- Rules -->
    <if type="has-rule" recursive="true">
      <or type="has-profile" recursive="true" value="{{ruleProfiles}}" />
      <div type="card">
        <div class="rules">
          <forces>
            <if type="has-rule">
              <div class="force removable"><span class="force-name">{{name}}</span> <span class="force-catalogue">({{catalogue}})</span>
                <rules recursive="false">
                  <div class="rule nested removable">
                    <span class="rule-name">{{name}}</span>
                    <span class="rule-desc" type="markdown">{{description}}</span>
                  </div>
                </rules>
              </div>
            </if>
          </forces>
          <rules skip-forces="true">
            <div class="rule removable">
              <span class="rule-name">{{name}}</span>
              <span class="rule-desc" type="markdown">{{description}}</span>
            </div>
          </rules>
          <profiles include="{{ruleProfiles}}">
            <div class="rule removable">
              <span class="rule-name">{{name}}</span>
              <characteristics>
                <span class="rule-desc" type="markdown">{{value}}</span>
              </characteristics>
            </div>
          </profiles>
        </div>
      </div>
    </if>
  </div>
</template>
<style>
  @charset "UTF-8";

  table,
  .table {
    border-collapse: collapse;
  }

  @font-face {
    font-family: "Tahoma";
    src: url("/Tahoma.ttf") format(truetype);
    font-weight: normal;
    font-style: normal;
  }

  @font-face {
    font-family: "Tahoma";
    src: url("https://www.newrecruit.eu/TahomaBold.ttf") format(truetype);
    font-weight: bold;
    font-style: normal;
    font-variant: normal;
  }

  html {
    font-family: "Tahoma";
    background-color: black;
    scrollbar-width: thin;
    scrollbar-color: rgba(200, 200, 200, 1) rgba(0, 0, 0, 0.3);
    color: rgb(255, 255, 255);
  }

  .card .cost,
  .table .cost {
    margin-left: 6px;
  }

  .card .cost-value-0,
  .table .cost-value-0 {
    display: none;
  }

  .cost-type {
    margin-left: 1px;
  }

  .roster-header {
    text-align: center;
    margin-left: auto;
    margin-right: auto;
  }

  a {
    text-decoration: none;
    color: unset;
  }

  .force-catalogue {
    color: gray;
  }

  .forces .force {
    margin-bottom: 20px;
    -moz-column-break-inside: avoid;
    break-inside: avoid;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }

  @media not print {
    .forces .force {
      margin-left: auto;
      margin-right: auto;
    }
  }

  .forces .custom-name {
    font-weight: bold;
  }

  .options+.profile-group {
    margin-top: 10px;
  }

  .options-profiles-group-header,
  .unit-categories-header {
    font-weight: bold;
    content: ": ";
  }

  .options-profiles-group-header::after,
  .unit-categories-header::after {
    content: ": ";
  }

  .options-profiles-name:not(:last-child)::after {
    content: ", ";
    white-space: break-spaces;
  }

  .unit-category-name:not(:last-child)::after {
    content: ", ";
    white-space: break-spaces;
  }

  .options-profiles-name,
  .unit-category-name {
    display: inline-block;
  }

  .section:empty {
    display: none;
  }

  .section.table .costs {
    margin-left: 4px;
  }

  .section.table .cell:not(.header) {
    text-align: left;
    vertical-align: middle;
    padding: 5px;
    border: 1px solid lightgrey;
  }

  .section.table> :nth-child(even) {
    background-color: rgba(51, 40, 40, 0.05);
  }

  .section.table .header.cell {
    border-bottom: 2px solid black;
    padding-right: 8px;
    text-transform: uppercase;
    font-weight: bold;
    font-family: "Constantia";
  }

  .section.roster-header .costs {
    margin-left: 4px;
  }

  .section.roster-header .force {
    display: table;
  }

  .section.config .costs {
    margin-left: 4px;
  }

  .section.config .unit::before {
    content: "• ";
  }

  .section.config .unit .name::after {
    content: ": ";
  }

  .header.cell {
    background-color: rgba(70, 70, 70, 1);
  }

  .unit {
    width: min(1000px, 100%);
  }

  .t9aprofile {
    margin-left: 10px;
  }

  .card:before {
    content: "";
    position: absolute;
    inset: 0;
    background: rgba(0, 60, 80, 1);
    clip-path: polygon(0 12px, 12px 0, calc(100% - 12px) 0, 100% 12px, 100% calc(100% - 12px), calc(100% - 12px) 100%, 12px 100%, 0 calc(100% - 12px), 0 12px, 2px 12.83px, 2px calc(100% - 12px - 0.83px), 12.83px calc(100% - 2px), calc(100% - 12px - 0.83px) calc(100% - 2px), calc(100% - 2px) calc(100% - 12px - 0.83px), calc(100% - 2px) 12.83px, calc(100% - 12px - 0.83px) 2px, 12.83px 2px, 2px 12.83px);
  }

  .card {
    clip-path: polygon(0 12px, 12px 0, calc(100% - 12px) 0, 100% 12px, 100% calc(100% - 12px), calc(100% - 12px) 100%, 12px 100%, 0 calc(100% - 12px));
    border-bottom: 2px solid rgba(0, 60, 80, 1);
    width: 100%;
  }

  .card-wrapper {
    position: relative;
    margin-left: auto;
    margin-right: auto;
    font-size: 18px;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
    -moz-column-break-inside: avoid;
    break-inside: avoid;
    margin-top: 10px;
    border-collapse: collapse;
    display: table;
  }

  .profile>.cell {
    padding: 2px;
    padding-left: 5px;
    padding-right: 5px;
  }

  .profile>.cell:not(.header) {
    border-left: 1px solid rgba(0, 60, 80, 1);
    border-right: 1px solid rgba(0, 60, 80, 1);
    border-bottom: 1px solid rgba(0, 60, 80, 1);
    border-top: none;
    /* white-space: break-spaces; */
  }

  .profile.header * .cell {
    white-space: nowrap;
    border-left: none;
    border-right: none;
    border-top: 1px solid slategray;
    border-bottom: none;
    /* border-bottom: 1px solid slategray; */
  }

  .profiles> :first-child {
    border-top: none;
  }

  .profiles> :first-child>.row {
    border-top: none;
  }

  .profiles> :first-child>.row>.cell {
    border-top: none;
  }

  .row {
    page-break-inside: avoid;
  }

  .card-row {
    text-align: left;
  }

  .card-row .card-models .options::before {
    content: ": (";
  }

  .card-row .card-models .options::after {
    content: ")";
  }

  .card-row .card-models .models {
    padding-bottom: 5px;
  }

  .card-row .header.cell {
    padding: 5px;
    padding-left: 10px;
    background-color: rgba(70, 70, 70, 1);
    height: 100%;
  }

  .card-row .cell {
    display: table-cell;
  }

  .card-row .cell:not(.header) {
    border-left: 1px solid rgba(0, 60, 80, 1);
    vertical-align: middle;
  }

  .card-row .cell:not(.header)>span:not(:last-child)::after {
    content: ",";
  }

  .card-row .cell:not(.header)>* {
    margin-left: 5px;
    display: inline-block;
  }

  .card-header {
    padding: 3px;
    background-color: rgba(0, 60, 80, 1);
    position: relative;
    text-align: center;
  }

  .card-header .count {
    color: white;
    position: absolute;
    right: 15px;
    font-family: "Georgia";
  }

  .card-header .count::before {
    content: "x";
  }

  .card-header .name {
    color: white;
    text-align: center;
    text-transform: uppercase;
    font-family: Arial;
  }

  .card-header .custom-name {
    color: white;
    font-weight: bold;
    text-align: center;
    text-transform: uppercase;
    font-family: Arial;
  }

  .card-header .costs {
    color: white;
    position: absolute;
    text-transform: uppercase;
    left: 15px;
  }

  .card-header .costs .cost-type {
    margin-left: 3px;
  }

  .profile .name {
    white-space: nowrap;
  }

  .group {
    width: 100%;
    border-top: 1px solid rgba(0, 60, 80, 1);
  }

  .roster-rules {
    margin-top: 20px;
  }

  .section.roster-rules .rule-name,
  .section.unit-rules .rule-name {
    margin-top: 5px;
    font-weight: bold;
  }

  .section.roster-rules .rule-text,
  .section.unit-rules .rule-text {
    white-space: pre-wrap;
    white-space-collapse: preserve-breaks;
    text-wrap: wrap;
  }

  .section.roster-rules .force-name,
  .section.unit-rules .force-name {
    font-size: 24px;
  }

  .section.unit-rules .header {
    font-size: 24px;
    font-weight: bold;
  }

  .section.roster-rules .roster-rules-header {
    font-size: 24px;
    font-weight: bold;
  }

  .section.roster-rules .force {
    margin-top: 10px;
  }

  .nowrap {
    white-space: nowrap;
  }

  .rule-definitions,
  .rule-definition {
    page-break-inside: avoid;
    margin-top: 10px;
  }

  .page-break-avoid {
    page-break-inside: avoid;
  }

  .on-next-page {
    page-break-before: always;
  }

  td {
    padding: 0;
  }

  .data {
    font-size: calc(var(--fontSize, 20px) - 2px) !important;
  }

  .data ul {
    margin: 0;
    padding: 0;
    margin-left: 16px;
    list-style-position: outside;
    margin-bottom: -16px;
  }

  .data li {
    margin-top: -16px;
  }

  .data li:before {
    content: "";
    margin-left: -0.4rem;
  }

  .data p {
    margin: 0;
    padding: 0;
    display: inline;
  }

  .data del {
    margin: 0;
    padding: 0;
    display: inline;
  }

  .note {
    color: gray;
    white-space: pre-wrap;
  }

  .data * td {
    border: 1px solid gray;
    padding: 2px;
  }

  .data * th {
    font-weight: bold;
  }

  .rules-block:not(:has(.rule)) {
    display: none !important;
  }

  .rules {
    padding: 8px;
    border: 2px solid rgba(0, 60, 80, 1);

    margin-bottom: 32px;
  }

  .rule:not(:last-child),
  .force:not(:last-child) {
    margin-bottom: 10px;
  }

  .rule-name {

    white-space: nowrap;
    font-weight: 700;
    display: block;
  }

  .rule-name:not(:last-child)::after {
    content: ": ";
  }

  .force-name {
    white-space: nowrap;
    font-weight: 800;
  }

  .force-catalogue {
    color: gray;
    font-weight: 500;
  }

  .nested {
    margin-left: 5px
  }
</style>`,Md=`<template>      
<set name="ruleProfiles" value="special rule"/>
<!-- Rules -->
<profiles skip-forces="false" grouped="true" sort="true" amount="false">
  <div type="card">
  <table>
  <items max="1">
    <tr>
      <th>{{typeName}}</th>
      <characteristics> 
        <if field="length" type="not-equals" value="1">
        <th>{{name}}</th> 
        </if>
      </characteristics>
    </tr>
  </items>
  <items>
    <tr class="removable">
      <characteristics>
        <if field="length" type="equals" value="1">
          <td class="name">
            <span class="profile-name">{{item.name}}</span>
            <span class="data" type="markdown">{{value}}</span>
          </td>
        </if>
      </characteristics>
      <else>
        <td class="name">
          <span class="profile-name">{{item.name}}</span>
        </td>
        <characteristics> 
          <td class="data" type="markdown">{{value}}</td> 
        </characteristics>
      </else>
    </tr>
  </items>
  </table>
  </div>
</profiles>
</template>
<style>
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,100..900;1,100..900&display=swap');
ol,ul,menu {
  margin: 0;
  padding-left: 18px;
  margin-bottom: -18px;
}
th, td {
  text-align: left;
  border: 1px solid #32435560;
  padding: 3px 5px;
}
th {
  font-weight: 700;
  text-transform: uppercase;
  background-color: #324355;
  color: white;
}
table {
  border-collapse: collapse;
  width: 100%;
  padding: 8px;
  background-color: rgb(238, 238, 240);
  border: 2px solid #324355;
  margin-bottom: 12px;
}
.name {
  font-weight: 600;
}
.data {
  font-weight: 400;
}
.profile-name:has(+.data)::after {
  content: ": ";
}
.profile-name {
  white-space: nowrap;
}
html {
  font-family: Noto Sans, sans-serif, Inter, system-ui, Avenir, Helvetica, Arial, sans-serif;
  line-height: 1.5;
  font-weight: 400;
  font-size: 13px;
  color-scheme: light dark;
  color: #111113;
  background-color: #fff;
  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  -webkit-text-size-adjust: 100%;
}
* {
  box-sizing: border-box;
  print-color-adjust: exact;
  -webkit-print-color-adjust: exact
}
body { 
  margin: 10px;  
} 
</style>
`,Id=`<template>
  <stratagems class="test_class">
    <div class="container avoid-page-break">
      <div class="name">{{ stratagem.name }}</div>
      <div class="stratagem">
        <if field="turn" type="match" value="Either.*">
          <set-attribute name="class" value="stratagem eitherTurn" in=".stratagem"></set-attribute>
        </if>
        <else-if field="turn" type="match" value="Opponent.*">
          <set-attribute name="class" value="stratagem opponentTurn" in=".stratagem"></set-attribute>
        </else-if>
        <else-if field="turn" type="match" value="Your.*">
          <set-attribute name="class" value="stratagem playerTurn" in=".stratagem"></set-attribute>
        </else-if>
        <script>
          <![CDATA[
                  cleanedDescription = stratagem.description.replace(/(<br>\\s*)+/gi, '<br>');
                  ]]>
        <\/script>
        <div class="description" type="html">{{cleanedDescription}}</div>
        <div class="strDiamondWrapWrap">
          <div class="strDiamondWrap">
            <if field="phase" type="match" value="Any.*">
              <div class="strDiamond">
                <div class="stratagemIcon strAny"></div>
              </div>
            </if>
            <if field="phase" type="match" value=".*ommand.*">
              <div class="strDiamond">
                <div class="strCommand stratagemIcon"></div>
              </div>
            </if>
            <if field="phase" type="match" value=".*ovement.*">
              <div class="strDiamond">
                <div class="strMovement stratagemIcon"></div>
              </div>
            </if>
            <if field="phase" type="match" value=".*hooting.*">
              <div class="strDiamond">
                <div class="strShooting stratagemIcon"></div>
              </div>
            </if>
            <if field="phase" type="match" value=".*arge.*">
              <div class="strDiamond">
                <div class="strCharge stratagemIcon"></div>
              </div>
            </if>
            <if field="phase" type="match" value=".*ight.*">
              <div class="strDiamond">
                <div class="strFight stratagemIcon"></div>
              </div>
            </if>
            <div class="strDiamond">
              <div class="strCP">{{ stratagem.cp_cost }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </stratagems>
</template>
<style>
  @charset "UTF-8";
  @import url("https://cdn.jsdelivr.net/npm/notosans-fontface@1.3.0/css/notosans-fontface.min.css");

  html {
    font-family: "Noto Sans", sans-serif, Inter, system-ui, Avenir, Helvetica, Arial, sans-serif;
    background-color: white;
    scrollbar-width: thin;
    scrollbar-color: rgba(0, 0, 0, 0.3) rgba(0, 0, 0, 0);
    color: rgb(70, 70, 70);
  }

  .container {
    padding-left: 16px;
    margin-bottom: 20px;
  }

  .stratagem {
    border-top: 3px solid;
    border-left: 28px solid;
    border-top-left-radius: 5px;
    position: relative;
    padding-left: 20px;
  }

  .eitherTurn {
    border-top: 10px double;
  }

  .playerTurn {
    border-top: 5px solid;
  }

  .opponentTurn {
    border-top: 5px dotted;
  }

  .type {
    margin-top: px;
    border-bottom: 2px dotted $ box_border;
  }

  .description {
    border-bottom: 1px dotted $ box_border;
    padding-bottom: 0px;
  }

  .strDiamond {
    background: white;
    font-weight: bold;
    border: 3px solid;
    width: 40px;
    height: 40px;
    margin: auto;
    margin-top: 0px;
    display: flex;
    justify-content: center;
    align-items: center;
    transform: rotate(45deg);
  }

  .strDiamondWrapWrap {
    width: 45px;
    display: flex;
    flex-direction: column;
    margin-left: -37px;
    margin-top: -52px;
    position: absolute;
    top: 8px;
    left: 0;
  }

  .strName {
    margin-left: 69px;
    font-size: 1.54em;
    font-family:
      ConduitITC,
      charcoal,
      arial black;
    font-weight: bold;
    color: inherit;
    line-height: normal;
  }

  /* 24px: the largest square that fits inside the rotated 40px diamond */
  .stratagemIcon {
    width: 24px;
    height: 24px;
    transform: rotate(-45deg);
    background-size: contain;
    background-position: center;
    background-repeat: no-repeat;
  }

  /* Inlined copies of svg/Strat*.vue: the export runs outside Vue, so the icons cannot be components */
  .strAny {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cg fill='%23464646'%3E%3Cpath d='M20.14 7.3 A9.4 9.4 0 1 1 12 2.6 L12 5.2 A6.8 6.8 0 1 0 17.89 8.6 Z' /%3E%3Cpath d='M12 0.5 L12 7.3 L17 3.9 Z' /%3E%3Cpath d='M8.6 10.6 L10.9 12.9 L15.3 8.5 L17 10.2 L10.9 16.3 L6.9 12.3 Z' /%3E%3C/g%3E%3C/svg%3E");
  }

  .strCommand {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cg fill='%23464646'%3E%3Cpath fill-rule='evenodd' d='M12 5.8 A6.2 6.2 0 1 0 12 18.2 A6.2 6.2 0 1 0 12 5.8 Z M12 8.1 A3.9 3.9 0 1 0 12 15.9 A3.9 3.9 0 1 0 12 8.1 Z' /%3E%3Cpath transform='translate(12 12)' d='M-1.6 -6.6 L1.6 -6.6 L0 -11 Z' /%3E%3Cpath transform='translate(12 12) rotate(45)' d='M-1.6 -6.6 L1.6 -6.6 L0 -11 Z' /%3E%3Cpath transform='translate(12 12) rotate(90)' d='M-1.6 -6.6 L1.6 -6.6 L0 -11 Z' /%3E%3Cpath transform='translate(12 12) rotate(135)' d='M-1.6 -6.6 L1.6 -6.6 L0 -11 Z' /%3E%3Cpath transform='translate(12 12) rotate(180)' d='M-1.6 -6.6 L1.6 -6.6 L0 -11 Z' /%3E%3Cpath transform='translate(12 12) rotate(225)' d='M-1.6 -6.6 L1.6 -6.6 L0 -11 Z' /%3E%3Cpath transform='translate(12 12) rotate(270)' d='M-1.6 -6.6 L1.6 -6.6 L0 -11 Z' /%3E%3Cpath transform='translate(12 12) rotate(315)' d='M-1.6 -6.6 L1.6 -6.6 L0 -11 Z' /%3E%3C/g%3E%3C/svg%3E");
  }

  .strMovement {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cg fill='%23464646'%3E%3Cpath d='M12 1.8 L20.8 11.6 H16.4 V15.4 H7.6 V11.6 H3.2 Z' /%3E%3Cpath d='M7.6 16.6 H16.4 V18 H7.6 Z' /%3E%3Cpath d='M7.6 18.9 H16.4 V20.3 H7.6 Z' /%3E%3Cpath d='M7.6 21.2 H16.4 V22.6 H7.6 Z' /%3E%3C/g%3E%3C/svg%3E");
  }

  .strShooting {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cg fill='%23464646'%3E%3Cpath fill-rule='evenodd' d='M12 4.2 A7.8 7.8 0 1 0 12 19.8 A7.8 7.8 0 1 0 12 4.2 Z M12 7.4 A4.6 4.6 0 1 0 12 16.6 A4.6 4.6 0 1 0 12 7.4 Z' /%3E%3Cpath d='M10.5 1.6 H13.5 V7 H10.5 Z' /%3E%3Cpath d='M10.5 17 H13.5 V22.4 H10.5 Z' /%3E%3Cpath d='M1.6 10.5 H7 V13.5 H1.6 Z' /%3E%3Cpath d='M17 10.5 H22.4 V13.5 H17 Z' /%3E%3Ccircle cx='12' cy='12' r='2.4' /%3E%3C/g%3E%3C/svg%3E");
  }

  .strCharge {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cg fill='%23464646'%3E%3Cpath d='M12 3.75 L21 8.95 L21 13.8 L12 8.6 L3 13.8 L3 8.95 Z' /%3E%3Cpath d='M12 10.2 L21 15.4 L21 20.25 L12 15.05 L3 20.25 L3 15.4 Z' /%3E%3C/g%3E%3C/svg%3E");
  }

  .strFight {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cg fill='%23464646' transform='translate(12.9 13.1) rotate(-45)'%3E%3Cpath d='M-4.2 -11.9 H4.2 V-7.2 H-4.2 Z' /%3E%3Cpath d='M-1.4 -7.2 H1.4 V9.8 H-1.4 Z' /%3E%3C/g%3E%3Cg fill='%23464646' transform='translate(11.1 13.1) rotate(45)'%3E%3Cpath d='M-4.2 -11.9 H4.2 V-7.2 H-4.2 Z' /%3E%3Cpath d='M-1.4 -7.2 H1.4 V9.8 H-1.4 Z' /%3E%3C/g%3E%3C/svg%3E");
  }

  .strDiamondWrap {
    margin-top: 18px;
  }

  .strCP {
    font-size: 20px;
    transform: rotate(-45deg);
  }

  .name {
    font-weight: bold;
    font-size: 20px;
    margin-left: 50px;
  }

  .avoid-page-break {
    position: relative;
    page-break-inside: avoid;
    -moz-column-break-inside: avoid;
    break-inside: avoid;
  }
</style>
`,Hd=G({props:{result:{type:Object,required:!0},field:{type:String,required:!0},type:{type:String,required:!0},label:{type:String,required:!0},defaultValue:{type:[Boolean,Object],required:!1,default:void 0},premium:{type:Boolean,default:!1}},created(){this.result[this.field]===void 0&&(this.result[this.field]={}),xe(this.result[this.field])||(this.result[this.field]={state:this.result[this.field]})},methods:{toggle(e){const t=e.target;if(t.checked&&this.premium&&!this.$userStore.isSupporter()){t.checked=!1,this.$emit("premium");return}this.value=t.checked}},computed:{value:{get(){const e=this.result[this.field];return(e==null?void 0:e.state)===void 0&&this.defaultValue!==void 0?this.defaultValue:this.type==="toggle"?!!(e!=null&&e.state):e==null?void 0:e.state},set(e){(this.result[this.field]??={}).state=e,this.$emit("changed")}}}}),Ld={style:{padding:"3px"}},Td=["id","checked"],Od=["for"],Yd=["for"],Nd=["id"],Vd=["for"],jd=["id"],Wd=["for"],Xd=["id"];function zd(e,t,n,s,a,d){const l=$n;return i(),p("div",Ld,[["boolean","checkbox","toggle"].includes(e.type)?(i(),p(C,{key:0},[r("input",{id:e.field,type:"checkbox",checked:!!e.value,onChange:t[0]||(t[0]=(...u)=>e.toggle&&e.toggle(...u))},null,40,Td),t[4]||(t[4]=o()),r("label",{for:e.field},[o(m(e.label)+" ",1),e.premium?(i(),E(l,{key:0,class:"premium-icon",size:13})):h("",!0)],8,Od)],64)):["number","numeric","int"].includes(e.type)?(i(),p(C,{key:1},[r("label",{for:e.field},m(e.label),9,Yd),t[5]||(t[5]=o(`:
      `,-1)),P(r("input",{id:e.field,type:"number","onUpdate:modelValue":t[1]||(t[1]=u=>e.value=u),style:{"max-width":"60px","max-height":"30px"}},null,8,Nd),[[q,e.value]])],64)):e.type==="color"?(i(),p(C,{key:2},[r("label",{for:e.field},m(e.label),9,Vd),t[6]||(t[6]=o()),P(r("input",{id:e.field,type:"color","onUpdate:modelValue":t[2]||(t[2]=u=>e.value=u)},null,8,jd),[[q,e.value]])],64)):["text","string"].includes(e.type)?(i(),p(C,{key:3},[r("label",{for:e.field},m(e.label),9,Wd),t[7]||(t[7]=o()),P(r("input",{id:e.field,type:"text","onUpdate:modelValue":t[3]||(t[3]=u=>e.value=u)},null,8,Xd),[[q,e.value]])],64)):h("",!0)])}const Zd=Object.assign(Q(Hd,[["render",zd]]),{__name:"ListsPrettyPreviewOption"}),Kd=G({components:{PreviewOption:Zd},name:"PreviewOptions",props:{options:{type:Object,required:!0},result:{type:Object,required:!0}},methods:{istoggled(e){var t;return this.result&&((t=this.result[e])==null?void 0:t.state)},changed(){this.$emit("changed",this.result)},changedChild(){this.changed()},type(e){return e!=null&&e.type?e==null?void 0:e.type:e!=null&&e.fields?"toggle":"boolean"}},computed:{fields(){return this.options.fields?Object.entries(this.options.fields).map(([e,t])=>({field:e,options:t})):[]}}}),Jd={key:0,style:{"margin-left":"10px"}};function qd(e,t,n,s,a,d){const l=R("PreviewOption"),u=R("PreviewOptions",!0);return i(),p("div",null,[(i(!0),p(C,null,D(e.fields,({field:g,options:c})=>(i(),p("div",null,[w(l,{field:g,type:e.type(c),result:e.result,label:c.label,onChanged:t[0]||(t[0]=x=>e.changedChild()),defaultValue:c.default,premium:!!c.premium,onPremium:t[1]||(t[1]=x=>e.$emit("premium"))},null,8,["field","type","result","label","defaultValue","premium"]),t[4]||(t[4]=o()),e.istoggled(g)?(i(),p("div",Jd,[w(u,{options:c,result:e.result[g],onChanged:t[2]||(t[2]=x=>e.changedChild()),onPremium:t[3]||(t[3]=x=>e.$emit("premium"))},null,8,["options","result"])])):h("",!0)]))),256))])}const pn=Object.assign(Q(Kd,[["render",qd]]),{__name:"ListsPrettyPreviewOptions"}),_d=`<template>
<div>
<units>
<div class="unit" type="card">
  <span class="name">{{name}}</span>
  <costs><span class="cost">{{name}}: {{value}}</span></costs>
  <profiles grouped="true">
  <div class="indent">
    <items max="1"><span class="type">{{typeName}}</span></items>
    <items>
    <div class="profile indent">
      <span>{{name}}</span>
      <characteristics>
      <if field="value"><span class="stat">{{name}} <strong type="markdown">{{value}}</strong></span></if>
      </characteristics>
    </div>
    </items>
  </div>
  </profiles> 
  <div class="indent">
    <rules><span class="rule">{{name}}</span></rules>
  </div>
</div>
</units>
</div>
</template>
<style>
* { font-family: sans-serif; }
.unit { border: 1px solid black; padding: 10px; margin-top: -1px; }
.name { font-weight: bold; }
.cost, .stat { background-color: rgba(0,0,0,0.1); padding: 0 4px; border-radius: 6px; }
.stat:has(+.stat) { margin-right: 3px; }
.rule:has(+.rule)::after { content: " "; }
.rule:first-child::before { content: "Rules: "; }
.indent { margin-left: 20px; }
</style>`;function kt(e){for(const t of e.styleSheets){let n;try{n=t.cssRules||t.rules}catch{continue}for(let s=0;s<n.length;s++){const a=n[s];a.type===CSSRule.MEDIA_RULE&&a.media.mediaText==="screen"?a.media.mediaText="print":a.type===CSSRule.MEDIA_RULE&&a.media.mediaText==="print"&&(a.media.mediaText="screen")}}}function ep(e,t){function n(u){if(!u||u.nodeType!==Node.ELEMENT_NODE||["STYLE","SCRIPT","TEMPLATE"].includes(u.tagName))return;window.getComputedStyle(u).display==="none"&&u.setAttribute("display","none"),Array.from(u.children).forEach(n)}function s(u){!u||u.nodeType!==Node.ELEMENT_NODE||["STYLE","SCRIPT","TEMPLATE"].includes(u.tagName)||(u.getAttribute("display")==="none"&&u.removeAttribute("display"),Array.from(u.children).forEach(n))}function a(u){if(u.getAttribute("display")==="none")return u.remove();Array.from(u.children).forEach(a)}kt(e),n(e.documentElement),kt(e);const d=e.documentElement.cloneNode(!0);s(e.documentElement),a(d);const l=d.innerHTML;l&&Nt(`${t}.html`,"text/html;charset=utf-8",`<!DOCTYPE html>
<html>
${l}
</html>`)}const tp=G({emits:["ready"],data:()=>({loading:!1,selected:null,template_string:null,html:null,optionsOpen:!1,editing:!1,config:{},settings:{},templates:[],fileHandle:null,fileLastModified:0,interval:null}),props:{roster:{type:Be,required:!0}},components:{PreviewOptions:pn},async mounted(){this.refresh()},async unmounted(){this.interval&&clearInterval(this.interval)},computed:{output(){if(this.template_string)return Gd(this.template_string,{roster:Ae(this.roster),config:this.config,settings:this.settings,system:this.system,figurinesStore:this.$figurineStore,userStore:this.$userStore})},editable(){var e;return(e=this.selected)==null?void 0:e.editable},default_template(){return _d},system(){return this.roster.getBook().getSystem()??this.roster.source.getCatalogue().getGameSystem()},showNonExportableWarning(){return et(this.roster)}},methods:{settingsChanged(e){var t;(t=this.selected)!=null&&t.name&&this.save_settings(this.selected.name,e)},save_settings(e,t){var d,l;const n=((d=globalThis.localStorage)==null?void 0:d.getItem("export-template-settings"))||"{}",a={...JSON.parse(n),[e]:t};(l=globalThis.localStorage)==null||l.setItem("export-template-settings",JSON.stringify(a))},load_settings(e){var s;if(!e)return{};const t=((s=globalThis.localStorage)==null?void 0:s.getItem("export-template-settings"))||"{}";return JSON.parse(t)[e]??{}},async refresh(){const e=[{name:"40K Cards",template:Ud},{name:"Profile Tables",template:Md},{name:"AoS4 Cards",template:Bd,supportedSystems:["bc33-05f5-8d3f-af43","Age of Sigmar 4.0"]},{name:"Pretty Cards",template:$d},{name:"Pretty Cards (Dark)",template:Rd},{name:"Stratagems",template:Id,premium:!0,supportedSystems:["sys-352e-adc2-7639-d6a9","Warhammer 40,000 10th Edition","sys-352e-adc2-7639-d610","Warhammer 40,000 11th Edition"]},{name:"Classic",template:Qd}],t=[this.system.name,this.system.id,this.system.bsid,this.system.short].filter(s=>s),n=e.filter(s=>{var a;return!((a=s.supportedSystems)!=null&&a.length&&!s.supportedSystems.some(d=>t.includes(d))||s.premium&&!this.$userStore.isSupporter())});await Ce.templates.each(s=>{n.push({...s,editable:!0})}),this.templates=n},select(e){this.selected=e},print(){var e;try{const t=this.$refs.frame;if(!(t!=null&&t.isConnected))return;if(globalThis.Capacitor&&globalThis.Capacitor.isNativePlatform()&&t.contentWindow){const n=t.contentWindow.document.documentElement.outerHTML;Yt.printHtml({html:n,name:this.roster.getName()})}return(e=t.contentWindow)==null?void 0:e.print()}catch(t){console.warn("Could not print the preview frame",t)}},can_create_file(){return typeof window.showSaveFilePicker=="function"},can_open_file(){return typeof window.showOpenFilePicker=="function"},async sync_template(e){try{if(e){const t=await window.showSaveFilePicker({suggestedName:"template.html",types:[{description:"Text Files",accept:{"text/plain":[".html"]}}]}),n=await t.createWritable();await n.write(this.template_string||`<template></template>
<style></style>`),await n.close(),this.fileHandle=t}else[this.fileHandle]=await window.showOpenFilePicker()}catch(t){(t==null?void 0:t.name)==="AbortError"?console.warn("Template file pick cancelled"):console.error("Failed to sync template with file",t)}},async sync_file(){if(this.fileHandle)try{const e=await this.fileHandle.getFile();e.lastModified>this.fileLastModified&&(this.template_string=await e.text(),this.fileLastModified=e.lastModified,this.save_template())}catch(e){showMessage(e),this.fileHandle=null}},async save_template(){var e;if((e=this.selected)!=null&&e.name)Ce.templates.put({name:this.selected.name,template:this.template_string||""});else{const t=await prompt(this.$referenceStore.getString("export_template_name_prompt"));if(t){const n={name:t,template:this.template_string||""};await Ce.templates.put(n),await this.refresh(),this.selected=n}}},edit_template(){this.editing=!0},async delete_template(){if(this.selected&&await customConfirm(this.$referenceStore.getString("export_confirm_delete_template"))){const e=this.selected.id??this.selected.name;Ce.templates.delete(e),await this.refresh(),this.selected=null}},save(){var t;const e=(t=this.$refs.frame)==null?void 0:t.contentDocument;if(e)return ep(e,this.roster.getName())}},watch:{template_string:{immediate:!0,handler(e){this.$emit("ready",e!=null)}},output(e){const t=(e==null?void 0:e.html)??"";this.html&&this.$refs.frame?this.$refs.frame.srcdoc=t:this.html=t},fileHandle(e){this.interval&&(clearInterval(this.interval),this.interval=null),this.interval=us(this.sync_file,100),this.fileLastModified=0},selected:{immediate:!0,handler(e){if(e===null){this.template_string=null;return}const t=e.id??e.name;this.config={fields:{oneCardPerPage:{label:"One Card per Page",type:"boolean",default:!1}}},this.settings=this.load_settings(e.name),this.html=null;try{const n=this.templates.find(s=>s.id===t)??this.templates.find(s=>s.name===t);if(n)return this.template_string=typeof n.template=="function"?n.template():n.template}catch{this.template_string="<template>String(e)</template>";return}this.template_string="<template>No template selected</template>"}}}}),np={style:{width:"calc(100vw - (10px + var(--safe-area-inset-right, 0px) + var(--safe-area-inset-right, 0px)))",height:"calc(100vh - (60px + var(--safe-area-inset-top, 0px) + var(--safe-area-inset-bottom, 0px)))","max-width":"1020px"}},sp={key:0,class:"non-exportable-warning printer-hidden"},op={key:1,style:{"margin-top":"20px"}},rp=["onClick"],ip={key:0},ap=["srcdoc"],lp={key:0,class:"printer-hidden gear-position"},dp={key:1,class:"preview-options printer-hidden popup gear-position"},pp={style:{display:"flex",gap:"10px"}},up={style:{margin:"auto","font-weight":"bold"}};function cp(e,t,n,s,a,d){const l=ye,u=ze,g=R("PreviewOptions");return i(),p("div",null,[r("div",np,[e.showNonExportableWarning?(i(),p("div",sp,m(e.$referenceStore.getString("no_exportable_units_warning")),1)):h("",!0),t[24]||(t[24]=o()),e.template_string===void 0||e.template_string===null?(i(),p("div",op,[r("div",null,m(e.$referenceStore.getString("export_select_template"))+":",1),t[9]||(t[9]=o()),(i(!0),p(C,null,D(e.templates,c=>(i(),p("div",{onClick:x=>e.select(c),class:"clickable hover-darken",style:{padding:"10px",border:"1px solid black","margin-top":"-1px"}},[r("span",null,m(c.name),1)],8,rp))),256)),t[10]||(t[10]=o()),r("div",{onClick:t[0]||(t[0]=c=>{e.template_string=e.default_template,e.edit_template()}),class:"clickable hover-darken",style:{padding:"10px",border:"1px solid black","margin-top":"-1px"}},[r("span",null,m(e.$referenceStore.getString("export_create_template")),1)])])):(i(),p(C,{key:2},[r("b",null,m(e.$referenceStore.getString("export_output_html"))+":",1),t[21]||(t[21]=o()),e.editing?(i(),p("div",ip,[r("span",null,[o(m(e.$referenceStore.getString("export_template_docs"))+" ",1),t[11]||(t[11]=r("a",{href:"https://github.com/giloushaker/nr-templates",target:"_blank"}," github.com/giloushaker/nr-templates ",-1))]),t[12]||(t[12]=o()),e.fileHandle?h("",!0):(i(),E(l,{key:0,modelValue:e.template_string,"onUpdate:modelValue":t[1]||(t[1]=c=>e.template_string=c),style:{"max-height":"500px",overflow:"auto",resize:"both"},spellcheck:"false"},null,8,["modelValue"]))])):h("",!0),t[22]||(t[22]=o()),r("iframe",{class:"printable",style:{border:"none","margin-left":"auto","margin-right":"auto",width:"100%",height:"calc(100% - 4px)"},srcdoc:e.html??void 0,ref:"frame"},null,8,ap),t[23]||(t[23]=o()),Object.keys(e.config).length||e.editable||e.editing?(i(),p(C,{key:1},[e.optionsOpen?(i(),p("div",dp,[r("div",pp,[r("span",up,m(e.$referenceStore.getString("options")),1),t[14]||(t[14]=o()),r("button",{class:"inputstyle",style:{width:"28px",height:"28px",float:"right"},onClick:t[3]||(t[3]=c=>e.optionsOpen=!e.optionsOpen)},[...t[13]||(t[13]=[r("span",{style:{"text-align":"center","vertical-align":"middle","font-size":"22px"}}," × ",-1)])])]),t[15]||(t[15]=o()),r("div",null,[w(g,{options:e.config,result:e.settings,onChanged:e.settingsChanged},null,8,["options","result","onChanged"])]),t[16]||(t[16]=o()),e.editing?(i(),p("button",{key:0,class:"bouton",style:{display:"block"},onClick:t[4]||(t[4]=(...c)=>e.save_template&&e.save_template(...c))},m(e.$referenceStore.getString("export_save_template")),1)):h("",!0),t[17]||(t[17]=o()),e.editing&&e.can_create_file?(i(),p("button",{key:1,class:"bouton",style:{display:"block"},onClick:t[5]||(t[5]=c=>e.sync_template(!0))},m(e.$referenceStore.getString("export_sync_new_file")),1)):h("",!0),t[18]||(t[18]=o()),e.editing&&e.can_open_file?(i(),p("button",{key:2,class:"bouton",style:{display:"block"},onClick:t[6]||(t[6]=c=>e.sync_template(!1))},m(e.$referenceStore.getString("export_sync_existing_file")),1)):h("",!0),t[19]||(t[19]=o()),e.editable&&!e.editing?(i(),p("button",{key:3,class:"bouton",style:{display:"block"},onClick:t[7]||(t[7]=(...c)=>e.edit_template&&e.edit_template(...c))},m(e.$referenceStore.getString("export_edit_template")),1)):h("",!0),t[20]||(t[20]=o()),e.editable&&!e.editing?(i(),p("button",{key:4,class:"bouton",style:{display:"block"},onClick:t[8]||(t[8]=(...c)=>e.delete_template&&e.delete_template(...c))},m(e.$referenceStore.getString("export_delete_template")),1)):h("",!0)])):(i(),p("div",lp,[r("button",{class:"inputstyle",style:{float:"right"},onClick:t[2]||(t[2]=c=>e.optionsOpen=!e.optionsOpen)},[w(u,{class:"icon",style:{padding:"1px","vertical-align":"center"}})])]))],64)):h("",!0)],64))])])}const Ve=Object.assign(Q(tp,[["render",cp],["__scopeId","data-v-b3f4161f"]]),{__name:"ListsPrettyExportTemplate"}),gp=".t9acss .ruleList{display:inline}.t9acss .statTable{border:1px solid #ccc;border-top:none;font-family:serif;padding-right:5px}.t9acss .statTable table{width:100%}.t9acss table td{border:none;min-width:35px;padding:0}.t9acss h4{margin-bottom:0}.t9acss .statNames td{padding-top:10px}.t9acss .statNames{border-top:1px solid #ccc;color:var(--color-gray);font-size:14px;font-style:italic}.t9acss .statNames td.titleTd{min-width:100px;padding-left:10px;text-align:left}.t9acss .modelRules{text-align:left}.t9acss .onlySmall,.t9acss .smallModelRules{display:none}@media screen and (max-width:770px){.t9acss table td:last-child{display:none}.t9acss table td:last-child.smallScreen{display:table-cell;text-align:left}.t9acss .onlySmall{display:table-row}.t9acss .onlySmall td{padding-bottom:5px}.t9acss .smallModelRules{display:block}}@media screen and (max-width:335px){.t9acss table td{min-width:30px}}@media screen and (max-width:310px){.t9acss table td{min-width:0}}.t9acss .typeSize{font-weight:400!important}.t9acss .typeSize a{color:var(--font-color)}.t9acss .typeSize{font-size:16px}.t9acss .cam{cursor:pointer;margin-bottom:2px;margin-left:10px}.t9acss .mod{color:#2262d8}.t9acss .mod.conditional{color:green}.t9acss .statValues{font-weight:700;padding-bottom:10px;padding-top:10px}.t9acss .statValues.modelRules{font-weight:400!important;padding-left:10px;text-align:left}.t9acss .statValues.offenseName{font-weight:400;text-align:left}.t9acss .selectable{vertical-align:middle}.t9acss .ruleLink{font-weight:400!important}",fp='@charset "UTF-8";.table,table{border-collapse:collapse}@font-face{font-family:CustomTahoma;font-style:normal;font-weight:400;src:local("Tahoma"),url(https://www.newrecruit.eu/Tahoma.ttf) format("truetype")}@font-face{font-family:CustomTahoma;font-style:normal;font-weight:700;src:local("Tahoma Bold"),url(https://www.newrecruit.eu/TahomaBold.ttf) format("truetype")}html{background-color:#fff;color:#464646;font-family:CustomTahoma,sans-serif;scrollbar-color:rgba(0,0,0,.3) transparent;scrollbar-width:thin}html.dark{scrollbar-color:hsla(0,0%,100%,.3) transparent}@media print{.print-display-none,.print-display-none *{display:none!important}}.card .cost,.table .cost{margin-left:6px}.card .cost-value-0,.table .cost-value-0{display:none}.cost-type{margin-left:1px}.roster-header{margin-left:auto;margin-right:auto;text-align:center}a{color:unset;text-decoration:none}.force-catalogue{color:gray}.forces .force{margin-bottom:20px;-moz-column-break-inside:avoid;break-inside:avoid;-webkit-print-color-adjust:exact;print-color-adjust:exact}@media not print{.forces .force{margin-left:auto;margin-right:auto}}.forces .custom-name{font-weight:700}.options+.profile-group{margin-top:10px}.options-profiles-group-header,.unit-categories-header{content:": ";font-weight:700}.options-profiles-group-header:after,.unit-categories-header:after{content:": "}.options-profiles-name:not(:last-child):after,.unit-category-name:not(:last-child):after{content:", ";white-space:break-spaces}.options-profiles-name,.unit-category-name{display:inline-block}.section:empty{display:none}.section.table .costs{margin-left:4px}.section.table .cell:not(.header){border:1px solid #d3d3d3;padding:5px;text-align:left;vertical-align:middle}.section.table>:nth-child(2n){background-color:#3328280d}.section.table .header.cell{border-bottom:2px solid #000;font-family:Constantia;font-weight:700;padding-right:8px;text-transform:uppercase}.section.roster-header .costs{margin-left:4px}.section.roster-header .force{display:table}.section.config .costs{margin-left:4px}.section.config .unit:before{content:"• "}.section.config .unit .name:after{content:": "}.section.cards .header.cell{background-color:#0000001a}.section.cards .unit{width:min(1000px,100%)}.section.cards .t9aprofile{margin-left:10px}.section.cards .card:before{background:#789;clip-path:polygon(0 12px,12px 0,calc(100% - 12px) 0,100% 12px,100% calc(100% - 12px),calc(100% - 12px) 100%,12px 100%,0 calc(100% - 12px),0 12px,2px 12.83px,2px calc(100% - 12.83px),12.83px calc(100% - 2px),calc(100% - 12.83px) calc(100% - 2px),calc(100% - 2px) calc(100% - 12.83px),calc(100% - 2px) 12.83px,calc(100% - 12.83px) 2px,12.83px 2px,2px 12.83px);content:"";top:0;right:0;bottom:0;left:0;position:absolute}.section.cards .card{border-bottom:2px solid #789;clip-path:polygon(0 12px,12px 0,calc(100% - 12px) 0,100% 12px,100% calc(100% - 12px),calc(100% - 12px) 100%,12px 100%,0 calc(100% - 12px));width:100%}.section.cards .card-wrapper{font-size:small;margin-left:auto;margin-right:auto;position:relative;-webkit-print-color-adjust:exact;print-color-adjust:exact;-moz-column-break-inside:avoid;border-collapse:collapse;break-inside:avoid;display:table;margin-bottom:10px}.section.cards .profile>.cell{padding:2px 5px}.section.cards .profile>.cell:not(.header){border:1px solid #e5e5e5;border-top:none;white-space:break-spaces}.section.cards .profile.header>.cell{border:none;border-top:1px solid #708090;white-space:nowrap}.section.cards .profiles>:first-child,.section.cards .profiles>:first-child>.row,.section.cards .profiles>:first-child>.row>.cell{border-top:none}.section.cards .row{page-break-inside:avoid}.section.cards .card-row{text-align:left}.section.cards .card-row .card-models .options:before{content:": ("}.section.cards .card-row .card-models .options:after{content:")"}.section.cards .card-row .card-models .models{padding-bottom:5px}.section.cards .card-row .header.cell{background-color:#0000001a;height:100%;padding:5px 5px 5px 10px}.section.cards .card-row .cell{display:table-cell}.section.cards .card-row .cell:not(.header){border-left:1px solid #789;vertical-align:middle}.section.cards .card-row .cell:not(.header)>span:not(:last-child):after{content:","}.section.cards .card-row .cell:not(.header)>*{display:inline-block;margin-left:5px}.section.cards .card-header{background-color:#708090;padding:3px;position:relative;text-align:center}.section.cards .card-header .count{color:#fff;font-family:Georgia;position:absolute;right:15px}.section.cards .card-header .count:before{content:"x"}.section.cards .card-header .custom-name,.section.cards .card-header .name{color:#fff;font-family:Arial;text-align:center;text-transform:uppercase}.section.cards .card-header .custom-name{font-weight:700}.section.cards .card-header .costs{color:#fff;left:15px;position:absolute;text-transform:uppercase}.section.cards .card-header .costs .cost-type{margin-left:3px}.section.cards .profile .name{white-space:nowrap}.section.cards .group{border-top:1px solid #708090;width:100%}.section.cards .data{text-wrap:wrap;white-space:pre-wrap;white-space-collapse:preserve-breaks}.roster-rules{margin-top:20px}.section.roster-rules .rule-name,.section.unit-rules .rule-name{font-weight:700;margin-top:5px}.section.roster-rules .rule-text,.section.unit-rules .rule-text{text-wrap:wrap;white-space:pre-wrap;white-space-collapse:preserve-breaks}.section.roster-rules .force-name,.section.unit-rules .force-name{font-size:24px}.section.unit-rules .header{font-size:24px;font-weight:700}.section.unit-rules .force-rule{margin-left:10px}.section.unit-rules .force{margin-top:10px}.section.roster-stratagems .header{font-size:24px;font-weight:700}.section.roster-stratagems .stratagem-group-name{font-size:20px;margin-top:15px}.section.roster-stratagems .stratagem-definition{margin-left:10px;margin-top:10px;page-break-inside:avoid}.section.roster-stratagems .stratagem-name{font-weight:700}.section.roster-stratagems .stratagem-cost:before{content:" - "}.section.roster-stratagems .stratagem-type,.section.roster-stratagems .stratagem-when{color:gray}.preview>*>*{margin-bottom:10px}.nowrap{white-space:nowrap}.rule-definition,.rule-definitions{page-break-inside:avoid;margin-top:10px}.page-break-avoid{page-break-inside:avoid}.page-break-after{page-break-after:always}.on-next-page,.page-break-before{page-break-before:always}td{padding:0}.data{font-size:calc(var(--fontSize, 16px) - 2px)!important;text-wrap:wrap;white-space:pre-wrap;white-space-collapse:preserve-breaks}.data ul{list-style-position:outside;margin:0 0 -16px 16px;padding:0}.data li{margin-top:-16px}.data li:before{content:"";margin-left:-.4rem}.data del,.data p{display:inline;margin:0;padding:0}.note{color:gray;white-space:pre-wrap}.data * td{border:1px solid gray;padding:2px}.data * th{font-weight:700}@media print{body{margin-bottom:0;margin-top:0}}pre{white-space:pre-wrap}.profile:not(.header){cursor:pointer}.crossed,.crossed *{text-decoration:line-through}@media print{.profile-group:not(:has(.profile:not(.header):not(.crossed))),.profile-row:has(.profile-group):not(:has(.profile:not(.header):not(.crossed))){display:none}}';function mp(e,t){if(t.include){const n=t.include;for(const s of n)s instanceof RegExp?e=e.filter(a=>a.getName().trim().match(s)):e=e.filter(a=>a.getName().trim().toLowerCase()===s)}if(t.exclude){const n=t.exclude;for(const s of n)s instanceof RegExp?e=e.filter(a=>!a.getName().trim().match(s)):e=e.filter(a=>a.getName().trim().toLowerCase()!==s)}if(t.order){const n=t.order;e=_(e,s=>{const a=n.indexOf(s.getName());return a===-1?n.length:a})}return e}function un(e){const t=new Set,n=[];for(const s of e){const a=`${s.name.toLowerCase()}|${(s.detachment??"").toLowerCase().trim()}`;t.has(a)||(t.add(a),n.push(s))}return n}function rt(e,t){var d,l;if(!t)return null;const n=(l=(d=e.getBook)==null?void 0:d.call(e))==null?void 0:l.getSystem();if(!n)return null;const s=V(n);if(!s.hasStratagems())return null;const a=s;return{func:a,detachment:a.getRosterDetachment(e)}}function cn(e,t){return un(t.flatMap(n=>e.func.getUnitStratagems(e.detachment,n)))}function hp(e,t){const n=new Set(t.getForces(!0).map(s=>{var a;return(a=s.getBook())==null?void 0:a.getOriginalName()}));return un([...n].flatMap(s=>e.func.getDetachmentStratagems(e.detachment,s)))}const xp=G({props:{opt:{type:Object,required:!0},config:{type:[Boolean,Object],required:!0},options:{type:Object,required:!0}},computed:{stratagemContext(){var e;return(e=this.options.forces)!=null&&e.includeStratagems?rt(this.opt,this.$userStore.isSupporter()):null}},methods:{ist9a(e){return e.getBook().getSystem().engine==="t9a"},data(){var t,n;const e=[];for(const s of this.opt.getForces().filter(a=>a.isExportable())){const a=[],d=this.options.commonCosts;for(const g of me(s.getCategories().filter(c=>c.isExportable()),{exclude:this.options.excludeConfigs})){const c=ue(g.getUnits().filter(y=>y.isExportable()),{flatten:!this.ist9a(g)}),x=[];for(const y of c){const b=this.ist9a(y)?y.calcOptionsList():dt(y,{constants:(t=this.options.forces)==null?void 0:t.includeConstantOptions,exclude:["Number"],modelOnNewLine:!0,trim:!0,costs:((n=this.options.forces)==null?void 0:n.includeOptionsCost)===!1?!1:{before:"[",after:"]",between:" / "}}),f={};y.calcTotalCosts().filter(S=>d.find(W=>S.name.toLowerCase().includes(W))).forEach(S=>f[S.name]=S.value);let v=[];y.getAllModifiedProfiles&&(v=ee(y.getAllModifiedProfiles(),{order:["unit","model","stats","weapon","psychic power","psyker"],grouped:!0}));const F=[...new Set([y.getParentCategory().getName(),...y.getAllSecondaries()])],A=this.stratagemContext?cn(this.stratagemContext,[y]):[];x.push({source:y,options:b,costs:f,modelCount:y.calcTotalUnitSize(),profiles:v,secondaries:F,stratagems:A})}a.push({source:g,units:x})}const l=new Set;for(const g of a)for(const c of g.units)for(const x in c.costs)l.add(x);for(const g of a)for(const c of g.units)for(const x of l)c.costs[x]=c.costs[x]??0;const u=[];for(const g of me(s.getCategories(),{include:this.options.excludeConfigs})){const c={constants:!0,units:!1,costs:{before:"[",after:"]",between:" / "}};u.push({source:g,units:g.getUnits().map(x=>({source:x,options:dt(x,c)}))})}e.push({source:s,categories:a,allCosts:[...l],configuration:u})}return e}}}),bp={class:"page-break-after"},yp={key:0},vp={key:0,class:"name"},wp={key:1,class:"name"},Cp={key:2,class:"costs"},Ep={class:"catalogue force-catalogue"},Fp={class:"name"},kp={key:1},Dp={key:0},Ap=["innerHTML"],Pp={key:2,class:"section table"},Sp={class:"header unit"},Gp={key:0,class:"cell header cost"},Bp={class:"cell header cost"},Qp={class:"cell"},Up={key:0,class:"model-count"},$p={class:"custom-name bold"},Rp={class:"name"},Mp={key:0,class:"cell"},Ip={class:"cell"},Hp={class:"cell"},Lp=["innerHTML"],Tp={class:"unit-categories-header header name"},Op={class:"options-profiles-name"},Yp={key:1},Np={class:"options-profiles-name"},Vp={key:2},jp={class:"options-profiles-name"};function Wp(e,t,n,s,a,d){return i(),p("div",bp,[(i(!0),p(C,null,D(e.data(),l=>{var u,g,c,x;return i(),p(C,null,[(u=e.options.forces)!=null&&u.includeHeader?(i(),p("div",yp,[l.source.getCustomName()?(i(),p("span",vp,m(l.source.getCustomName()),1)):(i(),p("span",wp,m(l.source.getName()),1)),t[2]||(t[2]=o()),l.source.calcTotalCosts().length?(i(),p("span",Cp,[t[0]||(t[0]=o(`
          [`,-1)),(i(!0),p(C,null,D(l.source.calcTotalCosts(),(y,b)=>(i(),p("span",null,m(b?", ":"")+m(y.value)+" "+m(y.name),1))),256)),t[1]||(t[1]=o(`]
        `,-1))])):h("",!0),t[3]||(t[3]=o()),r("span",Ep,[r("span",Fp,"("+m(l.source.getBook().getName())+")",1)])])):h("",!0),t[26]||(t[26]=o()),(g=e.options.forces)!=null&&g.includeConfig?(i(),p("div",kp,[(i(!0),p(C,null,D(l.configuration,y=>(i(),p(C,null,[(i(!0),p(C,null,D(y.units,b=>(i(),p("div",null,[t[5]||(t[5]=o(`
            • `,-1)),r("span",null,m(b.source.getName()),1),b.options?(i(),p("span",Dp,[t[4]||(t[4]=o(": ",-1)),r("span",{innerHTML:b.options},null,8,Ap)])):h("",!0)]))),256))],64))),256))])):h("",!0),t[27]||(t[27]=o()),l.categories.reduce((y,b)=>b.units.length+y,0)?(i(),p("table",Pp,[r("thead",null,[r("tr",Sp,[t[6]||(t[6]=r("td",{class:"cell header name"},"NAME",-1)),t[7]||(t[7]=o()),(c=e.options.forces)!=null&&c.includeRole?(i(),p("td",Gp,"ROLE")):h("",!0),t[8]||(t[8]=o()),((x=e.options.forces)==null?void 0:x.includePoints)!==!1?(i(!0),p(C,{key:1},D(l.allCosts,y=>(i(),p("td",Bp,m(y),1))),256)):h("",!0),t[9]||(t[9]=o()),t[10]||(t[10]=r("td",{class:"cell header name"},"OPTIONS",-1))])]),t[25]||(t[25]=o()),r("tbody",null,[(i(!0),p(C,null,D(l.categories,y=>(i(),p(C,null,[(i(!0),p(C,null,D(y.units,b=>{var f,v,F;return i(),p("tr",null,[r("td",Qp,[b.modelCount>1?(i(),p("span",Up,"("+m(b.modelCount)+") ",1)):h("",!0),t[12]||(t[12]=o()),b.source.getCustomName()?(i(),p(C,{key:1},[r("span",$p,m(b.source.getCustomName()),1),t[11]||(t[11]=o(` -
                `,-1))],64)):h("",!0),t[13]||(t[13]=o()),r("span",Rp,m(b.source.getName()),1)]),t[22]||(t[22]=o()),e.options.forces.includeRole?(i(),p("td",Mp,m(y.source.getName()),1)):h("",!0),t[23]||(t[23]=o()),((f=e.options.forces)==null?void 0:f.includePoints)!==!1?(i(!0),p(C,{key:1},D(b.costs,A=>(i(),p("td",Ip,m(A||""),1))),256)):h("",!0),t[24]||(t[24]=o()),r("td",Hp,[r("span",{class:"options",innerHTML:b.options},null,8,Lp),t[19]||(t[19]=o()),(v=e.options.forces)!=null&&v.includeProfiles?(i(!0),p(C,{key:0},D(b.profiles,A=>(i(),p("div",null,[r("span",Tp,m(A[0].typeName),1),t[14]||(t[14]=o()),(i(!0),p(C,null,D(A,S=>(i(),p("span",Op,m(S.name),1))),256))]))),256)):h("",!0),t[20]||(t[20]=o()),b.stratagems.length?(i(),p("div",Yp,[t[15]||(t[15]=r("span",{class:"unit-categories-header header name"},"Stratagems",-1)),t[16]||(t[16]=o()),(i(!0),p(C,null,D(b.stratagems,A=>(i(),p("span",Np,m(A.name)+" ("+m(A.cp_cost)+"CP)",1))),256))])):h("",!0),t[21]||(t[21]=o()),b.secondaries.length&&((F=e.options.forces)!=null&&F.includeCategories)?(i(),p("div",Vp,[t[17]||(t[17]=r("span",{class:"unit-categories-header header name"},"Categories",-1)),t[18]||(t[18]=o()),(i(!0),p(C,null,D(b.secondaries,A=>(i(),p("span",jp,m(A),1))),256))])):h("",!0)])])}),256))],64))),256))])])):h("",!0)],64)}),256))])}const Xp=Object.assign(Q(xp,[["render",Wp]]),{__name:"ListsPrettyTemplatesRenderForceUnits"}),zp=G({props:{opt:{type:Object,required:!0},config:{type:[Object,Boolean],required:!0},options:{type:Object,required:!0}},computed:{userOptions(){var e;return((e=this.options)==null?void 0:e.stratagems)??{}},stratagems(){const e=rt(this.opt,this.$userStore.isSupporter());if(!e)return[];const t=hp(e,this.opt);return this.userOptions.includeCore===!1?t.filter(pt):t},groups(){const e=new Map;for(const n of this.stratagems){const s=pt(n)?n.detachment||"Detachment":"Core";e.has(s)||e.set(s,[]),e.get(s).push(n)}return[...e.entries()].map(([n,s])=>({name:n,stratagems:s})).sort((n,s)=>+(n.name==="Core")-+(s.name==="Core"))}}}),Zp={key:0,class:"section roster-stratagems on-next-page"},Kp={class:"stratagem-group"},Jp={class:"stratagem-group-name"},qp={class:"stratagem-definition"},_p={class:"stratagem-name"},eu={class:"stratagem-cost"},tu={class:"stratagem-type"},nu={key:0,class:"stratagem-when"},su=["innerHTML"];function ou(e,t,n,s,a,d){return e.groups.length?(i(),p("div",Zp,[t[5]||(t[5]=r("div",{class:"stratagems-header header"},"Stratagems",-1)),t[6]||(t[6]=o()),(i(!0),p(C,null,D(e.groups,l=>(i(),p("div",Kp,[r("div",Jp,m(l.name),1),t[4]||(t[4]=o()),(i(!0),p(C,null,D(l.stratagems,u=>(i(),p("div",qp,[r("div",null,[r("span",_p,m(u.name),1),t[0]||(t[0]=o()),r("span",eu,m(u.cp_cost)+"CP",1)]),t[1]||(t[1]=o()),r("div",tu,m(u.type),1),t[2]||(t[2]=o()),u.turn||u.phase?(i(),p("div",nu,m([u.turn,u.phase].filter(g=>g).join(" - ")),1)):h("",!0),t[3]||(t[3]=o()),r("div",{class:"stratagem-text data",innerHTML:u.description},null,8,su)]))),256))]))),256))])):h("",!0)}const ru=Object.assign(Q(zp,[["render",ou]]),{__name:"ListsPrettyTemplatesRenderStratagems"}),iu=G({components:{StatValue:Gs,RuleList:Ss},props:{profile:{type:Ys,required:!0}},computed:{offense(){return this.profile.offense.filter(e=>e.hasSpecial("loses_part")?!1:e.special!=!0||this.$optionStore.options.shownestedrules)},hasRsr(){return this.profile?this.profile.global.stats.Rsr!=null:null}},methods:{stripHtml(e){return ke(e)}}}),au={key:0,class:"stats t9acss"},lu={key:0,class:"popup"},du={class:"typeSize"},pu={class:"statTable"},uu={class:"statNames"},cu={key:0},gu={key:1},fu={class:"statValues"},mu={class:"offenseName"},hu={key:1},xu={class:"modelRules"},bu={key:0,class:"onlySmall statValues"},yu={colspan:"10",class:"modelRules smallScreen"},vu={class:"offenseName"},wu={class:"modelRules"},Cu={key:1,class:"onlySmall statValues"},Eu={colspan:"10",class:"modelRules smallScreen"},Fu={class:"offenseName"},ku={class:"modelRules"},Du={colspan:"10",class:"modelRules smallScreen"};function Au(e,t,n,s,a,d){const l=R("StatValue"),u=R("RuleList");return e.profile&&e.$userStore.isSupporter()?(i(),p("div",au,[e.profile?(i(),p("h3",lu,[r("strong",null,m(e.profile.name)+" - ",1),t[0]||(t[0]=o()),r("span",du," ("+m(e.profile.basesize())+") ",1)])):h("",!0),t[50]||(t[50]=o()),r("div",pu,[r("table",null,[r("tbody",null,[r("tr",uu,[t[1]||(t[1]=r("td",{class:"titleTd"},"Global",-1)),t[2]||(t[2]=o()),t[3]||(t[3]=r("td",null,"Cha",-1)),t[4]||(t[4]=o()),t[5]||(t[5]=r("td",null,"Mob",-1)),t[6]||(t[6]=o()),t[7]||(t[7]=r("td",null,"Dis",-1)),t[8]||(t[8]=o()),t[9]||(t[9]=r("td",null,"Hgt",-1)),t[10]||(t[10]=o()),e.hasRsr?(i(),p("td",cu,"Rea")):(i(),p("td",gu)),t[11]||(t[11]=o()),t[12]||(t[12]=r("td",null,null,-1)),t[13]||(t[13]=o()),t[14]||(t[14]=r("td",{class:"titleTd"},"Model rules",-1))]),t[41]||(t[41]=o()),r("tr",fu,[r("td",mu,m(e.stripHtml(e.profile.global.name)),1),t[15]||(t[15]=o()),w(l,{statline:e.profile.global,val:"Ad"},null,8,["statline"]),t[16]||(t[16]=o()),w(l,{statline:e.profile.global,val:"Ma"},null,8,["statline"]),t[17]||(t[17]=o()),w(l,{statline:e.profile.global,val:"Di"},null,8,["statline"]),t[18]||(t[18]=o()),w(l,{statline:e.profile.global,val:"Hgt"},null,8,["statline"]),t[19]||(t[19]=o()),e.profile.global.stats.Rsr!=null?(i(),E(l,{key:0,statline:e.profile.global,val:"Rsr"},null,8,["statline"])):(i(),p("td",hu)),t[20]||(t[20]=o()),t[21]||(t[21]=r("td",null,null,-1)),t[22]||(t[22]=o()),r("td",xu,[w(u,{pretty:"",system:e.profile.system,statline:e.profile.global},null,8,["system","statline"])])]),t[42]||(t[42]=o()),e.$optionStore.options.modelRulesSmallScreen?(i(),p("tr",bu,[r("td",yu,[w(u,{pretty:"",system:e.profile.system,statline:e.profile.global},null,8,["system","statline"])])])):h("",!0),t[43]||(t[43]=o()),t[44]||(t[44]=r("tr",{class:"statNames"},[r("td",{class:"titleTd"},"Defensive"),o(),r("td",null,"HP"),o(),r("td",null,"Def"),o(),r("td",null,"Res"),o(),r("td",null,"Arm"),o(),r("td"),o(),r("td"),o(),r("td")],-1)),t[45]||(t[45]=o()),r("tr",null,[r("td",vu,m(e.stripHtml(e.profile.defense.name)),1),t[23]||(t[23]=o()),w(l,{statline:e.profile.defense,val:"HP"},null,8,["statline"]),t[24]||(t[24]=o()),w(l,{statline:e.profile.defense,val:"Df"},null,8,["statline"]),t[25]||(t[25]=o()),w(l,{statline:e.profile.defense,val:"Re"},null,8,["statline"]),t[26]||(t[26]=o()),w(l,{statline:e.profile.defense,val:"Arm"},null,8,["statline"]),t[27]||(t[27]=o()),t[28]||(t[28]=r("td",null,null,-1)),t[29]||(t[29]=o()),t[30]||(t[30]=r("td",null,null,-1)),t[31]||(t[31]=o()),r("td",wu,[w(u,{pretty:"",system:e.profile.system,statline:e.profile.defense},null,8,["system","statline"])])]),t[46]||(t[46]=o()),e.$optionStore.options.modelRulesSmallScreen?(i(),p("tr",Cu,[r("td",Eu,[w(u,{pretty:"",system:e.profile.system,statline:e.profile.defense},null,8,["system","statline"])])])):h("",!0),t[47]||(t[47]=o()),t[48]||(t[48]=r("tr",{class:"statNames"},[r("td",{class:"titleTd"},"Offensive"),o(),r("td",null,"Att"),o(),r("td",null,"Off"),o(),r("td",null,"Str"),o(),r("td",null,"AP"),o(),r("td",null,"Agi"),o(),r("td"),o(),r("td")],-1)),t[49]||(t[49]=o()),(i(!0),p(C,null,D(e.offense,(g,c)=>(i(),p(C,null,[r("tr",null,[r("td",Fu,m(e.stripHtml(g.name)),1),t[32]||(t[32]=o()),w(l,{statline:g,val:"At"},null,8,["statline"]),t[33]||(t[33]=o()),w(l,{statline:g,val:"Of"},null,8,["statline"]),t[34]||(t[34]=o()),w(l,{statline:g,val:"St"},null,8,["statline"]),t[35]||(t[35]=o()),w(l,{statline:g,val:"AP"},null,8,["statline"]),t[36]||(t[36]=o()),w(l,{statline:g,val:"Ag"},null,8,["statline"]),t[37]||(t[37]=o()),t[38]||(t[38]=r("td",null,null,-1)),t[39]||(t[39]=o()),r("td",ku,[w(u,{pretty:"",system:e.profile.system,statline:g},null,8,["system","statline"])])]),t[40]||(t[40]=o()),e.$optionStore.options.modelRulesSmallScreen?(i(),p("tr",{key:c,class:"onlySmall statValues"},[r("td",Du,[w(u,{pretty:"",system:e.profile.system,statline:g},null,8,["system","statline"])])])):h("",!0)],64))),256))])])])])):h("",!0)}const Pu=Object.assign(Q(iu,[["render",Au],["__scopeId","data-v-cdd02cea"]]),{__name:"UnitstatsPrettyUnitStats"}),Su=G({name:"T9AProfile",components:{},props:{unit:{type:Object,required:!0}},computed:{models(){let e=this.unit.getAllModels().filter(t=>t.profile!=null&&t!=this.unit);return e=e.filter(t=>t.field("model")!=null),e}}}),Gu={class:"t9acss"};function Bu(e,t,n,s,a,d){const l=Pu;return i(),p("span",Gu,[e.unit.profile?(i(),E(l,{key:0,profile:e.unit.profile},null,8,["profile"])):h("",!0),t[0]||(t[0]=o()),(i(!0),p(C,null,D(e.models,u=>(i(),p("div",{key:u.uid},[u.profile?(i(),E(l,{key:0,profile:u.profile},null,8,["profile"])):h("",!0)]))),128))])}const Qu=Object.assign(Q(Su,[["render",Bu]]),{__name:"UnitstatsT9APrettyProfile"}),Uu=G({props:{opt:{type:Object,required:!0},config:{type:[Object,Boolean],required:!0},options:{type:Object,required:!0},listrow:{type:Object,required:!1}},computed:{t9a(){return this.opt.getBook().getSystem().engine==="t9a"},hasLeaders(){const e=this.opt.getBook().getSystem();return e.engine==="bs"&&V(e).hasLeaders()},userOptions(){var e;return((e=this.options)==null?void 0:e.cards)??{}},allUnits(){var e;return bd(this.opt,{exclude:((e=this.userOptions)==null?void 0:e.includeConfigUnits)===!0?[]:this.options.excludeConfigs})},nestedUnitsMap(){const e=new Map;for(const t of this.allUnits){const n=t.getAllUnits();n.length>0&&e.set(t.uid,n)}return e},combinedUnitsMap(){var d;if(!this.userOptions.combineLeaders)return new Map;const e=this.allUnits,t={};for(const l of e)t[l.uid]=l;const n=this.hasLeaders&&((d=this.listrow)!=null&&d.metadata)?V(this.opt.getBook().getSystem()):void 0,s=new Map,a=new Set;for(const l of e){if(a.has(l.uid))continue;const u=n?n.getAttachmentGroup(this.listrow.metadata,t,l).filter(c=>t[c.uid]):[l],g=[];for(const c of u)a.add(c.uid),g.push(c,...this.nestedUnitsMap.get(c.uid)??[]);g.length>1&&s.set(u[0].uid,g)}return s},stratagemContext(){return this.userOptions.stratagems?rt(this.opt,this.$userStore.isSupporter()):null},stratagemsByUnit(){const e=new Map,t=this.stratagemContext;if(!t)return e;for(const n of this.units)e.set(n.uid,cn(t,this.getCombinedUnits(n)??[n]));return e},processedUnitUids(){const e=new Set;for(const t of this.combinedUnitsMap.values())for(const n of t)e.add(n.uid);return e},units(){let e=[...this.allUnits];if(this.userOptions.combineLeaders){const s=new Set(this.combinedUnitsMap.keys());e=e.filter(a=>s.has(a.uid)||!this.processedUnitUids.has(a.uid))}this.userOptions.sortByName&&Ie(e,s=>s.getName());const t=this.t9a?!1:!this.userOptions.combineLeaders,n={customName:!0,name:!0,totalCosts:!0,profiles:!0,rules:!0,categories:!0};if(this.userOptions.combineLeaders){const s=new Set(this.combinedUnitsMap.keys()),a=e.filter(u=>s.has(u.uid)),d=e.filter(u=>!s.has(u.uid)),l=ue(d,{flatten:t,sort:this.userOptions.sortByName?"name-asc":void 0,dedupe:n});return[...a,...l]}return ue(e,{flatten:t,sort:this.userOptions.sortByName?"name-asc":void 0,dedupe:n})}},methods:{getCombinedUnits(e){return this.combinedUnitsMap.get(e.uid)},combinedSecondaries(e){const t=e.getAllSecondaries(),n=new Set(t),s=t.map(a=>({name:a,fromCombined:!1}));for(const a of this.getCombinedUnits(e)??[])if(a!==e)for(const d of a.getAllSecondaries())n.has(d)||(n.add(d),s.push({name:d,fromCombined:!0}));return s},togglePrintFunction(e){var s;const t=e.target;if(!t)return;const n=t.closest(".card-controls");n&&((s=n.parentElement)==null||s.classList.toggle("print-display-none",t.checked))},moveUpFunction(e){const t=e.target;if(!t)return;const n=t.closest(".card-controls");if(!n)return;const s=n.parentElement;if(!s)return;const a=s.previousElementSibling;a&&(a==null?void 0:a.getAttribute("type"))==="card"&&a.before(s)},moveDownFunction(e){const t=e.target;if(!t)return;const n=t.closest(".card-controls");if(!n)return;const s=n.parentElement;if(!s)return;const a=s.nextElementSibling;(a==null?void 0:a.getAttribute("type"))==="card"&&a.after(s)},models(e){const t=this.getCombinedUnits(e);if(t&&t.length>0){const n=t.flatMap(s=>s.getAllModels("unit",!0));return ge(n,{name:!0,options:{models:!1,constants:!0}})}return ge(e.getAllModels("unit",!0),{name:!0,options:{models:!1,constants:!0}})},stratagems(e){return this.stratagemsByUnit.get(e.uid)??[]},nested_units(e){return this.userOptions.combineLeaders?[]:ge(e.getAllUnits(),{name:!0})},optionsList(e){return he(e,{models:!1})},fullProfiles(e){var a;const t=e.getBook().getSystem().settings,n=this.getCombinedUnits(e);let s;return n&&n.length>0?s=n.flatMap(d=>d.getAllModifiedProfiles(l=>!l.isExportable()||l.source.getType()==="unit",!1,!0)):s=e.getAllModifiedProfiles(d=>!d.isExportable()||d.source.getType()==="unit"),this.userOptions.hideLeaderAbility&&(s=s.filter(d=>!["Leader","Support"].includes(se(d,"name")))),ee(s,{grouped:!0,exclude:this.options.ruleProfiles,order:(a=t==null?void 0:t.profilesOrder)==null?void 0:a.map(d=>d.toLowerCase()),includeSource:n&&n.length>1})},shortProfiles(e){const t=this.getCombinedUnits(e);let n;return t&&t.length>0?n=t.flatMap(s=>[...s.getAllModifiedProfiles(a=>!a.isExportable()||a.source.getType()==="unit",!1,!0),...s.getAllModifiedRules(!1,a=>!a.isExportable()||a.source.getType()==="unit",!0).map(pe)]):n=[...e.getAllModifiedProfiles(s=>!s.isExportable()||s.source.getType()==="unit"),...e.getAllModifiedRules(!1,s=>!s.isExportable()||s.source.getType()==="unit").map(pe)],ee(n,{grouped:!0,include:this.options.ruleProfiles,includeSource:t&&t.length>1})},getCombinedCosts(e){const t=this.getCombinedUnits(e);if(this.userOptions.combineLeaders&&t&&t.length>0){const s=new Map,a=new Set;for(const d of t)for(const l of d.getAllUnits(!0))a.add(l.uid);for(const d of t){if(a.has(d.uid))continue;const l=d.calcTotalCosts();for(const u of l){const g=s.get(u.name)||0;s.set(u.name,g+u.value)}}return Array.from(s.entries()).map(([d,l])=>({name:d,value:l}))}const n=e.getAllUnits(!1);if(n.length>0){const s=new Map,a=e.calcTotalCosts();for(const d of a)s.set(d.name,d.value);for(const d of n){const l=d.calcTotalCosts();for(const u of l){const g=s.get(u.name)||0;s.set(u.name,g-u.value)}}return Array.from(s.entries()).map(([d,l])=>({name:d,value:l}))}return e.calcTotalCosts()},getSourceUnitName(e){var n;const t=(n=e.getParentUnit)==null?void 0:n.call(e);return t?t.getName():e.getName()},t9aunit(e){return e}},components:{BsProfileData:tt}}),$u={class:"section cards"},Ru={class:"card-controls print-display-none",style:{display:"flex","align-items":"center","justify-content":"flex-end",gap:"15px"}},Mu={class:"button",style:{cursor:"pointer"}},Iu={key:0,class:"t9a-card"},Hu={key:1,class:"section card movable"},Lu={class:"section card-header"},Tu={class:"costs"},Ou={class:"cost"},Yu={key:0,class:"custom-name"},Nu={class:"name"},Vu={key:1,class:"count"},ju={key:0},Wu={class:"section card-models group"},Xu={class:"model profile"},zu={class:"section cell nowrap"},Zu={class:"count"},Ku={class:"name"},Ju={class:"section cell"},qu={key:0,class:"options"},_u={class:"section profile-row profiles group"},ec={class:"profile-group group"},tc={class:"header profile"},nc={class:"header name cell"},sc={class:"header characteristic small cell data"},oc={class:"header value"},rc={class:"section profile row"},ic={class:"name cell"},ac={key:0,class:"source-name",style:{color:"#888"}},lc={class:"characteristic small cell data"},dc={key:1,class:"section card-units card-row group"},pc={class:"secondaries cell"},uc={class:"secondary"},cc={class:"name"},gc={class:"section card-rules card-row"},fc={class:"profiles profile-row profiles group"},mc={class:"header secondary cell"},hc={class:"name nowrap"},xc={class:"secondaries cell"},bc={class:"name"},yc={key:2,class:"section card-stratagems card-row group"},vc={class:"secondaries cell"},wc={class:"secondary"},Cc={class:"name"},Ec={class:"section card-keywords card-row group"},Fc={class:"secondaries cell"},kc={class:"secondary"},Dc={class:"name"},Ac={key:0,class:"secondary"};function Pc(e,t,n,s,a,d){const l=Qu,u=R("BsProfileData");return i(),p("div",$u,[(i(!0),p(C,null,D(e.units,g=>(i(),p("div",{class:T(["unit card-wrapper",{"on-next-page":e.userOptions.onePerPage}]),type:"card"},[r("div",Ru,[r("label",{class:"button",style:{cursor:"pointer"},onClick:t[0]||(t[0]=(...c)=>e.moveUpFunction&&e.moveUpFunction(...c))},[...t[3]||(t[3]=[r("span",null,"Move up 🠉",-1)])]),t[7]||(t[7]=o()),r("label",{class:"button",style:{cursor:"pointer"},onClick:t[1]||(t[1]=(...c)=>e.moveDownFunction&&e.moveDownFunction(...c))},[...t[4]||(t[4]=[r("span",null,"Move down 🠋",-1)])]),t[8]||(t[8]=o()),r("label",Mu,[r("input",{type:"checkbox",style:{cursor:"pointer"},onClick:t[2]||(t[2]=(...c)=>e.togglePrintFunction&&e.togglePrintFunction(...c))}),t[5]||(t[5]=o()),t[6]||(t[6]=r("span",null,"Don't print this card.",-1))])]),t[34]||(t[34]=o()),e.t9a?(i(),p("div",Iu,[w(l,{unit:e.t9aunit(g)},null,8,["unit"])])):(i(),p("table",Hu,[r("thead",null,[r("tr",Lu,[r("td",null,[r("span",Tu,[(i(!0),p(C,null,D(e.getCombinedCosts(g),c=>(i(),p("span",Ou,m(c.value)+" "+m(c.name),1))),256))]),t[9]||(t[9]=o()),g.getCustomName()?(i(),p("span",Yu,m(g.getCustomName())+" -",1)):h("",!0),t[10]||(t[10]=o()),r("span",Nu,m(g.getName()),1),t[11]||(t[11]=o()),g.dupeCount&&g.dupeCount>1?(i(),p("span",Vu,m(g.dupeCount),1)):h("",!0)])])]),t[33]||(t[33]=o()),r("tbody",null,[e.userOptions.models&&e.models(g).length?(i(),p("tr",ju,[r("td",null,[r("table",Wu,[t[14]||(t[14]=r("thead",null,[r("tr",{class:"header model profile"},[r("td",{class:"section cell nowrap header"},[r("span",{class:"header name"},"Models")]),o(),r("td",{class:"section cell header"},[r("span",{class:"header options"},"Options")])])],-1)),t[15]||(t[15]=o()),r("tbody",null,[(i(!0),p(C,null,D(e.models(g),c=>(i(),p("tr",Xu,[r("td",zu,[r("span",Zu,m(c.dupeCount)+"x ",1),t[12]||(t[12]=o()),r("span",Ku,m(c.getName()),1)]),t[13]||(t[13]=o()),r("td",Ju,[e.optionsList(c)?(i(),p("span",qu,m(e.optionsList(c)),1)):h("",!0)])]))),256))])])])])):h("",!0),t[28]||(t[28]=o()),r("tr",_u,[r("td",null,[(i(!0),p(C,null,D(e.fullProfiles(g),c=>(i(),p("table",ec,[r("thead",null,[r("tr",tc,[r("td",nc,m(c[0].typeName),1),t[16]||(t[16]=o()),(i(!0),p(C,null,D(c[0].characteristics,x=>(i(),p("td",sc,[r("span",oc,m(x.name),1)]))),256))])]),t[18]||(t[18]=o()),r("tbody",null,[(i(!0),p(C,null,D(c,x=>(i(),p("tr",rc,[r("td",ic,[o(m(x.name)+" ",1),e.userOptions.combineLeaders&&x.source?(i(),p("span",ac," - "+m(e.getSourceUnitName(x.source)),1)):h("",!0)]),t[17]||(t[17]=o()),(i(!0),p(C,null,D(x.characteristics,y=>(i(),p("td",lc,[w(u,{class:"value",data:y.$text,name:x.name},null,8,["data","name"])]))),256))]))),256))])]))),256))])]),t[29]||(t[29]=o()),e.nested_units(g).length?(i(),p("tr",dc,[r("td",null,[t[19]||(t[19]=r("span",{class:"header secondary cell"},[r("span",{class:"header name"},"Units")],-1)),t[20]||(t[20]=o()),r("div",pc,[(i(!0),p(C,null,D(e.nested_units(g),c=>(i(),p("span",uc,[r("span",cc,m(c.getAmount())+"x "+m(c.getName()),1)]))),256))])])])):h("",!0),t[30]||(t[30]=o()),r("tr",gc,[r("td",null,[(i(!0),p(C,null,D(e.shortProfiles(g),c=>(i(),p("div",fc,[r("span",mc,[r("span",hc,m(c[0].typeName),1)]),t[21]||(t[21]=o()),r("span",xc,[(i(!0),p(C,null,D(c,x=>(i(),p("span",bc,m(x.name),1))),256))])]))),256))])]),t[31]||(t[31]=o()),e.stratagems(g).length?(i(),p("tr",yc,[r("td",null,[t[22]||(t[22]=r("span",{class:"header secondary cell"},[r("span",{class:"header name"},"Stratagems")],-1)),t[23]||(t[23]=o()),r("div",vc,[(i(!0),p(C,null,D(e.stratagems(g),c=>(i(),p("span",wc,[r("span",Cc,m(c.name)+" ("+m(c.cp_cost)+"CP)",1)]))),256))])])])):h("",!0),t[32]||(t[32]=o()),r("tr",Ec,[r("td",null,[t[26]||(t[26]=r("span",{class:"header secondary cell"},[r("span",{class:"header name"},"Categories")],-1)),t[27]||(t[27]=o()),r("div",Fc,[(i(!0),p(C,null,D(e.combinedSecondaries(g),c=>(i(),p("span",kc,[r("span",Dc,m(c.name)+m(c.fromCombined?"*":""),1)]))),256)),t[25]||(t[25]=o()),e.combinedSecondaries(g).some(c=>c.fromCombined)?(i(),p("span",Ac,[...t[24]||(t[24]=[r("span",{class:"name"},"*from combined unit",-1)])])):h("",!0)])])])])]))],2))),256))])}const Sc=Object.assign(Q(Uu,[["render",Pc]]),{__name:"ListsPrettyTemplatesRenderUnitCards"}),Gc=G({components:{BsProfileData:tt},props:{opt:{type:Object,required:!0},config:{type:[Object,Boolean],required:!0},options:{type:Object,required:!0}},methods:{getRules(e){if(!e.getModifiedRules)return[];const t=e.getModifiedRules().map(n=>pe(n));return ee(t,{include:["rules"],dedupe:!0,sort:!0})}},computed:{rawForces(){var e;return(e=this.opt)==null?void 0:e.getForces().filter(t=>t.isExportable())},forces(){return this.rawForces.filter(e=>this.getRules(e).length)},rules(){const e=[...new Set([...this.options.ruleProfiles||[],"rules","special rule"])],t=[];return typeof this.opt.getAllModifiedProfiles=="function"&&t.push(...this.opt.getAllModifiedProfiles(n=>!n.isExportable())),typeof this.opt.getAllModifiedRules=="function"&&t.push(...this.opt.getAllModifiedRules(!0).map(n=>pe(n))),ee(t,{include:e,dedupe:!0,sort:!0})},deduped_rules(){const e={};for(const n of this.rules)Ot(e,`${n.characteristics[0].$text}`,n);const t=[];for(const n of Object.values(e)){const s=n[0],a=[...new Set(n.map(d=>d.name))].join(" / ");t.push({name:a,characteristics:s.characteristics,typeId:s.typeId,typeName:s.typeName,hidden:s.hidden})}return t},display(){return this.rules.length>0}}}),Bc={key:0,class:"section unit-rules on-next-page"},Qc={class:"force-rules"},Uc={class:"force-custom-name"},$c={class:"force-name"},Rc={key:1,class:"force-catalogue"},Mc={class:"force-rule"},Ic={class:"rule-name"},Hc={class:"rule-text"},Lc={class:"profile rule-definition"},Tc={class:"rule-name"},Oc={class:"rule-text"};function Yc(e,t,n,s,a,d){const l=R("BsProfileData");return e.display?(i(),p("div",Bc,[t[7]||(t[7]=r("div",{class:"unit-rules-header header"}," Rules ",-1)),t[8]||(t[8]=o()),(i(!0),p(C,null,D(e.forces,u=>(i(),p("div",Qc,[u.getCustomName()?(i(),p(C,{key:0},[r("span",Uc,m(u.getCustomName()),1),t[0]||(t[0]=o()),t[1]||(t[1]=r("span",{class:"force-name-separator"}," - ",-1))],64)):h("",!0),t[3]||(t[3]=o()),r("span",$c,m(u.getName()),1),t[4]||(t[4]=o()),u.getBook().getName()?(i(),p("span",Rc," ("+m(u.getBook().getName())+") ",1)):h("",!0),t[5]||(t[5]=o()),(i(!0),p(C,null,D(e.getRules(u),g=>(i(),p("div",Mc,[r("div",null,[r("span",Ic,m(g.name),1)]),t[2]||(t[2]=o()),r("div",null,[r("span",Hc,[w(l,{data:g.characteristics[0].$text},null,8,["data"])])])]))),256))]))),256)),t[9]||(t[9]=o()),(i(!0),p(C,null,D(e.deduped_rules,u=>(i(),p("div",Lc,[r("div",null,[r("span",Tc,m(u.name)+":",1)]),t[6]||(t[6]=o()),r("div",null,[r("span",Oc,[w(l,{data:u.characteristics[0].$text},null,8,["data"])])])]))),256))])):h("",!0)}const Nc=Object.assign(Q(Gc,[["render",Yc]]),{__name:"ListsPrettyTemplatesRenderUnitRules"}),re=G({props:{opt:{type:Object,required:!0},config:{type:[Object,Boolean],required:!1},parent:{type:String},header:{type:String},options:{type:Object}},computed:{configObject(){const e=this.config;if(typeof e=="object"){const t=this.header;return t&&typeof e[t]=="object"?{...e,...e[t],isHeader:!0}:{...e}}return e===!1?!1:{}}}});function gn(e){return e.charAt(0).toUpperCase()+e.slice(1)}function J(e,t,n){return G({mixins:[re],props:{opt:{type:Object,required:!0}},render(){if(!this.config)return null;let s=t(this.opt,this.configObject);if(s==null)return null;if(this.header){const a=this.configObject.label||((n?n(this.opt,this.configObject):void 0)??gn(e));return M(this.configObject.tag||"span",{class:["header",e,this.configObject.class]},a)}return this.configObject.before&&(s=`${this.configObject.before}${s}`),this.configObject.after&&(s=`${s}${this.configObject.after}`),s===null?null:M(this.configObject.tag||"span",{class:[e,this.configObject.class]},s)}})}function Vc(e,t,n){return G({mixins:[re],props:{opt:{type:Object,required:!0}},render(){const s=t(this.opt,this.configObject);if(this.header){const a=this.configObject.label||gn(e);return M(this.configObject.tag||"span",{class:["header",e,this.configObject.class]},a)}return s?M(this.configObject.tag||"span",{class:[e,this.configObject.class],innerHTML:s}):null}})}function le(e,t,n,s){return G({mixins:[re],props:{opt:{type:Object,required:!0}},methods:{getOpts(){if(this.header){if(s)return s(this.opt,this.configObject);const a=n(this.opt,this.configObject);return Array.isArray(a)?a.length>0?[a[0]]:null:a?[a]:null}return n(this.opt,this.configObject)}},render(){const a=this.configObject.flat,d=this.configObject.unwrap,l=this.getOpts();if(!l||Array.isArray(l)&&!l.length)return this.$slots.empty&&this.$slots.empty(),null;if(this.header)return l.map(g=>{if(d)return this.$slots.default(g);const c=["header",t,this.configObject.childClass];return M(this.configObject.childTag||"div",{class:c},this.$slots.default(g))});const u=l.map(g=>d?this.$slots.default(g):M(this.configObject.childTag||"div",{class:[t,this.configObject.childClass]},this.$slots.default(g)));return a?u:!this.configObject.includeEmpty&&!(u!=null&&u.length)?null:M(this.configObject.tag||"div",{class:[e,this.configObject.class]},u)}})}function jc(e,t,n){return G({mixins:[re],props:{opt:{type:Object,required:!0}},methods:{getOpts(){return this.header?t(this.opt,this.configObject):t(this.opt,this.configObject)}},render(){const s=this.configObject.unwrap,a=this.getOpts();if(!a)return null;if(s)return this.$slots.default(a);const d=[e,this.configObject.childClass];return this.header&&d.push("header"),M(this.configObject.childTag||"div",{class:d},this.$slots.default(a))}})}const Wc=G({mixins:[re],props:{opt:{type:Object,required:!0}},render(){const e=this.configObject.flat,n=cs(this.opt.calcTotalCosts(),this.configObject).map(d=>{const l=[{header:this.header},`cost cost-${gs(d.name)}`];return l.push(this.configObject.childClass),M(this.configObject.childTag||"span",{class:l,innerHTML:this.header?d.name:d.html})});if(e)return n;const s=[];this.configObject.before&&n.length&&s.push(this.configObject.before);let a=!0;for(const d of n)this.configObject.between&&!a&&s.push(this.configObject.between),s.push(d),a=!1;return this.configObject.after&&n.length&&s.push(this.configObject.after),M(this.configObject.tag||"span",{class:["costs",this.configObject.class]},s)}}),Xc=Object.assign(Wc,{__name:"ListsPrettyRenderRCosts"}),zc=G({mixins:[re],props:{opt:{type:Object,required:!0}},computed:{all_profiles(){const e=[];if(typeof this.opt.getAllModifiedProfiles=="function"&&e.push(...this.opt.getAllModifiedProfiles()),this.opt.getAllModifiedRules){const t=this.opt.getAllModifiedRules(this.configObject.skipForces);e.push(...t.map(n=>pe(n)))}return e},profiles(){const e=[];if(this.opt.getModifiedProfiles&&e.push(...this.opt.getModifiedProfiles()),this.opt.getModifiedRules){const t=this.opt.getModifiedRules();e.push(...t.map(n=>pe(n)))}return e}},render(){const e=this.configObject.flat,t=this.configObject.unwrap,n=this.configObject.grouped,s=this.configObject.groupedChilds,a=this.configObject.deep!==!1?this.all_profiles:this.profiles;if(!(a!=null&&a.length))return null;const d=l=>{if(this.header)return t?[this.$slots.default(l[0])]:[M(this.configObject.childTag||"div",{class:["header profile",this.configObject.childClass]},this.$slots.default(l[0]))];const u=l.map(g=>t?this.$slots.default(g):M(this.configObject.childTag||"div",{class:["profile",this.configObject.childClass]},this.$slots.default(g)));return s?[M(this.configObject.childsGroupTag||"div",{class:["profile-group-entries",this.configObject.childsGroupClass]},u)]:u};if(n){const u=ee(a,this.configObject).map(g=>{if(!g.length)return null;const c=d(g);if(this.configObject.generateGroupHeader){const x=M(this.configObject.childTag||"div",{class:["header profile",this.configObject.headerClass]},this.$slots.default(g[0],"header"));c.unshift(x)}return M(this.configObject.groupTag||"div",{class:["profile-group",this.configObject.groupClass]},c)});return M(this.configObject.tag||"div",{class:["profiles",this.configObject.class]},u)}else{const l=ee(a,this.configObject);if(!l.length)return null;const u=d(l);return e?u:!this.configObject.includeEmpty&&!(u!=null&&u.length)?null:M(this.configObject.tag||"div",{class:["profiles",this.configObject.class]},u)}}}),Zc=Object.assign(zc,{__name:"ListsPrettyRenderRProfiles"}),Kc=G({props:{opt:{type:Object,required:!0}},render(){return M("div",this.$slots.default(this.opt))}}),Jc=Object.assign(Kc,{__name:"ListsPrettyRenderRRoster"}),qc=G({mixins:[re],props:{opt:{type:Object,required:!0}},methods:{},render(){if(!(this.opt instanceof Ts))return null;if(this.header)return[M(this.configObject.childTag||"div",{class:["header t9aprofile",this.configObject.childClass]},this.$referenceStore.getString("lists_profiles"))];const e=M(ct,{aunit:this.opt});return M(this.configObject.tag||"div",{class:["t9aprofile",this.configObject.class]},e)},components:{T9AProfile:ct}}),_c=Object.assign(qc,{__name:"ListsPrettyRenderRT9aprofiles"});function eg(e){return e.isCategory()}function tg(e){return e.isForce()}function ng(e){return e.isRoster()}const sg=G({mixins:[re],props:{opt:{type:Object,required:!0}},methods:{categoryUnits(e){return e.getUnits()},forceUnits(e){const t=[];for(const n of me(e.getCategories(),this.configObject))t.push(...this.categoryUnits(n));return t},rosterUnits(e){const t=[];for(const n of e.getForces())t.push(...this.forceUnits(n));return t}},computed:{units(){const e=this.opt;return eg(e)?this.categoryUnits(e):tg(e)?this.forceUnits(e):ng(e)?this.rosterUnits(e):[]}},render(){const e=this.configObject.flat,t=this.configObject.unwrap,n=ue(this.units,this.configObject);if(!n.length)return null;if(this.header)return t?this.$slots.default(n[0]):M(this.configObject.childTag||"div",{class:["header unit",this.configObject.childClass]},this.$slots.default(n[0]));const s=n.map(a=>t?this.$slots.default(a):M(this.configObject.childTag||"div",{class:["unit",this.configObject.childClass]},this.$slots.default(a)));return e?s:M(this.configObject.childTag||"div",{class:["units",this.configObject.class]},s)}}),og=Object.assign(sg,{__name:"ListsPrettyRenderRUnits"}),Ee={costs:Xc,roster:Jc,units:og,profiles:Zc,t9aprofiles:_c,force_units:Xp,render_unit_cards:Sc,render_unit_rules:Nc,render_stratagems:ru,type:J("type",e=>e.getType?e.getType():e.type??e.typeName),primary:J("primary",e=>e.getParentCategory().getName()),originalValue:J("originalValue",e=>e.originalValue),forces:le("forces","force",e=>e.getForces()),size:J("size",(e,t)=>{const n=e.calcTotalUnitSize();return t.min!==void 0&&n<t.min?null:n}),amount:J("amount",(e,t)=>{const n=e.amount??0;return t.min!==void 0&&n<t.min?null:n}),characteristics:le("characteristics","characteristic",(e,t)=>ie(e.characteristics,t),(e,t)=>ie(e.characteristics,t)),smallcharacteristics:le("smallcharacteristics","characteristic",(e,t)=>e.small?ie(e.small,t):null,(e,t)=>e.small?ie(e.small,t):null),bigcharacteristics:le("bigcharacteristics","characteristic",(e,t)=>e.big?ie(e.big,t):null,(e,t)=>e.big?ie(e.big,t):null),categories:le("categories","category",(e,t)=>me(e.getCategories(),t)),models:le("models","model",(e,t)=>t.dedupe?ge(e.getAllModels(),t.dedupe):e.getAllModels()),secondaries:le("secondaries","secondary",(e,t)=>e.getSecondaryCategories?mp(e.getSecondaryCategories(),t):null),options:Vc("options",(e,t)=>e instanceof Os?e.calcOptionsList():fs(he(e,t),"<br/>")),name:J("name",e=>e.getName?e.getName():e.name,e=>e.typeName??"Name"),note:J("note",e=>e.getNote()),value:J("value",e=>e.$text,e=>e.name),customName:J("customName",e=>e.getCustomName()||null),count:J("count",(e,t)=>t.always||e.dupeCount&&e.dupeCount>1?e.dupeCount:null),catalogue:jc("catalogue",e=>e.getBook())},rg=G({components:Ee,mixins:[re],props:{opt:{type:Object,required:!0},parent:{type:String,default:"root"},options:{type:Object},listrow:{type:Object,required:!1}},name:"RSection",methods:{render_field(e,t){const n=(a,d)=>{const l={...t,parent:e,opt:a,options:this.options,listrow:this.listrow};return d&&(l.header=d),M(R("r-section",!0),l)};return M(Ee[e],t,n)},render_section(e,t){const n=a=>{const d={...t,parent:e,opt:a,options:this.options,listrow:this.listrow};return M(R("r-section",!0),d)};return M(R("r-section"),t,n)}},render(){const e=[];if(this.header&&!this.configObject.flat)return null;const t={opt:this.opt,parent:this.parent,header:this.header,options:this.options,listrow:this.listrow};if(!this.header&&"generateHeader"in this.configObject){const n=typeof this.configObject.generateHeader=="object"?this.configObject.generateHeader:{},s={...this.configObject,...n};for(const a in s){const d=s[a];if(a==="sections")for(const l of Array.isArray(d)?d:[d]){const u=this.header?{...l,...l[this.header]}:l,g={...t,config:l,header:"header"},c=this.render_section(a,g);if(u.sectionTag||u.sectionClass){const y={class:["section header",u.sectionClass]};e.push(M(u.sectionTag||"div",y,c))}else e.push(c)}else if(a in Ee){const l={...t,config:d,header:"header"};e.push(this.render_field(a,l))}}}for(const n in this.configObject){const s=this.configObject[n];if(n==="sections")for(const a of Array.isArray(s)?s:[s]){const d=this.header?{...a,...a[this.header]}:a,l={...t,config:a},u=this.render_section(n,l);if(d.sectionTag||d.sectionClass){const c={class:["section",d.sectionClass,{header:this.header}],header:this.header};e.push(M(d.sectionTag||"div",c,u))}else e.push(u)}else if(n in Ee&&s!==!1){const a={...t,config:s};e.push(this.render_field(n,a))}}return this.configObject.html&&e.length&&e.unshift(M("div",{innerHTML:this.configObject.html})),e}}),ig=Object.assign(rg,{__name:"ListsPrettyRenderRSection"}),ag="html ::-webkit-scrollbar-thumb{background:#0000004d;border-radius:5px}html ::-webkit-scrollbar-thumb:hover{background:#0006}html ::-webkit-scrollbar-thumb:active{background:#00000080}html ::-webkit-scrollbar{height:6px;width:6px}";class ve{get_options(t){return{}}get_json(t,n){return null}is_available(t){return!0}}class lg extends ve{get_options(){return{default:{includeHeader:!0,includeConfig:!0,includeConstantOptions:!0},id:"forces",label:"Forces",type:"toggle",fields:{includeHeader:{label:"Force Name",type:"boolean"},includeConfig:{label:"Configuration",type:"boolean"},includeRole:{label:"Role",type:"boolean"},includePoints:{label:"Points",type:"boolean"},includeConstantOptions:{label:"Constant selections",type:"boolean"},includeOptionsCost:{label:"Options cost",type:"boolean"},includeProfiles:{label:"Profiles",type:"boolean"},includeCategories:{label:"Categories",type:"boolean"},includeStratagems:{label:"Stratagems",type:"boolean",premium:!0}}}}get_json(t,n){return{force_units:!0}}}class dg extends ve{get_options(){return{id:"header",label:"Roster Name",type:"toggle",default:{},fields:{note:{label:"Roster Note",type:"boolean"}}}}get_json(t){return{sectionClass:"roster-header",name:!0,costs:{before:"[",after:"]",between:" / "},note:t.header.note?{tag:"div"}:!1}}}class pg extends ve{get_options(){return{id:"stratagems",label:"Stratagems",type:"toggle",premium:!0,default:{state:!1,includeCore:!0},fields:{includeCore:{label:"Core stratagems",type:"boolean"}}}}is_available(t){return!!(t&&V(t).hasStratagems())}get_json(){return{render_stratagems:!0}}}class ug extends ve{get_options(t){const n=!!(t&&V(t).hasStratagems());return{id:"cards",label:"Cards",type:"toggle",default:{},fields:{includeConfigUnits:{type:"boolean",label:"Include configuration units"},sortByName:{type:"boolean",label:"Sort by name"},models:{type:"boolean",label:"Models"},onePerPage:{type:"boolean",label:"One per page"},combineLeaders:{type:"boolean",label:"Combine Leaders with Units"},...n?{hideLeaderAbility:{type:"boolean",label:"Hide Leader / Support ability"}}:{},stratagems:{type:"boolean",label:"Stratagems",premium:!0}}}}get_json(){return{render_unit_cards:!0}}}class cg extends ve{get_options(){return{id:"rules",label:"Rules",type:"toggle",default:{}}}get_json(){return{render_unit_rules:!0}}}function gg(e){return[dg,lg,ug,cg,pg].filter(n=>n.prototype.is_available(e))}function fn(e,t){for(const n in e){const s=e[n];s&&typeof s=="object"&&fn(s,t);const a=t(n,e[n],e);a===void 0?delete e[n]:e[n]=a}return e}function Dt(e){return fn(JSON.parse(JSON.stringify(e)),(n,s,a)=>{if(xe(s)){const d=s;if(Object.keys(s).length===1&&"state"in s)return d.state;if(d.state===!1)return!1}return s})}function At(e,t){const n=[];for(const s of t){const a=s.prototype,d=a.get_options(),l=e[d.id];if(!l)continue;const u=a.get_json(e,l);u&&n.push(u)}return{roster:{sections:n}}}function fg(e,t){const n={};for(const s of e){const a=s.prototype.get_options(t);a.id&&(n[a.id]=a)}return{fields:n}}function Fe(e){const t=["configuration","game options","uncategorized","rites of war","rite of war:","allegiance","tournament options","tournament quests","allegiance:","allied detachment","scenery","malign sorcery"];e!=null&&e.configurationCategories&&t.push(...e.configurationCategories.map(l=>l.toLowerCase()));const n=["pts","points","point","pl","cp"];e!=null&&e.commonCosts&&t.push(...e.commonCosts.map(l=>l.toLowerCase()));const s=["expanded army lists"],a=[...t,...s];return{configs:t,excludeConfigs:a,commonCosts:n,ruleProfiles:["rules","rule","special rule","command"]}}function mg(e,t){const n={};for(const s of e){const a=s.prototype.get_options(t);a.id&&a.default&&(n[a.id]=a.default)}return n}const hg=G({components:{Loading:Me,PreviewOptions:pn,PopupDialog:H},emits:["ready"],props:{roster:{type:Object,required:!0},listrow:{type:Object,required:!1}},setup(){return{loading:Mn(!0)}},data(){const e=this.roster.getBook().getSystem(),t=gg(e),s={...mg(t,e),...this.$optionStore.options.prettyExportOptions??{}},a=e.settings,d=Dt(s),l={...Fe(a),...d};return{html:'<div class="preview"></div>',app:null,ready:!1,templates:t,options:fg(t,e),optionsOpen:!1,subPopup:!1,user_options:s,settings:a,props:{opt:this.roster,config:At({...Fe(a),...d},t),options:l,listrow:this.listrow}}},async mounted(){setTimeout(this.render,500)},created(){addEventListener("afterprint",this.print)},unmounted(){removeEventListener("afterprint",this.print),this.app&&this.app.unmount()},computed:{showNonExportableWarning(){return et(this.roster)}},methods:{getApp(){return this.app},getFrame(){return this.$refs.frame},createApp(){const e=Rn(ig,this.props);return e.config.globalProperties.$optionStore=this.$optionStore,e.config.globalProperties.$userStore=this.$userStore,e.config.globalProperties.$systemStore=this.$systemStore,this.app=e,e},async render(){try{this.loading=!0;const e=this.roster.getBook().getSystem();V(e).hasStratagems()&&await e.loadExtraBooks(),this.createApp();const t=this.getFrame();if(!(t!=null&&t.contentWindow))return;const n=t.contentWindow.document.getElementsByTagName("div")[0],s=t.contentWindow.document.head;if(!n||!s)return;s.insertAdjacentHTML("beforeend",'<meta http-equiv="content-type" content="text/html;charset=utf-8" />'),s.insertAdjacentHTML("beforeend",`<style>${ag}</style>`),s.insertAdjacentHTML("beforeend",`<style>${fp}</style>`),s.insertAdjacentHTML("beforeend",`<style>${gp}</style>`),t.contentWindow.document.addEventListener("click",this.toggleCrossed),this.getApp().mount(n),this.ready=!0,this.$emit("ready")}catch(e){console.error(e)}finally{this.loading=!1}},toggleCrossed(e){var n,s;const t=(s=(n=e.target).closest)==null?void 0:s.call(n,".profile:not(.header)");t&&(t.classList.toggle("crossed"),t.classList.toggle("print-display-none",t.classList.contains("crossed")))},async print(){if(this.ready)try{const e=this.getFrame();if(!(e!=null&&e.isConnected)||!e.contentDocument)return;const t=e.contentWindow;if(!t)return;globalThis.Capacitor&&globalThis.Capacitor.isNativePlatform()?Yt.printHtml({html:t.document.documentElement.outerHTML,name:this.roster.getName()}):t.print()}catch(e){console.warn("Could not print the preview frame",e)}},save_html(){var t,n;const e=(n=(t=this.getFrame())==null?void 0:t.contentWindow)==null?void 0:n.document.documentElement.innerHTML;e&&Nt(`${this.roster.getName()}.html`,"text/html;charset=utf-8",`<!DOCTYPE html>
<html>
${e}
</html>`)},optionschange(e){const t=Dt(e),n=At({...Fe(),...t},this.templates);this.$optionStore.options.prettyExportOptions=e,this.$optionStore.updateOptions("prettyExportOptions");for(const s in n)this.props.config[s]=n[s];Object.assign(this.props.options,{...Fe(this.settings),...t})}}}),xg={class:"preview",style:{width:"calc(100%-10px)"}},bg={class:"printwarn"},yg={style:{"text-align":"center","font-size":"50px"}},vg={key:0,class:"non-exportable-warning printer-hidden"},wg=["srcdoc"],Cg={key:2,class:"preview-options printer-hidden popup",style:{position:"fixed",top:"calc(var(--safe-area-inset-top) + 20px)",right:"calc(var(--safe-area-inset-right) + 20px)"}},Eg={style:{"vertical-align":"center"}},Fg={class:"section"},kg={key:3,class:"printer-hidden",style:{position:"fixed",top:"calc(var(--safe-area-inset-top) + 20px)",right:"calc(var(--safe-area-inset-right) + 20px)"}};function Dg(e,t,n,s,a,d){const l=Me,u=R("PreviewOptions"),g=ze,c=$s,x=be,y=H;return i(),p("div",xg,[r("div",bg,[r("span",yg,m(e.$referenceStore.getString("preview_print_dialog")),1)]),t[9]||(t[9]=o()),e.showNonExportableWarning?(i(),p("div",vg,m(e.$referenceStore.getString("no_exportable_units_warning")),1)):h("",!0),t[10]||(t[10]=o()),e.loading?(i(),E(l,{key:1,class:"loading",style:{height:"90vh"}})):h("",!0),t[11]||(t[11]=o()),r("div",{class:T(["previewframe",{"hide-loading":e.loading}]),style:{width:"calc(100vw - (10px + var(--safe-area-inset-right, 0px) + var(--safe-area-inset-right, 0px)))",height:"calc(100vh - (60px + var(--safe-area-inset-top, 0px) + var(--safe-area-inset-bottom, 0px)))","max-width":"1020px"}},[r("iframe",{class:"printable iframe",style:{border:"none","margin-left":"auto","margin-right":"auto",width:"100%",height:"calc(100% - 4px)"},srcdoc:e.html,ref:"frame"},null,8,wg)],2),t[12]||(t[12]=o()),e.optionsOpen?(i(),p("div",Cg,[r("span",Eg,m(e.$referenceStore.getString("options")),1),t[7]||(t[7]=o()),r("button",{class:"inputstyle",style:{width:"28px",height:"28px",float:"right"},onClick:t[0]||(t[0]=b=>e.optionsOpen=!e.optionsOpen)},[...t[5]||(t[5]=[r("span",{style:{"text-align":"center","vertical-align":"middle","font-size":"22px"}}," × ",-1)])]),t[8]||(t[8]=o()),r("div",null,[w(u,{options:e.options,style:{"margin-top":"10px"},result:e.user_options,onChanged:e.optionschange,onPremium:t[1]||(t[1]=b=>e.subPopup=!0)},null,8,["options","result","onChanged"]),t[6]||(t[6]=o()),r("div",Fg,[r("button",{class:"bouton",onClick:t[2]||(t[2]=(...b)=>e.save_html&&e.save_html(...b))},m(e.$referenceStore.getString("lists_save_as_html")),1)])])])):(i(),p("div",kg,[r("button",{class:"inputstyle",style:{float:"right"},v:"",onClick:t[3]||(t[3]=b=>e.optionsOpen=!e.optionsOpen)},[w(g,{class:"icon",style:{padding:"1px","vertical-align":"center"}})])])),t[13]||(t[13]=o()),e.subPopup?(i(),E(y,{key:4,modelValue:e.subPopup,"onUpdate:modelValue":t[4]||(t[4]=b=>e.subPopup=b),noclose:""},{default:k(()=>[w(x,null,{default:k(()=>[w(c)]),_:1})]),_:1},8,["modelValue"])):h("",!0)])}const mn=Object.assign(Q(hg,[["render",Dg],["__scopeId","data-v-5c25154d"]]),{__name:"ListsPrettyPreview"}),Ag=G({components:{PopupDialog:H,ExportPanel:_t,Export:md,Preview:mn,ExportTemplate:Ve,SpellsView:Wt},emits:["share","update:modelValue"],props:{modelValue:{type:Boolean,default:!0},list:{required:!0,type:Object},system:{required:!0,type:Object},hideLink:{type:Boolean,default:!1},hideRos:{type:Boolean,default:!1},onlyExportable:{type:Boolean,default:!1}},data(){return{textExport:!1,previewing:!1,previewReady:!1,templating:!1,templateReady:!1,exportSpells:!1}},computed:{instanceArmy(){return this.list.army instanceof Be?this.list.army:null},allSpells(){var e;return this.system.spells&&((e=this.list)!=null&&e.army)&&this.list.army.iterateUnits?V(this.system).getSpellCards(this.list.army):[]}},watch:{previewing(){this.previewReady=!1},templating(){this.templateReady=!1}},methods:{exportText(){this.textExport=!0},exportPdf(){this.list.army&&Es(this.list,this.system.engine==="t9a",this.$userStore.user!=null,this.$optionStore.options)},exportPretty(){this.previewing=!0},exportTemplates(){this.templating=!0},exportJson(){this.list.army&&Cs(this.list,this.onlyExportable)},exportRos(){this.list.army&&ws(this.list,this.onlyExportable)},async exportRosz(){this.list.army&&await vs(this.list,this.onlyExportable)},async yellow(){if(this.list.army)try{const e=await ys(this.list,this.onlyExportable);this.handleYellowResult(e)}catch(e){console.error(e),alert(this.$referenceStore.getString("yellowscribe_error"))}},async wh40kyellow(){if(this.list.army)try{const e=await bs(this.list);this.handleYellowResult(e)}catch{alert(this.$referenceStore.getString("yellowscribe_error"))}},async nryellow(){if(this.list.army)try{const e=await xs(this.list);this.handleYellowResult(e)}catch{alert(this.$referenceStore.getString("yellowscribe_error"))}},async t9ayellow(){if(this.list.army)try{const e=await hs(this.list);this.handleYellowResult(e)}catch{alert(this.$referenceStore.getString("yellowscribe_error"))}},handleYellowResult(e){e!=null?(Tt(e),alert(this.$referenceStore.getString("yellowscribe_copied")+" "+e)):alert(this.$referenceStore.getString("yellowscribe_error"))},async exportYellowscribe(){V(this.system).hasYellowscribe()?await this.wh40kyellow():this.system.short.includes("wh40k")?await this.yellow():this.system.engine==="t9a"?await this.t9ayellow():await this.nryellow()},twohg(){if(!this.list.army){alert(this.$referenceStore.getString("no_list_selected"));return}let e=Ls(this.list.army);e=e.replace(/\n{2,}/g,`
`).trim();const t=new Blob([`"Game System","Faction","Unit","Model","Number","Equipment"
`+e],{type:"text/plain;charset=utf-8"});ms(t,"second_hand_geek_export.csv")},getPreview(){return this.$refs.preview}}});function Pg(e,t,n,s,a,d){const l=_t,u=R("Export"),g=R("Preview"),c=H,x=R("ExportTemplate"),y=Wt;return i(),E(c,{modelValue:e.modelValue,"onUpdate:modelValue":t[9]||(t[9]=b=>e.$emit("update:modelValue",b)),x:"",noclose:""},{header:k(()=>[o(m(e.$referenceStore.getString("export_list")),1)]),default:k(()=>[t[12]||(t[12]=o()),w(l,{system:e.system,hideLink:e.hideLink,hideRos:e.hideRos,onTxt:e.exportText,onPdf:e.exportPdf,onJson:e.exportJson,onRos:e.exportRos,onRosz:e.exportRosz,onPretty:e.exportPretty,onTemplates:e.exportTemplates,onNryellow:e.exportYellowscribe,onSpells:t[0]||(t[0]=b=>e.exportSpells=!0),onTwohg:e.twohg,onShare:t[1]||(t[1]=b=>e.$emit("share"))},null,8,["system","hideLink","hideRos","onTxt","onPdf","onJson","onRos","onRosz","onPretty","onTemplates","onNryellow","onTwohg"]),t[13]||(t[13]=o()),e.textExport?(i(),E(u,{key:0,list:e.list,onlyExportable:e.onlyExportable,modelValue:e.textExport,"onUpdate:modelValue":t[2]||(t[2]=b=>e.textExport=b)},null,8,["list","onlyExportable","modelValue"])):h("",!0),t[14]||(t[14]=o()),e.previewing?(i(),E(c,{key:1,modelValue:e.previewing,"onUpdate:modelValue":t[4]||(t[4]=b=>e.previewing=b),button:e.$referenceStore.getString("print"),onButton:t[5]||(t[5]=()=>{var b;return(b=e.getPreview())==null?void 0:b.print()}),print:"",buttonclose:!1,disabled:!e.previewReady},{default:k(()=>[e.list.army?(i(),E(g,{key:0,ref:"preview",roster:e.list.army,listrow:e.list.row,onReady:t[3]||(t[3]=b=>e.previewReady=!0)},null,8,["roster","listrow"])):h("",!0)]),_:1},8,["modelValue","button","disabled"])):h("",!0),t[15]||(t[15]=o()),e.templating?(i(),E(c,{key:2,modelValue:e.templating,"onUpdate:modelValue":t[7]||(t[7]=b=>e.templating=b),width:"700px",buttons:e.templateReady?[{label:e.$referenceStore.getString("lists_save"),close:!1,function:()=>{var b;return(b=e.$refs.template)==null?void 0:b.save()}},{label:e.$referenceStore.getString("lists_print"),close:!1,function:()=>{var b;return(b=e.$refs.template)==null?void 0:b.print()}}]:[],print:""},{default:k(()=>[e.instanceArmy?(i(),E(x,{key:0,roster:e.instanceArmy,ref:"template",onReady:t[6]||(t[6]=b=>e.templateReady=b)},null,8,["roster"])):h("",!0)]),_:1},8,["modelValue","buttons"])):h("",!0),t[16]||(t[16]=o()),e.exportSpells?(i(),E(c,{key:3,modelValue:e.exportSpells,"onUpdate:modelValue":t[8]||(t[8]=b=>e.exportSpells=b),x:"",noclose:""},{header:k(()=>[...t[10]||(t[10]=[o("Export Spells",-1)])]),default:k(()=>[t[11]||(t[11]=o()),w(y,{invisible:"",spells:e.allSpells},null,8,["spells"])]),_:1},8,["modelValue"])):h("",!0)]),_:1},8,["modelValue"])}const Sg=Object.assign(Q(Ag,[["render",Pg]]),{__name:"ListsListExportDialog"}),hn="dismissedReadmes",Gg=20;function Pt(){if(typeof localStorage>"u")return{};try{return JSON.parse(localStorage.getItem(hn)||"{}")}catch{return{}}}const Bg=G({emits:["edit-unit","list-change","preset-created","force-clicked","add-unit-to-force-category"],components:{CollapsibleBox:ne,SubMenu:$e,ForceList:nl,Category:Za,ForceName:Zt,PopupDialog:H,BsProfileData:tt,ListExportDialog:Sg},setup(){return{store:te()}},props:{list:{required:!0,type:Object},player:{required:!1,type:Object},force:{required:!0,type:Object},mode:{required:!1,default:0,type:Number},mobile:{type:Boolean,default:!1}},data(){return{selectedForceBook:null,selectedForce:null,selectedCategory:null,selectedUnit:null,selectedUnitPresets:null,selectingPreset:!1,selectingForce:!1,selectingForceOptions:void 0,selectingForceFor:"",showSubMenu:!1,bringing:!1,readmeHidden:!1,exporting:!1,singleForceList:null}},watch:{readmeHash:{immediate:!0,handler(e){this.readmeHidden=e in Pt()}}},computed:{readmeHash(){return String(Fs(this.force.getReadMe()||""))},showForceTitleMobile(){var t,n;return this.customView||!this.$mainStore.mobileMode?!0:this.system.settings.hideForces?!1:(((n=(t=this.list)==null?void 0:t.army)==null?void 0:n.getForces(!0).length)||0)<=1?this.forceHasInfo:!0},castSelectedForceOptions(){return this.selectingForceOptions},customView(){var e;return((e=this.list.row.metadata)==null?void 0:e.custom_view)===!0},playMode(){var e,t;return((t=(e=this.list)==null?void 0:e.row.metadata)==null?void 0:t.play_mode)===!0},bs(){return this.force.getBook().getSystem().engine==="bs"},showForceTitle(){return this.customView?!0:!this.hasOnlyOneForce},hasOnlyOneForce(){return this.army.getBook().hasOnlyOneForce()&&this.army.getForces(!0).length<=1},forceHasInfo(){if(!this.bs)return!1;const e=this.force;return e.getModifiedProfiles().length>0||e.getModifiedRules().length>0},system(){return this.army.getBook().getSystem()},categories(){const e=this.customView===!0?this.customCategories:this.force.getCategories();return this.playMode?e.filter(t=>t.isExportable()):e},army(){return this.list.army},customCategories(){return ia(this.list.row,this.force,this.$referenceStore.getString("lists_uncategorized"))}},methods:{hideReadme(){if(this.readmeHidden=!0,typeof localStorage>"u")return;const e=Pt();e[this.readmeHash]=Date.now();const t=Object.entries(e).sort((n,s)=>s[1]-n[1]).slice(0,Gg);localStorage.setItem(hn,JSON.stringify(Object.fromEntries(t)))},async addCustomCategory(){const e=await prompt(this.$referenceStore.getString("lists_custom_category_name"));e&&Jt(this.list.row,e)},debug(e){console.log(e.getName(),e),window.$debugOption=e},editUnit(e){this.$emit("edit-unit",e)},async removeForce(e){if(this.showSubMenu=!1,e.stopImmediatePropagation(),await customConfirm(this.$referenceStore.getString("lists_force_delete_confirm"))){const t=this.force.uid;this.force.delete(this.$optionStore.algoSettings),this.store.editingForceUid===t&&this.store.setEditedForce(null),this.saveList()}},async cloneForce(){this.showSubMenu=!1,await this.force.dupe(),this.saveList()},renameForce(e){this.showSubMenu=!1,this.$nextTick(()=>{var t;(t=this.$refs.forceName)==null||t.editName(e)})},bringUnitsTo(){this.bringing=!0},async hideForce(){this.showSubMenu=!1,await customConfirm({html:this.$referenceStore.getString("play_mode_hide_force_info"),accept:this.$referenceStore.getString("play_mode_hide_force"),id:"play-mode-hide-force-info",save:"session",saveTruthyOnly:!0})&&this.store.hideForce(this.force.uid)},async exportForce(){this.showSubMenu=!1,this.singleForceList=await la(this.list,this.force),this.exporting=!0},bringUnitTo(e,t){t.switchForce(e),this.saveList()},canBringUnitTo(e,t){return t.canSwitchForce(e)},forceChangedClicked(){this.showSubMenu=!1;const e=this.force,t=e.getParent().source.forces||[];this.selectingForceOptions=t.filter(n=>n.id!==e.id),this.selectingForceFor=e.getModelName(),this.selectingForce=!0},forceChangeCanceled(){this.selectingForce=!1,this.selectingForceOptions=void 0,this.selectingForceFor=""},async forceChangeSelected(e){this.forceChangeCanceled();const t=this.force,n=t.toJsonObject();n.option_id=e.getId(),n.name=e.getName();const s=t.getParent();if(!s)throw Error(`Coulnd't find parent of Force ${t.getName()}`);s.setIsRosterLoading(!0),await s.loadOptionsFromJson([n]),t.delete(),s.setIsRosterLoading(!1),this.saveList()},saveList(){this.$emit("list-change")},clicked(e){this.store.editingForceUid!==e.uid&&this.army.getForces().length>1?this.store.setEditedForce(e):this.store.setEditedForce(null),this.$emit("force-clicked",e)},addUnitToCategory(e){this.$emit("add-unit-to-force-category",this.force.uid,e)},copyCats(){this.list&&(ra(this.list.row,this.force),this.saveList())}}}),Qg={key:0,class:"forceRightButtons"},Ug={class:"menuText large-only"},$g={class:"dots"},Rg={class:"dropDownIcon"},Mg={class:"dropDownIcon"},Ig={class:"dropDownIcon"},Hg={class:"dropDownIcon"},Lg={class:"dropDownIcon"},Tg={class:"dropDownIcon"},Og={class:"dropDownIcon"},Yg={class:"dropDownIcon"},Ng={class:"dropDownIcon"},Vg={class:"listSection"},jg={key:0,class:"liste"},Wg={key:0,class:"readme"},Xg={class:"text-center"},zg={key:0},Zg={class:"actionButtons"},Kg=["onClick"];function Jg(e,t,n,s,a,d){const l=R("ForceName"),u=Rt,g=Bt,c=Hn,x=In,y=Ln,b=Ze,f=Se,v=Xe,F=Tn,A=$e,S=R("ForceList"),W=R("BsProfileData"),Y=R("Category"),L=ne,j=H,we=R("ListExportDialog");return i(),p("div",{class:T(["forceSection",{selected:e.force.uid===e.store.editingForceUid}])},[e.showForceTitleMobile?(i(),p("h3",{key:0,class:"titreForce",onClick:t[13]||(t[13]=U=>e.clicked(e.force))},[r("div",null,[w(l,{class:"inline",force:e.force,onSave:e.saveList,editable:"",costs:e.mode!==3,playMode:e.playMode,onMouseup:t[0]||(t[0]=B(U=>e.debug(e.force),["middle","stop"])),ref:"forceName"},null,8,["force","onSave","costs","playMode"])]),t[37]||(t[37]=o()),r("div",{onMouseup:t[12]||(t[12]=B(U=>e.debug(e.force),["middle","prevent"])),class:"forceOptions"},[e.mode==0&&e.showForceTitle?(i(),p("span",Qg,[r("span",{class:"dotsMenuContainer imgBt unselectable nowrap",onClick:t[11]||(t[11]=B(U=>e.showSubMenu=!e.showSubMenu,["stop"]))},[r("span",Ug,m(e.$referenceStore.getString("lists_force_options")),1),t[35]||(t[35]=o()),r("span",$g,[w(u)]),t[36]||(t[36]=o()),e.showSubMenu?(i(),E(A,{key:0,modelValue:e.showSubMenu,"onUpdate:modelValue":t[10]||(t[10]=U=>e.showSubMenu=U),capture:""},{default:k(()=>[e.playMode?(i(),p("div",{key:0,onClick:t[1]||(t[1]=B((...U)=>e.hideForce&&e.hideForce(...U),["stop"]))},[r("span",Rg,[w(g,{class:"icon"})]),t[17]||(t[17]=o()),r("span",null,m(e.$referenceStore.getString("play_mode_hide_force")),1)])):h("",!0),t[27]||(t[27]=o()),e.bs?(i(),p("div",{key:1,onClick:t[2]||(t[2]=B((...U)=>e.forceChangedClicked&&e.forceChangedClicked(...U),["stop"]))},[r("span",Mg,[w(c,{class:"icon"})]),t[18]||(t[18]=o()),r("span",null,m(e.$referenceStore.getString("lists_force_change")),1)])):h("",!0),t[28]||(t[28]=o()),e.bs&&e.force.getParentRoster().getForces().length>1?(i(),p("div",{key:2,onClick:t[3]||(t[3]=B((...U)=>e.bringUnitsTo&&e.bringUnitsTo(...U),["stop"]))},[r("span",Ig,[w(x,{class:"icon"})]),t[19]||(t[19]=o()),r("span",null,m(e.$referenceStore.getString("lists_force_bring_units")),1)])):h("",!0),t[29]||(t[29]=o()),r("div",{onClick:t[4]||(t[4]=B((...U)=>e.renameForce&&e.renameForce(...U),["prevent"]))},[r("span",Hg,[w(y,{class:"icon"})]),t[20]||(t[20]=o()),t[21]||(t[21]=r("span",null," Rename Force ",-1))]),t[30]||(t[30]=o()),e.hasOnlyOneForce?h("",!0):(i(),p("div",{key:3,onClick:t[5]||(t[5]=B((...U)=>e.cloneForce&&e.cloneForce(...U),["prevent"]))},[r("span",Lg,[w(b,{class:"icon","stroke-mult":.85})]),t[22]||(t[22]=o()),r("span",null,m(e.$referenceStore.getString("lists_force_duplicate")),1)])),t[31]||(t[31]=o()),e.hasOnlyOneForce?h("",!0):(i(),p("div",{key:4,onClick:t[6]||(t[6]=B((...U)=>e.removeForce&&e.removeForce(...U),["prevent"]))},[r("span",Tg,[w(f,{class:"icon"})]),t[23]||(t[23]=o()),r("span",null,m(e.$referenceStore.getString("lists_force_delete")),1)])),t[32]||(t[32]=o()),e.customView?(i(),p("div",{key:5,onClick:t[7]||(t[7]=B((...U)=>e.addCustomCategory&&e.addCustomCategory(...U),["prevent"]))},[r("span",Og,[w(v,{class:"icon",size:24,"stroke-mult":1.25})]),t[24]||(t[24]=o()),r("span",null,m(e.$referenceStore.getString("lists_force_add_custom_category")),1)])):h("",!0),t[33]||(t[33]=o()),e.customView?(i(),p("div",{key:6,onClick:t[8]||(t[8]=B((...U)=>e.copyCats&&e.copyCats(...U),["prevent"]))},[r("span",Yg,[w(b,{class:"icon","stroke-mult":.85})]),t[25]||(t[25]=o()),r("span",null,m(e.$referenceStore.getString("lists_force_copy_categories")),1)])):h("",!0),t[34]||(t[34]=o()),e.bs?(i(),p("div",{key:7,onClick:t[9]||(t[9]=B((...U)=>e.exportForce&&e.exportForce(...U),["prevent"]))},[r("span",Ng,[w(F,{class:"icon"})]),t[26]||(t[26]=o()),r("span",null,m(e.$referenceStore.getString("export")),1)])):h("",!0)]),_:1},8,["modelValue"])):h("",!0)])])):h("",!0)],32),t[38]||(t[38]=o()),e.selectingForce?(i(),E(S,{key:0,items:e.castSelectedForceOptions,for:e.selectingForceFor,onCancel:e.forceChangeCanceled,onSelect:e.forceChangeSelected},null,8,["items","for","onCancel","onSelect"])):h("",!0)])):h("",!0),t[45]||(t[45]=o()),r("div",Vg,[e.list&&e.force?(i(),p("div",jg,[e.force.getReadMe()&&!e.playMode&&!e.readmeHidden?(i(),p("div",Wg,[r("button",{class:"readme-close",onClick:t[14]||(t[14]=(...U)=>e.hideReadme&&e.hideReadme(...U))},"×"),t[39]||(t[39]=o()),w(W,{data:e.force.getReadMe(),name:"readme"},null,8,["data"])])):h("",!0),t[40]||(t[40]=o()),(i(!0),p(C,null,D(e.categories,U=>(i(),E(Y,{key:U.uid,list:e.list,category:U,mode:e.mode,onSaveList:e.saveList,onEditUnit:e.editUnit,player:e.player,custom:e.customView,onAddUnitToCategory:e.addUnitToCategory,mobile:e.mobile},{default:k($=>[N(e.$slots,"default",{unit:$.unit},void 0,!0)]),_:3},8,["list","category","mode","onSaveList","onEditUnit","player","custom","onAddUnitToCategory","mobile"]))),128))])):h("",!0),t[43]||(t[43]=o()),e.bringing?(i(),E(j,{key:1,modelValue:e.bringing,"onUpdate:modelValue":t[15]||(t[15]=U=>e.bringing=U),width:"600px"},{default:k(()=>[r("h2",Xg,m(e.$referenceStore.getString("lists_select_units_bring")),1),t[42]||(t[42]=o()),(i(!0),p(C,null,D(e.force.getParentRoster().getForces(),U=>(i(),p(C,null,[U!==e.force?(i(),p("div",zg,[w(L,{title:"titreForce",icon:!1,defcollapsed:!1},{title:k(()=>[w(l,{force:U,costs:e.mode!==3,playMode:e.playMode},null,8,["force","costs","playMode"])]),content:k(()=>[(i(!0),p(C,null,D(U.getCategories(),$=>(i(),p(C,null,[$.getUnits().length?(i(),E(Y,{key:$.uid,list:e.list,player:e.player,force:U,category:$,mode:e.mode},{default:k(({unit:ae})=>[r("div",Zg,[e.canBringUnitTo(e.force,ae)?(i(),p("div",{key:0,class:"actions imgBt",onClick:B(ce=>e.bringUnitTo(e.force,ae),["prevent"])},[w(x,{title:e.$referenceStore.getString("lists_bring_over")},null,8,["title"])],8,Kg)):h("",!0)])]),_:1},8,["list","player","force","category","mode"])):h("",!0)],64))),256))]),_:2},1024)])):h("",!0)],64))),256))]),_:1},8,["modelValue"])):h("",!0),t[44]||(t[44]=o()),e.exporting&&e.singleForceList?(i(),E(we,{key:2,list:e.singleForceList,system:e.system,hideLink:"",onlyExportable:"",modelValue:e.exporting,"onUpdate:modelValue":t[16]||(t[16]=U=>e.exporting=U)},null,8,["list","system","modelValue"])):h("",!0)])],2)}const qg=Object.assign(Q(Bg,[["render",Jg],["__scopeId","data-v-2855893e"]]),{__name:"ListsForce"}),_g=G({props:{preset:{type:Object,required:!0}},data:()=>({editing:!1}),methods:{getTimeAgo(e){return typeof e=="string"&&(e=new Date(e)),ks(e)},delete_preset(){this.$optionStore.deletePreset(this.preset,this.preset.systemId,this.preset.unitId),this.$emit("delete",this.preset)},start_edit(){this.editing=!0},end_edit(){this.editing=!1,this.$optionStore.updateOptions("presets"),this.$emit("edit",this.preset)},toggle_default(){this.$emit("set-default",this.preset)}},components:{EditableDiv:ye},computed:{name:{get(){return this.preset.name??""},set(e){this.preset.name=e}}}}),ef={class:"itemRow"},tf={class:"block"},nf={key:1,class:"presetName"},sf={class:"presetAge"},of={class:"presetDescription",style:{"white-space":"pre-wrap"}},rf=["checked","title"];function af(e,t,n,s,a,d){const l=R("EditableDiv"),u=Pe,g=Se;return i(),p("tr",ef,[r("td",null,[r("div",tf,[e.editing?(i(),E(l,{key:0,modelValue:e.name,"onUpdate:modelValue":t[0]||(t[0]=c=>e.name=c),class:"presetName inputlike",style:{display:"inline-block"},onClick:t[1]||(t[1]=B(()=>{},["stop"])),onDone:e.end_edit,single:""},null,8,["modelValue","onDone"])):(i(),p("span",nf,m(e.name),1)),t[6]||(t[6]=o()),r("span",sf,m(e.getTimeAgo(e.preset.created)),1)]),t[7]||(t[7]=o()),r("div",of,m(e.preset.description),1)]),t[8]||(t[8]=o()),r("td",{class:"tdicon",onClick:t[3]||(t[3]=B(()=>{},["stop"]))},[r("input",{type:"checkbox",checked:e.preset.default,onChange:t[2]||(t[2]=(...c)=>e.toggle_default&&e.toggle_default(...c)),title:e.$referenceStore.getString("preset_default")},null,40,rf)]),t[9]||(t[9]=o()),r("td",{class:"tdicon hover-darken",onClick:t[4]||(t[4]=B((...c)=>e.start_edit&&e.start_edit(...c),["stop"]))},[w(u,{class:"icon"})]),t[10]||(t[10]=o()),r("td",{class:"tdicon trash",onClick:t[5]||(t[5]=B((...c)=>e.delete_preset&&e.delete_preset(...c),["stop"]))},[w(g,{class:"icon"})])])}const lf=Object.assign(Q(_g,[["render",af],["__scopeId","data-v-229af2f7"]]),{__name:"ListsPresetListPreset"}),df=G({emits:["onCancel","onSelect"],components:{PopupDialog:H,PresetListPreset:lf},name:"PresetList",data(){return{items:void 0}},props:{systemId:{type:[String,Number],default:null},unitId:{type:String,default:null},for:{type:String,default:null}},created(){this.items=this.getItems()},computed:{title(){return this.for?this.$referenceStore.getString("preset_select_for").replace("{name}",this.for):this.$referenceStore.getString("preset_select")}},methods:{getItems(){if(!this.systemId||!this.unitId)return;const e=Ht(this.$optionStore.options,this.systemId,this.unitId);if(e)return Object.values(e)},selectItem(e){this.$emit("onSelect",e)},update(){this.items=this.getItems()},onSetDefault(e){const t=e.default;Ds(this.$optionStore.options,this.systemId,this.unitId,t?null:e),this.items=this.getItems()}}}),pf={class:"contentTable"};function uf(e,t,n,s,a,d){const l=R("PresetListPreset"),u=H;return i(),E(u,{text:e.$referenceStore.getString("cancel"),width:"800px",x:"",noclose:""},{header:k(()=>[o(m(e.title),1)]),default:k(()=>[t[6]||(t[6]=o()),r("div",pf,[r("table",null,[r("thead",null,[r("tr",null,[r("th",null,m(e.$referenceStore.getString("preset_select")),1),t[0]||(t[0]=o()),r("th",null,m(e.$referenceStore.getString("preset_default")),1),t[1]||(t[1]=o()),t[2]||(t[2]=r("th",null,null,-1)),t[3]||(t[3]=o()),t[4]||(t[4]=r("th",null,null,-1))])]),t[5]||(t[5]=o()),r("tbody",null,[(i(!0),p(C,null,D(e.items,(g,c)=>(i(),E(l,{class:"itemRow",key:c,preset:g,onClick:x=>e.selectItem(g),onDelete:e.update,onSetDefault:e.onSetDefault},null,8,["preset","onClick","onDelete","onSetDefault"]))),128))])])])]),_:1},8,["text"])}const cf=Object.assign(Q(df,[["render",uf],["__scopeId","data-v-df10d851"]]),{__name:"ListsPresetList"}),gf=G({components:{PopupDialog:H,Force:qg,Book:_i,PresetList:cf,UnitProfiles:Ue,Preview:mn,ExportTemplate:Ve},setup(){return{store:te()}},mixins:[nt],props:{unit:{type:Object,required:!1},force:{type:Object,required:!1},allForces:{type:Boolean,default:!0},player:{required:!1,type:Object}},created(){addEventListener("keydown",this.on_p_key)},activated(){var e;addEventListener("keydown",this.on_p_key),(e=this.$refs.splitView)==null||e.update()},deactivated(){removeEventListener("keydown",this.on_p_key)},data(){return{renumbering:!1,previewing:!1,previewReady:!1,templating:!1,templateReady:!1,addingForce:!1,addingNestedForce:!1,shareLink:null,newForceBook:null,newForce:null,newForces:null,supportNewRecruit:"",selectingForce:!1,selectingForceOptions:void 0,selectingForceFor:"",selectingForceHandler:void 0,presetForce:null,presetUnit:null,presetOpen:!1,large:globalThis.innerWidth>1200,loaded:!1,poppingUnit:!1,poppedUnit:null,addingUnitToForceUid:null,addingUnitToCategory:null,exportTemplateComponent:Ve}},computed:{playMode(){var t,n,s;const e=((n=(t=this.player)==null?void 0:t.list)==null?void 0:n.row.metadata)||((s=this.$listStore.currentList)==null?void 0:s.row.metadata);return(e==null?void 0:e.play_mode)===!0},hasLeaders(){const e=this.$systemStore.selectedSystem;return e?V(e).hasLeaders():!1},hasStratagems(){const e=this.$systemStore.selectedSystem;return e?V(e).hasStratagems():!1},showNonExportableWarning(){return et(this.army)},instanceArmy(){return this.list.army&&this.list.army instanceof Be?this.list.army:null},mobile(){return this.$userStore.windowWidth<770},tableForces(){let e=[];return this.force&&(e=[this.force]),e=this.forces||[],e.filter(t=>this.playMode?t.isExportable()?!this.store.hiddenForceUids.includes(t.uid):!1:!0)},addCollapsed(){return this.store.isCollapsed()},readonly(){return this.playMode},show_floating_add_forces_button(){var e,t;return!this.readonly&&!!((t=(e=this.system)==null?void 0:e.settings)!=null&&t.floatingAddForcesButton)},show_floating_add_nested_forces_button(){var e,t;return!this.readonly&&!!((t=(e=this.system)==null?void 0:e.settings)!=null&&t.floatingAddNestedForcesButton)},nested_force_label(){for(const e of this.tableForces){const t=e.getChildForcesLabel();if(t)return t}return null},prefer_viewing(){return this.editingUnit&&this.unit?"edit":this.addingUnit?"add":"force"},show_adding(){return this.playMode?!1:this.split||this.prefer_viewing==="add"},show_editing(){return this.playMode?!1:!!(this.split&&this.unit||this.prefer_viewing==="edit")},show_force(){return this.split||this.prefer_viewing==="force"},addingUnit(){return this.store.addingUnit},systemId(){var e;return((e=this.book)==null?void 0:e.getIdSystem())||null},split(){return this.$optionStore.options.alwaysShowPlus?!1:this.large&&this.mode==0},poppedInstance(){return this.poppedUnit}},watch:{previewing(){this.previewReady=!1},templating(){this.templateReady=!1},list(){this.army&&this.army.validateArmy(!0)},addCollapsed(e){e?this.loaded=!0:this.loaded=!1}},mounted(){this.army&&this.army.validateArmy(!0),this.$nextTick(()=>{window.addEventListener("resize",this.onResize)})},unmounted(){window.removeEventListener("resize",this.onResize),removeEventListener("keydown",this.on_p_key)},methods:{get_preview(){return this.$refs.preview},on_p_key(e){function t(n){var a,d;const s=(((a=n.target)==null?void 0:a.tagName)||"").toLowerCase();return!(["input"].includes(s)||(d=n.target)!=null&&d.isContentEditable)}if(e.key&&e.key.toLowerCase()==="p"&&!e.ctrlKey&&t(e)&&(this.previewing=!this.previewing),e.key&&e.key.toLowerCase()==="y"&&!e.ctrlKey&&t(e)&&(this.templating=!this.templating),e.key&&e.key.toLowerCase()==="t"&&!e.ctrlKey&&t(e)){const n=this.$parent;n!=null&&n.exportText&&n.exportText()}},closePoppedUnit(){this.poppedUnit=null,this.poppingUnit=!1},popUnit(e){this.poppedUnit=e,this.poppingUnit=!0},editUnit(e){this.mode==3||this.playMode?this.popUnit(e):this.mode==0&&this.$router.push({query:{view:e.uid}})},forceNameClicked(e){const t=this.$refs.book;t&&this.$nextTick(()=>{t.scrollTo(e.getUid())})},onResize(){const e=globalThis.innerWidth>1200;this.large!==e&&(this.large=e)},onPresetCreation(e,t){this.presetForce=e,this.presetUnit=t,this.presetOpen=!0},recruitOnPresetSelected(e){if(this.presetUnit&&this.presetForce){const t=new Ge;t.logOwnUnitWarnings=!1;const n=this.presetForce.insertUnit(t,this.presetUnit,e.options);if(n==null){this.$mainStore.errorManager.notifyLastError(t.errorStack);return}else t.logWarnings&&this.$showMessages(t.warningStack);this.save(),this.mobile||(this.$router.push({query:{view:n.uid}}),this.store.setEditedUnit(n))}this.presetUnit=null,this.presetOpen=!1},forceAdded(){this.save(),this.$router.replace({query:{view:"main"}})},save(){this.$emit("list-change")},addUnitToForceCategory(e,t){this.$router.push({query:{view:"add",category:t,force:e}})}}}),ff={key:1,class:"non-exportable-warning"},mf={class:"scrollable"},hf={key:0,style:{width:"100%"}},xf={class:"scrollable"},bf={class:"scrollable"},yf={key:0,class:"content"},vf=["innerHTML"],wf={key:1};function Cf(e,t,n,s,a,d){var we,U;const l=Yo,u=_o,g=R("Book"),c=R("Force"),x=je,y=rr,b=Je,f=R("PresetList"),v=Zr,F=R("UnitProfiles"),A=Us,S=Rs,W=Ms,Y=H,L=R("Preview"),j=R("ExportTemplate");return e.list&&!e.$mainStore.loading?(i(),p("div",{key:0,id:"vueListe",class:T({editingVueList:e.editingUnit})},[e.mode!==3?(i(),E(l,{key:0,list:e.list,hidden:e.addingUnit||!e.split&&e.editingUnit,mode:e.mode,onSave:e.save},{default:k(()=>[N(e.$slots,"icons",{},void 0,!0)]),_:3},8,["list","hidden","mode","onSave"])):h("",!0),t[26]||(t[26]=o()),P(w(u,{list:e.list},null,8,["list"]),[[K,e.mode!=3&&(!e.mobile||!e.editingUnit&&!e.addingUnit)]]),t[27]||(t[27]=o()),e.playMode&&e.showNonExportableWarning?(i(),p("div",ff,m(e.$referenceStore.getString("no_exportable_units_warning")),1)):h("",!0),t[28]||(t[28]=o()),e.army&&e.book?(i(),p(C,{key:2},[e.split?(i(),E(y,{key:0,ref:"splitView",draggable:"",leftWidth:e.addCollapsed?28:0,showLeft:e.show_adding,showRight:e.show_editing,showMiddle:e.show_force,rightWidth:650,loaded:e.loaded,id:"roster"},$t({left:k(()=>[w(g,{ref:"book",book:e.book,army:e.army||void 0,booksDate:e.list.row.booksDate,"force-uid":(e._.provides[ut]||e.$route).query.force||e.store.editingForceUid,onEditUnit:e.editUnit,onListChange:e.save,onPresetCreated:e.onPresetCreation},null,8,["book","army","booksDate","force-uid","onEditUnit","onListChange","onPresetCreated"])]),middle:k(()=>{var $,ae;return[r("div",mf,[(i(!0),p(C,null,D(e.tableForces,ce=>(i(),E(c,{key:ce.uid,onForceClicked:e.forceNameClicked,onEditUnit:e.editUnit,onListChange:e.save,onPresetCreated:e.onPresetCreation,onAddUnitToForceCategory:e.addUnitToForceCategory,force:ce,list:e.list,player:e.player,mode:e.mode},{default:k(xn=>[N(e.$slots,"rowactions",{unit:xn.unit},void 0,!0)]),_:3},8,["onForceClicked","onEditUnit","onListChange","onPresetCreated","onAddUnitToForceCategory","force","list","player","mode"]))),128)),t[13]||(t[13]=o()),e.playMode?h("",!0):(i(),p("div",hf,[($=e.tableForces)!=null&&$.length&&e.show_floating_add_nested_forces_button?(i(),p("button",{key:0,class:"bouton add-force-btn",onClick:t[0]||(t[0]=ce=>e.addingNestedForce=!0)},[w(x,{size:18}),o(" "+m(e.nested_force_label?e.$referenceStore.getString("add")+" "+e.nested_force_label:e.$referenceStore.getString("add_force")),1)])):!((ae=e.tableForces)!=null&&ae.length)||e.show_floating_add_forces_button?(i(),p("button",{key:1,class:"bouton add-force-btn",onClick:t[1]||(t[1]=ce=>e.addingForce=!0)},[w(x,{size:18}),o(" "+m(e.$referenceStore.getString("add_force")),1)])):h("",!0)])),t[14]||(t[14]=o()),t[15]||(t[15]=r("div",{style:{"min-height":"100px"}},null,-1))])]}),_:2},[e.unit?{name:"right",fn:k(()=>[r("div",xf,[N(e.$slots,"edit",{},void 0,!0)])]),key:"0"}:void 0]),1032,["leftWidth","showLeft","showRight","showMiddle","loaded"])):(i(),p(C,{key:1},[P(w(g,{ref:"book",book:e.book,army:e.army,nocollapse:"",booksDate:e.list.row.booksDate,onEditUnit:e.editUnit,onListChange:e.save,onPresetCreated:e.onPresetCreation,"force-uid":(e._.provides[ut]||e.$route).query.force||e.store.editingForceUid||e.store.addingUnitForceUid,"category-filter":e.store.addingUnitCategory,fixedsearchbar:""},null,8,["book","army","booksDate","onEditUnit","onListChange","onPresetCreated","force-uid","category-filter"]),[[K,e.show_adding]]),t[21]||(t[21]=o()),P(r("div",{style:oe(e.show_force&&e.mode!=3?"margin-bottom: 50px":""),class:"scrollable"},[(i(!0),p(C,null,D(e.tableForces,$=>(i(),E(c,{key:$.uid,onForceClicked:e.forceNameClicked,onEditUnit:e.editUnit,onListChange:e.save,onPresetCreated:e.onPresetCreation,onAddUnitToForceCategory:e.addUnitToForceCategory,force:$,list:e.list,player:e.player,mode:e.mode,mobile:""},{default:k(ae=>[N(e.$slots,"rowactions",{unit:ae.unit},void 0,!0)]),_:3},8,["onForceClicked","onEditUnit","onListChange","onPresetCreated","onAddUnitToForceCategory","force","list","player","mode"]))),128)),t[18]||(t[18]=o()),(we=e.tableForces)!=null&&we.length&&e.show_floating_add_nested_forces_button?(i(),p("button",{key:0,class:"bouton add-force-btn",onClick:t[2]||(t[2]=$=>e.addingNestedForce=!0)},[w(x,{size:18}),o(" "+m(e.nested_force_label?e.$referenceStore.getString("add")+" "+e.nested_force_label:e.$referenceStore.getString("add_force")),1)])):!((U=e.tableForces)!=null&&U.length)||e.show_floating_add_forces_button?(i(),p("button",{key:1,class:"bouton add-force-btn",onClick:t[3]||(t[3]=$=>e.addingForce=!0)},[w(x,{size:18}),o(" "+m(e.$referenceStore.getString("add_force")),1)])):h("",!0),t[19]||(t[19]=o()),t[20]||(t[20]=r("div",{style:{"min-height":"100px"}},null,-1))],4),[[K,e.show_force]]),t[22]||(t[22]=o()),P(r("div",bf,[N(e.$slots,"edit",{},void 0,!0)],512),[[K,e.show_editing]])],64))],64)):(i(),p(C,{key:3},[e.mode==0?(i(),p("div",yf,[e.list.army?(i(),p("p",{key:0,innerHTML:e.$referenceStore.getString("no_army_force")},null,8,vf)):(i(),p("p",wf,[o(m(e.$referenceStore.getString("book_load_error_online"))+" "+m()+" ",1),w(b,{to:{name:"app-Contact"}},{default:k(()=>[o(m(e.$referenceStore.getString("contact_new_recruit")),1)]),_:1})]))])):(i(),p(C,{key:1},[o(m(e.$referenceStore.getString("no_list_selected_player")),1)],64))],64)),t[29]||(t[29]=o()),e.presetOpen&&e.systemId&&e.presetUnit&&e.presetForce?(i(),E(f,{key:4,modelValue:e.presetOpen,"onUpdate:modelValue":t[4]||(t[4]=$=>e.presetOpen=$),systemId:e.systemId,unitId:e.presetUnit.id,for:e.presetUnit.name,onOnSelect:e.recruitOnPresetSelected},null,8,["modelValue","systemId","unitId","for","onOnSelect"])):h("",!0),t[30]||(t[30]=o()),e.list&&e.list.army&&e.book&&e.addingForce?(i(),E(v,{key:5,roster:e.list.army,book:e.book,booksDate:e.list.row.booksDate,modelValue:e.addingForce,"onUpdate:modelValue":t[5]||(t[5]=$=>e.addingForce=$),onForceAdded:e.forceAdded},null,8,["roster","book","booksDate","modelValue","onForceAdded"])):h("",!0),t[31]||(t[31]=o()),e.list&&e.list.army&&e.book&&e.addingNestedForce?(i(),E(v,{key:6,roster:e.list.army,book:e.book,booksDate:e.list.row.booksDate,nested:"",modelValue:e.addingNestedForce,"onUpdate:modelValue":t[6]||(t[6]=$=>e.addingNestedForce=$),onForceAdded:e.forceAdded},null,8,["roster","book","booksDate","modelValue","onForceAdded"])):h("",!0),t[32]||(t[32]=o()),e.poppedUnit&&e.poppingUnit?(i(),E(Y,{key:7,modelValue:e.poppingUnit,"onUpdate:modelValue":t[7]||(t[7]=$=>e.poppingUnit=$),text:e.$referenceStore.getString("close"),onClose:e.closePoppedUnit,width:"1200px",x:"",noclose:"",notitlebar:"",xtop:"10px",xright:"10px"},{default:k(()=>[w(F,{unit:e.poppedUnit,onClose:e.closePoppedUnit,listrow:e.list.row,onChange:e.save},null,8,["unit","onClose","listrow","onChange"]),t[23]||(t[23]=o()),w(A,{unit:e.poppedInstance},null,8,["unit"]),t[24]||(t[24]=o()),e.hasStratagems?(i(),E(S,{key:0,unit:e.poppedInstance,"filter-by-phase":e.mode===3},null,8,["unit","filter-by-phase"])):h("",!0),t[25]||(t[25]=o()),e.hasLeaders?(i(),E(W,{key:1,onChange:e.save,unit:e.poppedInstance,list:e.list.row},null,8,["onChange","unit","list"])):h("",!0)]),_:1},8,["modelValue","text","onClose"])):h("",!0),t[33]||(t[33]=o()),e.previewing?(i(),E(Y,{key:8,modelValue:e.previewing,"onUpdate:modelValue":t[9]||(t[9]=$=>e.previewing=$),button:e.$referenceStore.getString("print"),onButton:t[10]||(t[10]=()=>e.get_preview().print()),print:"",buttonclose:!1,disabled:!e.previewReady},{default:k(()=>[e.list.army?(i(),E(L,{key:0,ref:"preview",roster:e.list.army,listrow:e.list.row,onReady:t[8]||(t[8]=$=>e.previewReady=!0)},null,8,["roster","listrow"])):h("",!0)]),_:1},8,["modelValue","button","disabled"])):h("",!0),t[34]||(t[34]=o()),e.templating?(i(),E(Y,{key:9,modelValue:e.templating,"onUpdate:modelValue":t[12]||(t[12]=$=>e.templating=$),width:"700px",buttons:e.templateReady?[{label:e.$referenceStore.getString("lists_save"),close:!1,function:()=>{var $;return($=e.$refs.preview)==null?void 0:$.save()}},{label:e.$referenceStore.getString("lists_print"),close:!1,function:()=>{var $;return($=e.$refs.preview)==null?void 0:$.print()}}]:[],print:""},{default:k(()=>[e.instanceArmy?(i(),E(j,{key:0,roster:e.instanceArmy,ref:"preview",onReady:t[11]||(t[11]=$=>e.templateReady=$)},null,8,["roster"])):h("",!0)]),_:1},8,["modelValue","buttons"])):h("",!0)],2)):h("",!0)}const jf=Object.assign(Q(gf,[["render",Cf],["__scopeId","data-v-2230ccaf"]]),{__name:"ListsTableList"});export{md as E,jf as T,Zr as _,ma as a,_t as b};
