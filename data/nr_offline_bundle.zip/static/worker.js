// @ts-check
/// <reference lib="webworker" />
// Checked by static/tsconfig.json (npm run typecheck); keep this file dependency-free.
const sw = /** @type {ServiceWorkerGlobalScope} */ (/** @type {unknown} */ (self));

const version = "36.27";

const debug = false;
const modes = [
  "Cache/Save",
  "Cache/No",
  "Network/Save",
  "Network/No",
  "Cache Only",
  "Network Only/Save",
  "Network Only/No",
];

/** @param {Request} request */
function isHtmlPage(request) {
  const res = request.url.includes("/app/") && request.url.endsWith(".js") == false;
  return res;
}

/** @param {Request} request @param {number} strat */
async function mFetch(request, strat) {
  if (debug) {
    console.log("Fetching (" + modes[strat - 1] + ") " + request.url);
  }
  try {
    /** @type {RequestMode} */
    let mode = "same-origin";
    if (request.url.includes("newrecruit") || request.url.includes("github")) {
      mode = "cors";
    }
    return await fetch(request, { mode: mode });
  } catch (e) {
    return null;
  }
}

/** @param {Request} request */
async function fCache(request) {
  // Look only in the cache the entry was written to: caches.match() walks every cache, and
  // books_folder holds hundreds of MB on a real profile, so ~100 chunk lookups at boot were
  // paying that walk each.
  const cacheTab = await openCacheTab(request);
  if (isHtmlPage(request)) {
    return await cacheTab.match(new Request("/app/"));
  }
  return await cacheTab.match(request);
}

/** @type {Record<string, Promise<Cache>>} */
const cacheHandles = {};
/** @param {string} name */
function openNamed(name) {
  if (!cacheHandles[name]) cacheHandles[name] = caches.open(name);
  return cacheHandles[name];
}

/** @param {Request} request */
function openCacheTab(request) {
  if (request.url.includes("books_")) {
    return openNamed("books_folder");
  }

  if (request.url.includes("user_")) {
    return openNamed("user_folder");
  }

  if (request.url.includes("tourny_")) {
    return openNamed("tourny_folder");
  }

  if (request.url.includes("report_get")) {
    return openNamed("report_folder");
  }

  if (request.url.includes("get_library")) {
    return openNamed("lib_folder");
  }

  if (request.url.includes("/settings/")) {
    return openNamed("settings_folder");
  }

  return openNamed("newrecruit");
}

/** @param {Request} request @param {number} strat @param {FetchEvent} [event] */
async function fetchAndCache(request, strat, event) {
  const resp = await mFetch(request, strat);
  if (resp == null) return null;

  // The page gets the response now; the cache write runs behind it under waitUntil. Awaiting
  // the write held every response until its own put landed, and after a deploy (every chunk a
  // miss) that serialised ~100 boot chunks on the disk, seconds apart.
  const writing = storeResponse(request, resp.clone());
  if (event) event.waitUntil(writing);
  return resp;
}

/** @param {Request} request @param {Response} resp */
async function storeResponse(request, resp) {
  try {
    // Only cache 200-299, and never an rpc payload that carries an error
    if (!resp.ok) return;
    if (request.url.includes("/api/")) {
      try {
        const json = await resp.clone().json();
        if (json.error) return;
      } catch {}
    }
    const cacheTab = await openCacheTab(request);
    if (isHtmlPage(request)) {
      await cacheTab.put("/app/", resp);
    } else {
      await cacheTab.put(request, resp);
    }
  } catch {
    console.log("Error: " + request.url);
  }
}

// Strategy 3 is app navigations, so it must never wait on a connection that answers but stalls:
// a dead fetch never rejects, and the offline fallback below only runs on rejection or null.
const NETWORK_FIRST_TIMEOUT = 5000;
const TIMED_OUT = "__nr_timed_out__";

/**
 * Resolves to TIMED_OUT after ms without cancelling the request: the in-flight fetch keeps
 * going and still fills the cache, we only stop waiting for it.
 * @param {Promise<Response|null>} promise @param {number} ms
 */
function raceWithTimeout(promise, ms) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve(TIMED_OUT), ms);
    promise.then(
      (res) => {
        clearTimeout(timer);
        resolve(res);
      },
      () => {
        clearTimeout(timer);
        resolve(null);
      },
    );
  });
}

/** 
 * @param {Request} request 
 * @param {boolean} save 
 * @param {number} strat 
 * @param {FetchEvent} [event]
 **/
async function networkFirst(request, save, strat, event) {
  const pending = save ? fetchAndCache(request, strat, event) : mFetch(request, strat);
  // The background completion must not surface as an unhandled rejection once we stop awaiting it.
  pending.catch(() => {});

  const res = await raceWithTimeout(pending, NETWORK_FIRST_TIMEOUT);

  if (res === TIMED_OUT) {
    // Must extend the event now: answering from cache settles respondWith, and fetchAndCache's own
    // waitUntil would then fire on a finished event (InvalidStateError) and lose the cache write.
    if (event) event.waitUntil(pending);
    const cached = await fCache(request);
    if (cached && cached.ok) return cached;
    // Nothing cached: the slow network is still our only source, so go back to waiting on it.
    return pending;
  }

  // If res is null, look into cache
  if (res == null || !res.ok) {
    return fCache(request);
  }
  return res;
}

/** @param {Request} request @param {boolean} save @param {boolean} onlyCache @param {number} strat @param {FetchEvent} [event] */
async function cacheFirst(request, save, onlyCache, strat, event) {
  const reponse = await fCache(request);
  // reponse is null if we found no cache
  if (reponse == null || !reponse.ok) {
    if (onlyCache) return null;
    if (save) {
      return fetchAndCache(request, strat, event);
    }
    return mFetch(request, strat);
  } else {
    // We found something in cache
    return reponse;
  }
}

sw.addEventListener("install", function (event) {
  event.waitUntil(sw.skipWaiting());
});

// Chunks accumulate forever otherwise (hashed urls rotate every release). assets.json is the
// build's own public-file listing, so anything cached outside its _nuxt set belongs to a dead
// build. A stale shell that loses a chunk refetches it: the server retains old builds on disk.
async function cleanOldChunks() {
  /** @type {Set<string>} */
  let current;
  try {
    /** @type {string[]} */
    const files = await (await fetch("/assets.json", { cache: "no-store" })).json();
    // Separators are \ when built on Windows, / on the Linux CI.
    current = new Set(files.map((f) => String(f).replace(/\\/g, "/")).filter((f) => f.startsWith("_nuxt/")).map((f) => f.slice(6)));
  } catch {
    return; // offline: keep everything, the next online sweep retries
  }
  if (current.size === 0) return;
  const cache = await openNamed("newrecruit");
  // The cached shell can be an older build (network-first HTML falls back to cache): keep every
  // chunk it references so that shell still boots offline until its next online refresh.
  try {
    const shell = await cache.match("/app/");
    const html = shell ? await shell.text() : "";
    for (const ref of html.match(/\/_nuxt\/[\w.-]+/g) ?? []) current.add(ref.slice(7));
  } catch {}
  for (const request of await cache.keys()) {
    // Only top-level /_nuxt/<file> entries; builds/ (latest.json etc) never matches.
    const m = /\/_nuxt\/([^/?]+)(\?|$)/.exec(request.url);
    if (m && !current.has(m[1])) await cache.delete(request);
  }
}

// Cleanup must never run from activate: waitUntil there delays activation, and fetch events
// wait for activation, so the first (large) sweep would stall page loads right after an update.
// A fetch event's waitUntil only keeps the worker alive; responses are never delayed by it.
let cleanupStarted = false;
/** @param {FetchEvent} event */
function scheduleCleanup(event) {
  if (cleanupStarted) return;
  cleanupStarted = true;
  event.waitUntil(cleanupOnce());
}

// Runs the sweep once per release: the marker holds the last version that completed it, so SW
// cold starts within one release cost a single cache lookup and no network.
async function cleanupOnce() {
  try {
    const cache = await openNamed("newrecruit");
    const marker = await cache.match("/__sw-cleaned__");
    if (marker && (await marker.text()) === version) return;
    await cleanOldChunks();
    await cache.put("/__sw-cleaned__", new Response(version));
  } catch {}
}

/*
 ** Caching strategies
 ** 1 : Cache first and save to cache
 ** 2 : Cache first and don't save to cache
 ** 3 : Network first and save to cache
 ** 4 : Network first and don't save to cache
 ** 5 : Cache only
 ** 6 : Network only and save to cache
 ** 7 : Network only and don't save to cache
 */

/** @param {FetchEvent} event */
async function handleRequest(event) {
  let cacheStrategy = 1;

  const stratHeader = event.request.headers.get("SW-Cache-Strategy");
  if (stratHeader != undefined) {
    cacheStrategy = parseInt(stratHeader);
  }

  if (isHtmlPage(event.request)) {
    cacheStrategy = 3;
  }

  let res = null;

  // Handle tournament lists
  // Check cache first and compare the version numbers
  // If no cache or version numbers are different, we fetch from server

  if (cacheStrategy === 1) {
    res = await cacheFirst(event.request, true, false, 1, event);
  }

  if (cacheStrategy === 2) {
    res = await cacheFirst(event.request, false, false, 2);
  }

  if (cacheStrategy === 3) {
    res = await networkFirst(event.request, true, 3, event);
  }

  if (cacheStrategy === 4) {
    res = await networkFirst(event.request, false, 4);
  }

  if (cacheStrategy === 5) {
    res = await cacheFirst(event.request, false, true, 5);
  }

  if (cacheStrategy === 7) {
    res = await mFetch(event.request, 7);
  }

  if (
    res != null &&
    event.request.url.includes("/app") === false &&
    event.request.url.includes("api/rpc") === false &&
    event.request.method === "GET" &&
    res.status >= 400
  ) {
    return Response.redirect("/app/");
  }
  if (res == null || res.status >= 400) {
    if (cacheStrategy == 5) {
      return new Response(
        JSON.stringify({
          error: 2,
          message: "Cache only request was made and nothing found in cache",
        }),
        {
          headers: { "Content-Type": "application/json" },
        },
      );
    }

    // NR-G7: respondWith(null) throws in the page; answer offline-and-uncached with a real response
    if (res == null) {
      return new Response("Offline and not cached", { status: 504 });
    }
    return res;
  }

  return res;
}

sw.addEventListener("fetch", function (event) {
  const noWorker = [
    "sockjs",
    "chrome-extension",
    "hot-update",
    "webpack",
    "hot-middleware",
    "google",
    "process-update",
    "bootstrap",
    "stripe.com",
    "hmr",
    "nuxtdev",
    "warhall",
    "firebasedatabase",
    "unityweb",
    "_loading",
    "t.paypal.com",
  ];
  let leave = false;

  if (event.request.method.toUpperCase() != "GET") {
    return false;
  }

  if (event.request.url.endsWith("/app")) {
    return false;
  }

  // Service worker should only handles request from app, assets or rpc gets
  let include = ["assets", "settings", "favicon.ico", "rpc", "app", "_nuxt"];
  let useWorker = false;
  for (let elt of include) {
    useWorker = useWorker || event.request.url.includes(elt);
  }
  if (useWorker == false) {
    return false;
  }

  for (const url of noWorker) {
    if (leave == false && event.request.url.includes(url)) {
      leave = true;
    }
  }

  if (event.request.url.startsWith(self.location.origin) == false) {
    leave = true;
  }

  if (leave) {
    return false;
  }
  scheduleCleanup(event);
  event.respondWith(handleRequest(event));
});
